package com.xray.bt.monitor2;

import android.view.View;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;

public class BatteryIndicator extends View {
	private static final String TAG = "BatteryIndicator";
    private static final boolean DBG_SPACE = false;

    int mBodyHeightPercent;
    int mBodyWidthPercent;
    int mCapHeightPercent;
    int mCapWidthPercent;
	
	Paint mSolidPaint;
	Paint mEmptyPaint;
    Paint mSolidPaintLow;
	Paint mEmptyPaintLow;
	Paint mSolidPaintMiddle;
	Paint mEmptyPaintMiddle;
	
    Paint mTextPaint;
	
	int mLevel = -1;
    String mLevelText = "";
	
    int mLowLimit = 0, mMiddleLimit = 0;

	public BatteryIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.BatteryIndicator);

        mLowLimit = typedArray.getColor(R.styleable.BatteryIndicator_lowLevelLimit, 0);
		mMiddleLimit = typedArray.getColor(R.styleable.BatteryIndicator_middleLevelLimit, 50);
		
		int color_good = typedArray.getColor(R.styleable.BatteryIndicator_goodFillColor, Color.WHITE);
		int color_middle = typedArray.getColor(R.styleable.BatteryIndicator_middleFillColor, Color.YELLOW);
        int color_low = typedArray.getColor(R.styleable.BatteryIndicator_lowFillColor, Color.RED);
		
		mBodyHeightPercent = typedArray.getInt(R.styleable.BatteryIndicator_bodyHeightPercent, 0);
		mBodyWidthPercent = typedArray.getInt(R.styleable.BatteryIndicator_bodyWidthPercent, 0);
        mCapHeightPercent = typedArray.getInt(R.styleable.BatteryIndicator_capHeightPercent, 0);
		mCapWidthPercent = typedArray.getInt(R.styleable.BatteryIndicator_capWidthPercent, 0);

		mSolidPaint = new Paint();
		mSolidPaint.setColor(color_good);
		mSolidPaint.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyPaint = new Paint();
		mEmptyPaint.setColor(color_good);
		mEmptyPaint.setStyle(Paint.Style.STROKE);
		mEmptyPaint.setStrokeWidth(2);

        mSolidPaintLow = new Paint();
		mSolidPaintLow.setColor(color_low);
		mSolidPaintLow.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyPaintLow = new Paint();
		mEmptyPaintLow.setColor(color_low);
		mEmptyPaintLow.setStyle(Paint.Style.STROKE);
		mEmptyPaintLow.setStrokeWidth(2);

        mSolidPaintMiddle = new Paint();
		mSolidPaintMiddle.setColor(color_middle);
		mSolidPaintMiddle.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyPaintMiddle = new Paint();
		mEmptyPaintMiddle.setColor(color_middle);
		mEmptyPaintMiddle.setStyle(Paint.Style.STROKE);
		mEmptyPaintMiddle.setStrokeWidth(2);		

        mTextPaint = new Paint();
        mTextPaint.setColor(Color.WHITE);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        		
		typedArray.recycle();
	}
        
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (mLevel == -1)
            return;
        
		final int w = getWidth();
		final int h = getHeight();

        //Log.d(TAG, "w = " + w + ", h = " + h);

        final int x1 = w * (100 - mBodyWidthPercent) / 2 / 100;
        final int x2 = w - x1;
        final int y1 = h * (100 - mBodyHeightPercent) / 2 / 100;
        final int y2 = h - y1;

        final int xx1 = x2;
        final int yy1 = y1 + (y2 - y1) * (100 - mCapHeightPercent) / 2 / 100;
        final int xx2 = xx1 + (w - x2) * (mCapWidthPercent) / 100;
        final int yy2 = y2 - (yy1 - y1);

        final int xlevel = x1 + (x2 - x1) * mLevel / 100;

        Paint emptyPaint, solidPaint;
		if (mLevel <= mLowLimit) {
			emptyPaint = mEmptyPaintLow;
			solidPaint = mSolidPaintLow;
		} else if (mLevel <= mMiddleLimit) {
			emptyPaint = mEmptyPaintMiddle;
			solidPaint = mSolidPaintMiddle;			
		} else {
			emptyPaint = mEmptyPaint;
			solidPaint = mSolidPaint;			
		}

        canvas.drawRect(x1, y1, x2, y2, emptyPaint);
        canvas.drawRect(x1, y1, xlevel, y2, solidPaint);
        canvas.drawRect(xx1, yy1, xx2, yy2, solidPaint);

        if (!mLevelText.isEmpty()) {
            mTextPaint.setTextSize((y2 - y1) / 2);
            canvas.drawText(mLevelText, 0, mLevelText.length(), w/2, h * 2 / 3, mTextPaint);
        }

        //Log.d(TAG, String.format("%%: %d, %d, %d, %d", mBodyWidthPercent, mBodyHeightPercent, mCapHeightPercent, mCapWidthPercent));
        //Log.d(TAG, String.format("body: (%4d, %4d)-(%4d, %4d)", x1, y1, x2, y2));
        //Log.d(TAG, String.format("cap:  (%4d, %4d)-(%4d, %4d)", xx1, yy1, xx2, yy2));

        if (DBG_SPACE)
            canvas.drawRect(1, 1, w-1, h-1, emptyPaint);
    }

    // set level in percent [0 ; 100]
    public void setLevel(int lev) {
        mLevel = lev;
        mLevelText = String.format("%3d", mLevel);
        invalidate();
    }

}
