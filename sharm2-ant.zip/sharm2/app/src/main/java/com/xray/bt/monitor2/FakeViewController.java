package com.xray.bt.monitor2;

import android.os.Handler;
import android.os.Vibrator;
import android.os.Message;
import android.content.Context;
import android.util.Log;
import java.util.Random;

public class FakeViewController implements Handler.Callback {
	private IViewController mSink;
	private Handler mHandler;
	private final static int THREAD_DELAY_MS = 500;
	private boolean mExit = false;
	private Random mRandom = new Random(12345);
	private Beeper mBeep = new Beeper(440, 250, 250);
	private Vibrator mVibrator;

	private final static int MSG_WORK_SIGNAL = 1;
    private final static int MSG_RSSI = 2;
    private final static int MSG_BATT = 3;
    private final static int MSG_THRESHOLD = 4;
    private final static int MSG_ALERT = 5;
    private final static int MSG_MODE = 6;

    private final static String[] THRESHOLDS = new String[] { "0,25", "0,4", "1,0", "3,0", "10,0", "30,0", "100", "1000" };
    
    private class RSSI {
        int bd;
        int rr1;
        int rr2;
        int ks;
        int gsm;
    }

    private class Batt {
        int bd;
        int rr;
        int ks;
    }

    private static class Alert {
        public Alert(String t, int c) { text = t; color = c; }
        String text;
        int color;
    }

    private static final Alert[] ALERTS = new Alert[] {
        new Alert("Измерение", 0xff00ee00),
        new Alert("Превышение", 0xffee0000),
        new Alert("Уменьшение", 0xffee0000),
        new Alert("Хищение", 0xffee0000),
    };

    private static final String[] MODES = new String[] { "0 - Измеритель", "1 - Сигнализатор", "2 - Сторож" };

	public FakeViewController(IViewController sink, Context ctx) {
		mSink = sink;
		mVibrator = (Vibrator)ctx.getSystemService(Context.VIBRATOR_SERVICE);
		mHandler = new Handler(this);
		startSimulationThread();
	}

	public void stop() {
		mExit = true;
	}

	public boolean handleMessage(Message msg) {
		switch (msg.what) {
			case MSG_WORK_SIGNAL:
				mSink.onWorkSignal((String)msg.obj);
				break;
            case MSG_RSSI:
                RSSI rssi = (RSSI)msg.obj;                
                mSink.onBdRssiValue(rssi.bd);
                mSink.onRr1RssiValue(rssi.rr1);
                mSink.onRr2RssiValue(rssi.rr2);
                mSink.onKsRssiValue(rssi.ks);
                mSink.onGsmRssiValue(rssi.gsm);
                break;
            case MSG_BATT:
                Batt batt = (Batt)msg.obj;
                mSink.onBdBatteryValue(batt.bd);
                mSink.onRrBatteryValue(batt.rr);
                mSink.onKsBatteryValue(batt.ks);
                break;
            case MSG_THRESHOLD:
                mSink.onThreshold((String)msg.obj);
                break;
            case MSG_ALERT:
                Alert a = (Alert)msg.obj;
                mSink.onAlert(a.text, a.color);
                break;
            case MSG_MODE:
                mSink.onSetMode((String)msg.obj);
                break;
			default:
		}
		return true;
	}

    private void updateRssi() {
        RSSI rssi = new RSSI();
        rssi.bd = mRandom.nextInt(4);
        rssi.rr1 = mRandom.nextInt(4);
        rssi.rr2 = mRandom.nextInt(4);
        rssi.ks = mRandom.nextInt(4);
        rssi.gsm = mRandom.nextInt(4);
		mHandler.obtainMessage(MSG_RSSI, rssi).sendToTarget();
    }

    private void updateBatteries() {
        Batt bat = new Batt();
        bat.bd = mRandom.nextInt(101);
        bat.rr = mRandom.nextInt(101);
        bat.ks = mRandom.nextInt(101);
        mHandler.obtainMessage(MSG_BATT, bat).sendToTarget();
    }

	private void updateWorkSignal() {
		int val = mRandom.nextInt() % 10000000;
		float f = Math.abs((float)val / 100);
		String s;
		if (f < 10)
			s = String.format("%.2f", f);
		else
			s = String.format("%.0f", f);
		mHandler.obtainMessage(MSG_WORK_SIGNAL, s).sendToTarget();
	}

    private void updateThreshold() {
        mHandler.obtainMessage(MSG_THRESHOLD, THRESHOLDS[mRandom.nextInt(8)]).sendToTarget();
    }

    private void updateAlert() {
        mHandler.obtainMessage(MSG_ALERT, ALERTS[mRandom.nextInt(4)]).sendToTarget();
    }

    private void updateMode() {
        mHandler.obtainMessage(MSG_MODE, MODES[mRandom.nextInt(3)]).sendToTarget();
    }

	private void startBeep() {
		mBeep.start();
	}

	private void stopBeep() {
		mBeep.stop();
	}

	private void startVibrate() {
		mVibrator.vibrate(new long[]{500, 500}, 0);
	}

	private void stopVibrate() {
		mVibrator.cancel();
	}	

	private void startSimulationThread() {
		final Thread thread = new Thread() {
				@Override
				public void run() {
					int cnt = 0;
					while (!mExit) {
						sleepMs(THREAD_DELAY_MS);
						
						if (cnt % 3 == 2)
							updateRssi();
						if (cnt % 3 == 0)
                            updateBatteries();
						if (cnt % 4 == 0)
							updateWorkSignal();
						if (cnt % 4 == 2)
							updateThreshold();
						if (cnt % 5 == 0)
							updateAlert();
						if (cnt % 6 == 0)
							updateMode();
						
						if (cnt % 20 == 1)
							startBeep();
						else if (cnt % 20 == 10)
							stopBeep();

						if (cnt % 20 == 5)
							startVibrate();
						else if (cnt % 20 == 15)
							stopVibrate();

						/*if (cnt % 9 == 0)
							startBacklight();
						else if (cnt % 9 == 0)
						stopBacklight();*/

						cnt++;
					}

					stopBeep();
					//stopVibrate();
					//stopBacklight();
				}
			};
		thread.start();
	}

	private void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}
}
