package com.xray.bt.monitor2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;
import android.view.View;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.KeyEvent;
import android.content.Intent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.text.InputType;
import android.content.DialogInterface;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TableRow;
import android.net.Uri;
import android.preference.PreferenceManager;
import java.io.IOException;
import java.util.Random;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

public class BtMonitorActivity extends AppCompatActivity
	implements BtObserver, Handler.Callback, DialogInterface.OnKeyListener,
			   IViewController, ISharmDevice
{
	private final static String TAG = "BtMonitorActivity";
	private final boolean DUMP_LOGCAT = true;
	private final static String APP_VERSION = "1.0";
	private final static String SYS_PIN = "7575";

	private final static int ACTIVITY_THRESHOLD = 2;
	private final static String KEY_DEV_ADDR = "key_dev_addr";

	private final static int ACCESS_DELAY_MS = 500;
	private final static int QUERY_DELAY_MS = 1000;
	private final static int RECONNECT_DELAY_MS = 3000;

	private final static int MAX_RECONNECT_ATTEMPTS = 3;
	private final int MAX_RESEND_ATTEMPTS = 5;

	private final static String PREF_THRESHOLD = "threshold";
    private static final String PREF_ALLOW_VIBRATE = "pref_allow_vibrate";

	private Random mRand = new Random();
	private int mVal;
	private int mLastReceivedThreshold = 0;
	private int mStoredThresholdIdx = -1;

	private IBtManager mBtMgr = new BtManager(this, this, null);
	//private IBtManager mBtMgr = new TcpManager(this, true, false, true, true,
	//    new FoundDevice[]{ new FoundDevice("igorhome(new)", "192.168.88.248:1234")},
	//    new FoundDevice[]{ new FoundDevice("igorhome(paired)", "192.168.88.248:1234")});

	private Handler mHandler = new Handler(this);
	private SocketInterface mSocket = null;
	private String mDevAddr = null;
	private FoundDevice[] mDevList = null;

	private static final int MSG_ENABLED = 1;
	private static final int MSG_DENIED = 2;
	private static final int MSG_ERR_ENAB = 3;
	private static final int MSG_DISCOVERED = 4;
	private static final int MSG_TOAST = 5;
	private static final int MSG_PREPARE_CONN_SHORT = 6;
	private static final int MSG_PREPARE_CONN_LONG = 7;
	private static final int MSG_STRING = 8;
	private static final int MSG_STRING_FATAL = 9;
	private static final int MSG_IO_ERROR = 10;
	private static final int MSG_SHOW_INCOMING = 11;
	private static final int MSG_SHOW_BUSY = 12;
	private static final int MSG_HIDE_BUSY = 13;
	private static final int MSG_SEND_EMAIL = 14;

	private static final int DIALOG_BUSY = 1;
	private static final int DIALOG_CONFIRM_DISCOVERY = 2;
	private ProgressDialog mBusy;
	private Dialog mSomeDialog = null;
	private Menu mMenu = null;

	private static boolean mIsUnlocked;
	private Vibrator mVibrator;
	private boolean mStartingSetup = false;
	private int mReconnectAttemptsLeft;
	private int mResendAttemptsLeft;
	private boolean mAllowVibrate;

	int mAboutDlgKeyCounter;
	private static final int ABOUT_DLG_SETUP_GOAL = 3;
	private AlertDialog mPinDlg;

    private final static int REQUEST_TIMEOUT_MS = 25000; // until we got live_time from user config
    private final static int LIVE_TIMEOUT_MS = 25000;

    private SharmDevice mSharm = new SharmDevice(this, REQUEST_TIMEOUT_MS, null, false);
    private static final boolean CLICK_RUN_TESTS = false;
	private static final boolean SHOW_INCOMING_MSG = true;

	//private FakeViewController viewCtrl;
    private MainViewController mViewCtrl;
    private int mViewCtrlStep = 0;
    private State[] mTestStates;

    private UserConfigAdapter mUserConfigAdapter;
	private SysConfigAdapter mSysConfigAdapter;
	private UserConfig mLastUserConfigToAccept = null;

	private TextView mIncomingText;
	private EditText mRawToSend;
	private EditText mPayloadToSend;

	private TextView mWorkSignal;
	private TextView mPeak;
	private TextView mThreshold;
    private TextView mAlert;
    private TextView mMode;
	private Button mReset;
    private TextView mStatus;
    private TableRow mHardwareLoss;
	private TableRow mIncomingMsgRow;
	private TextView mIncomingMsg;

    private BatteryIndicator mBatteryBd, mBatteryRr, mBatteryKs;
    private SignalIndicator mSignalBd, mSignalRr1, mSignalRr2, mSignalKs, mSignalGsm;

	private Beeper mShortBeep = new Beeper(3000, 500, 500);
	private Beeper mLongBeep = new Beeper(440, 2000, 2000);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//FakeViewController viewCtrl = new FakeViewController(this, this);
        mViewCtrl = new MainViewController(this, this, LIVE_TIMEOUT_MS);

		if (savedInstanceState != null)
			savedInstanceState.getString(KEY_DEV_ADDR, null);

		setContentView(R.layout.activity_main);
        //setContentView(R.layout.activity_tester);
		//setContentView(R.layout.user_setup);

		Toolbar myToolbar = (Toolbar)findViewById(R.id.my_toolbar);
		setSupportActionBar(myToolbar);

		mWorkSignal = (TextView)findViewById(R.id.work_signal);
		mPeak = (TextView)findViewById(R.id.peak);
		mThreshold = (TextView)findViewById(R.id.threshold);
        mAlert = (TextView)findViewById(R.id.alert);

        mBatteryBd = (BatteryIndicator)findViewById(R.id.battery_bd);
        mBatteryRr = (BatteryIndicator)findViewById(R.id.battery_rr);
        mBatteryKs = (BatteryIndicator)findViewById(R.id.battery_ks);

        mSignalBd = (SignalIndicator)findViewById(R.id.rssi_bd);
        mSignalRr1 = (SignalIndicator)findViewById(R.id.rssi_rr1);
        mSignalRr2 = (SignalIndicator)findViewById(R.id.rssi_rr2);
        mSignalKs = (SignalIndicator)findViewById(R.id.rssi_ks);
        mSignalGsm = (SignalIndicator)findViewById(R.id.rssi_gsm);

        mMode = (TextView)findViewById(R.id.mode);

		mReset = (Button)findViewById(R.id.reset);

        mHardwareLoss = (TableRow)findViewById(R.id.hardware_loss);
        mStatus = (TextView)findViewById(R.id.status);

        mUserConfigAdapter = new UserConfigAdapter(this);
		mSysConfigAdapter = new SysConfigAdapter(this);

		mVibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);

		if (SHOW_INCOMING_MSG) {
			mIncomingMsgRow = (TableRow)findViewById(R.id.message_dump_row);
			mIncomingMsg = (TextView)findViewById(R.id.message_dump);
			mIncomingMsgRow.setVisibility(View.VISIBLE);
		}

        mViewCtrl.init();
        initTestStates();
        loadAppSettingsFromPrefs();

        Log.d(TAG, "onCreate done, version = " + Version.TIMESTAMP + " / " + Version.VERSION_STRING);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu ){
		MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
		mMenu = menu;
		mMenu.findItem(R.id.menu_toggle_vibrate).setChecked(mAllowVibrate);
        return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int itemId = item.getItemId();
		if (itemId == R.id.menu_user_setup) {
			requestUserConfig();
			return true;
		} else if (itemId == R.id.menu_sys_setup) {
			requestPin();
			return true;
		} else if (itemId == R.id.menu_about) {
			mAboutDlgKeyCounter = 0;
			new AlertDialog.Builder(this)
					.setMessage(String.format(getString(R.string.about),
							APP_VERSION, Version.VERSION_STRING, Version.TIMESTAMP))
					.setCancelable(true)
					.setOnKeyListener(this)
					.show();
			return true;
		} else if (itemId == R.id.menu_send_logs) {
			if (DUMP_LOGCAT) {
				int saveResult = LogSaver.getAndSave();
				int msgToShow = saveResult == 0 ? R.string.log_success : saveResult;
				Toast.makeText(this, getString(msgToShow), Toast.LENGTH_SHORT).show();
			}
			return true;
		} else if (itemId == R.id.menu_exit) {
            Log.d(TAG, "menu exit");
            onEndBeep();
            onEndVibrate();
			mSharm.stop();
			mSocket.close();
			finish();
			return true;
		} else if (itemId == R.id.menu_toggle_vibrate) {
            mAllowVibrate = !mAllowVibrate;
			Log.d(TAG, "toggle vibrate: " + (mAllowVibrate ? "yes" : "no"));
			item.setChecked(mAllowVibrate);
            saveAppSettingsToPrefs();
			if (!mAllowVibrate)
				onEndVibrate();
            return true;
		} else {
			return super.onOptionsItemSelected(item);
		}
	}

	public static void setUnlocked() {
		mIsUnlocked = true;
	}

	public static boolean isUnlocked() {
		return mIsUnlocked;
	}

    @Override
    protected void onResume() {
		Log.d(TAG, "onResume enter");
		super.onResume();
		checkBluetoothPermissions();

        if (!mBtMgr.isSupported()) {
			Log.e(TAG, "bluetooth is not supported!");
            showMessageAndExit(R.string.bt_not_supp);
			return;
        }

		mBtMgr.subscribe();

		if (CLICK_RUN_TESTS)
			return;
		
		if (mBtMgr.isEnabled()) {
			Log.d(TAG, "bluetooth is enabled");
			if (mSocket != null && mSocket.isAlive()) {
				Log.d(TAG, "starting Sharm");
				mSharm.start(mSocket);
			}
			else {
				Log.d(TAG, "no connections yet, need to connect first");
				mHandler.obtainMessage(MSG_PREPARE_CONN_SHORT).sendToTarget();
			}
		}
		else {
			Log.d(TAG, "bluetooth is not enabled, requesting user ...");
			mBtMgr.requestEnable(BtMonitorActivity.this);
		}
		
		Log.d(TAG, "onResume finish");
	}

    @Override
    protected void onPause() {
		Log.d(TAG, "onPause enter");
		mSharm.stop();
        super.onPause();
		// Если диалог уже открыт — закрываем его
		if (mSomeDialog != null && mSomeDialog.isShowing()) {
			mSomeDialog.dismiss();
		}
		if (!mStartingSetup)
			mIsUnlocked = false;
        mBtMgr.unsubscribe();
		Log.d(TAG, "onPause finish");
	}

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
		outState.putString(KEY_DEV_ADDR, mDevAddr);
		Log.d(TAG, "onSaveInstanceState done");
	}

	@Override 
	public void onDestroy() {
		Log.d(TAG, "onDestroy enter");
		super.onDestroy();
		// Если диалог уже открыт — закрываем его
		if (mSomeDialog != null && mSomeDialog.isShowing()) {
			mSomeDialog.dismiss();
		}
		if (mSocket != null) {
			mSocket.close();
			mSocket = null;
		}
		Log.d(TAG, "onDestroy finish");
	}
	
	@Override
	public void onBackPressed () {
		// no-op
        super.onBackPressed();
    }

	@Override 
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
			case MSG_ENABLED:
				onBluetoothEnabled();
				break;
			case MSG_DENIED:
				onBluetoothDenied();
				break;
			case MSG_ERR_ENAB:
				onBluetoothErrorEnabling();
				break;
			case MSG_DISCOVERED:
				onBluetoothDiscovered((FoundDevice[])msg.obj);
				break;
			case MSG_TOAST:
				Toast.makeText(this, (String)msg.obj,
					Toast.LENGTH_SHORT).show();
				break;
			case MSG_PREPARE_CONN_SHORT:
				prepareForConnection(true);
				break;
			case MSG_PREPARE_CONN_LONG:
				prepareForConnection(false);
				break;
			case MSG_STRING:
				showMessageStr((String)msg.obj);
				break;
			case MSG_STRING_FATAL:
				new AlertDialog.Builder(this)
					.setMessage((Integer)msg.obj)
					.setCancelable(false)
					.setPositiveButton(R.string.button_exit,
						new DialogInterface.OnClickListener() {
							public void onClick(
								DialogInterface dialog, int whichButton)
							{
								finish();
							}
						})
					.show();
				break;
			/*case MSG_SHOW_INCOMING:
				showIncomingMsg((String)msg.obj);
				break;*/
			case MSG_SHOW_BUSY:
				showBusyIndicator();
				break;
			case MSG_HIDE_BUSY:
				hideBusyIndicator();
				break;
			case MSG_SEND_EMAIL:
				sendEmail((String)msg.obj);
				break;				
			default:
		}
		return true;
	}

	private void onBluetoothEnabled() {
		Log.d(TAG, "onBluetoothEnabled");
		if (!mBtMgr.enableWillResumeActivity()) {
			Log.d(TAG, "need to connect first");
			mHandler.obtainMessage(MSG_PREPARE_CONN_SHORT).sendToTarget();
		}
	}

	private void onBluetoothDenied() {
		Log.e(TAG, "onBluetoothDenied");
		showMessageAndExit(R.string.bt_not_enabled);
	}

	private void onBluetoothErrorEnabling() {
		Log.e(TAG, "onBluetoothErrorEnabling");
		showMessageAndExit(R.string.bt_not_enabled_fatal);
	}

	private void onBluetoothDiscovered(FoundDevice[] devices) {
		Log.e(TAG, "onBluetoothDiscovered");
		hideBusyIndicator();
		showNewDevicesDialog(devices);
	}

	private void onKnownDeviceClicked(int index) {
		if (!mBtMgr.isEnabled()) {
			mHandler.obtainMessage(MSG_STRING,
				getString(R.string.bt_suddenly_off)).sendToTarget();
			return;
		}
		showBusyIndicator();
		if (index == mDevList.length)
			mBtMgr.startScanning();
		else {
			tryConnect(mDevList[index].addr);
			hideBusyIndicator();
		}
	}

	private void onNewDeviceClicked(int index) {
		if (!mBtMgr.isEnabled()) {
			mHandler.obtainMessage(MSG_STRING,
				getString(R.string.bt_suddenly_off)).sendToTarget();
			return;
		}
		showBusyIndicator();
		tryConnect(mDevList[index].addr);
		hideBusyIndicator();
	}

	public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_MENU && event.getAction() == KeyEvent.ACTION_UP)
			mAboutDlgKeyCounter++;
		if (mAboutDlgKeyCounter >= ABOUT_DLG_SETUP_GOAL) {
			dialog.dismiss();
			Toast.makeText(this, getString(R.string.service_mode_setup_pending),
				Toast.LENGTH_SHORT).show();
			mAboutDlgKeyCounter = 0;
			Log.d(TAG, "service mode setup");
		}
		return false;
	}

	// BtObserver implementations
    @Override
	public void onEnabled() {
		mHandler.obtainMessage(MSG_ENABLED).sendToTarget();
	}

    @Override
	public void onErrorEnabling() {
		mHandler.obtainMessage(MSG_ERR_ENAB).sendToTarget();
	}

    @Override
	public void onDeniedEnabling() {
		mHandler.obtainMessage(MSG_DENIED).sendToTarget();
	}

    @Override
	public void onDiscoveryFinished(FoundDevice[] devices) {
		mHandler.obtainMessage(MSG_DISCOVERED, devices).
			sendToTarget();
	}

	@Override
    protected Dialog onCreateDialog(int id) {
		if (id == DIALOG_BUSY) {
			mBusy = new ProgressDialog(this);
			mBusy.setMessage(getString(R.string.busy_wait));
			mBusy.setCancelable(false);
			return mBusy;
		}
		else if (id == DIALOG_CONFIRM_DISCOVERY) {
			return new AlertDialog.Builder(this)
				.setMessage(R.string.confirm_discovery)
				.setPositiveButton(R.string.yes,
					new DialogInterface.OnClickListener() {
						public void onClick(
							DialogInterface dialog, int whichButton)
						{
							if (!mBtMgr.isEnabled()) return;
							showBusyIndicator();
							mBtMgr.startScanning();
						}
					})
				.setNegativeButton(R.string.no,
					new DialogInterface.OnClickListener() {
						public void onClick(
							DialogInterface dialog, int whichButton)
						{
							showMessageAndExit(R.string.bt_not_enabled);
						}
					})
				.create();
		}
		return null;
	}

	private boolean prepareForConnection(boolean dialogIfFailed) {
		if (mDevAddr != null) {
			// was connected before, try the same device
			Log.d(TAG, "Connecting to " + mDevAddr);
			mSocket = mBtMgr.connectToDevice(mDevAddr);
			if (mSocket == null) { // could not connect
				Log.e(TAG, "could not connect");
				if (dialogIfFailed) {
					mDevAddr = null;
					showKnownDevicesDialog();
				}
				else {
					mReconnectAttemptsLeft--;
					if (mReconnectAttemptsLeft > 0) {
						mHandler.obtainMessage(MSG_TOAST,
							getString(R.string.reconnection_attempt)).sendToTarget();
						Log.d(TAG, "will try again, " + mReconnectAttemptsLeft + " left");
						launchReconnectThread();
					}
					else {
						mDevAddr = null;
						showKnownDevicesDialog();
					}
				}
			}
			else {
				afterConnected();
				return true;
			}
		}
		else // no previous connections
			showKnownDevicesDialog();
		return false;
	}

	private void tryConnect(String addr) {
		Log.d(TAG, "Connecting to " + addr);
		mSocket = mBtMgr.connectToDevice(addr);
		if (mSocket != null) {
			afterConnected();
			mDevAddr = addr;
		}
		else {
			mDevAddr = null;
			showDialog(DIALOG_CONFIRM_DISCOVERY);
		}
	}

	private void showMessageAndExit(int id) {
		mHandler.obtainMessage(MSG_STRING_FATAL, new Integer(id)).sendToTarget();
	}

	private void launchReconnectThread() {
		final Thread thread = new Thread() {
				@Override
				public void run() {
					sleepMs(RECONNECT_DELAY_MS);
					Log.d(TAG, "reconnect thread: attempt to connect...");
					mHandler.obtainMessage(MSG_PREPARE_CONN_LONG).sendToTarget();
				}
			};
		thread.start();
	}

	private void showMessageStr(String s) {
		new AlertDialog.Builder(this)
			.setMessage(s)
			.setCancelable(true)
			.show();
	}

	private void showKnownDevicesDialog() {
		Log.d(TAG, "showKnownDevicesDialog");
		// Если диалог уже открыт — закрываем его
		if (mSomeDialog != null && mSomeDialog.isShowing()) {
			mSomeDialog.dismiss();
		}

		mDevList = mBtMgr.getPairedDevices();
		if (mDevList == null) {
			showMessageAndExit(R.string.bt_not_enabled);
			return;
		}
		String[] items = new String[mDevList.length + 1];
		for (int i = 0; i < mDevList.length; i++)
			items[i] = mDevList[i].name + " / " +
				mDevList[i].addr.substring(12, mDevList[i].addr.length());
		items[items.length - 1] = getString(R.string.discover_new);
		mSomeDialog = new AlertDialog.Builder(this)
			.setTitle(R.string.known_devices)
			.setItems(items, new DialogInterface.OnClickListener() {
					public void onClick(
						DialogInterface dialog, int whichButton)
					{
						onKnownDeviceClicked(whichButton);
						mSomeDialog.dismiss();
						mSomeDialog = null;
					}
				})
			.setNegativeButton(R.string.button_exit, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						Log.d(TAG, "Known devices dialog dismissed, exiting");
						finish();
					}
				})
			.setOnCancelListener(dialog -> {
				// Очистка, если пользователь закрыл диалог
				mSomeDialog = null;
				})
			.show();
	}

	private void showNewDevicesDialog(FoundDevice[] devices) {
		Log.d(TAG, "showNewDevicesDialog");
		mDevList = devices;
		String[] devicesToShow = new String[devices.length];
		for (int i = 0; i < devices.length; i++)
			devicesToShow[i] = devices[i].name + " / " +
				devices[i].addr.substring(12, devices[i].addr.length());
		mSomeDialog = new AlertDialog.Builder(this)
			.setTitle(R.string.new_devices)
			.setItems(devicesToShow, new DialogInterface.OnClickListener() {
					public void onClick(
						DialogInterface dialog, int whichButton)
					{
						onNewDeviceClicked(whichButton);
						mSomeDialog.dismiss();
						mSomeDialog = null;
					}
				})
			.setNegativeButton(R.string.button_exit, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						Log.d(TAG, "New devices dialog dismissed, exiting");
						finish();
					}
				})
			.show();
	}

	private void showBusyIndicator() {
		showDialog(DIALOG_BUSY);
	}

	private void hideBusyIndicator() {
		mBusy.dismiss();
	}

	private void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}

    @Override
    public void onActivityResult(
		final int requestCode, final int resultCode, final Intent data)
	{
		// Log.d(TAG, String.format("onActivityResult %d %d %s", requestCode, resultCode, data != null ? data.toString() : "null" ));

        super.onActivityResult(requestCode, resultCode, data);
        if (mBtMgr.checkActivityResult(requestCode, resultCode, data))
			return;
		
        if ((resultCode == Activity.RESULT_CANCELED) || (data == null)) {
			mLastUserConfigToAccept = null;
			Log.d(TAG, "activity " + requestCode + " was canceled");
			return;
		}
		
		if (requestCode == ActivityCodes.USER_SETUP) {
			try {
				UserConfig cfg = mUserConfigAdapter.parseUserConfigIntent(data);
				Log.d(TAG, "new user config: " + cfg.toString());
				mLastUserConfigToAccept = cfg;
				mSharm.sendUserConfigSetup(cfg);
                mViewCtrl.requestWriteSent(true);
			} catch (Exception e) {
				Log.e(TAG, "user config invalid: " + e.getMessage());
			}
		} else if (requestCode == ActivityCodes.SYS_SETUP) {
			try {
				SysConfig cfg = mSysConfigAdapter.parseSysConfigIntent(data);
				Log.d(TAG, "new sys config: " + cfg.toString());
				mSharm.sendSysConfigSetup(cfg);
                mViewCtrl.requestWriteSent(true);
			} catch (Exception e) {
				Log.e(TAG, "sys config invalid: " + e.getMessage());
			}
		}
	}

	public void btnResetClicked(View v) {
		mViewCtrl.handleResetPressed();
	}

	public void onThresholdClicked(View v) {
		if (CLICK_RUN_TESTS)
			runViewTests(v);
	}

	public void onAlertClicked(View v) {
		if (CLICK_RUN_TESTS)
			onResetAlertAccepted();
	}	

	public void runViewTests(View v) {
        if (mViewCtrlStep >= mTestStates.length) {
			Toast.makeText(this, "no more tests", Toast.LENGTH_LONG).show();
            return;
        }
        final State s = mTestStates[mViewCtrlStep];
        mViewCtrl.handleState(s);
        mViewCtrlStep++;
	}

	@SuppressLint("LongLogTag")
    private void sendEmail(String text) {
		String[] TO = {"i.bezzubchenko@securitycode.ru"};
		Intent emailIntent = new Intent(Intent.ACTION_SEND);
      
		emailIntent.setData(Uri.parse("mailto:"));
		emailIntent.setType("text/plain");
		emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
		emailIntent.putExtra(Intent.EXTRA_SUBJECT, "SHARM test results");
		emailIntent.putExtra(Intent.EXTRA_TEXT, text);
      
		try {
			startActivity(Intent.createChooser(emailIntent, "Send mail..."));
			finish();
			Log.d("Finished sending email...", "");
		} catch (android.content.ActivityNotFoundException ex) {
			Toast.makeText(BtMonitorActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
		}		
	}

	private void dumpBuf(String prefix, byte[] data) {
        Log.d(TAG, "buffer: " + prefix + ": " + HexUtils.bytesToHexString(data, 0));
	}

	private void afterConnected() {
		Log.d(TAG, "successfully connected");
        mViewCtrl.startFirstStateTimer();
		mSharm.start(mSocket);
		mReconnectAttemptsLeft = MAX_RECONNECT_ATTEMPTS;
		mResendAttemptsLeft = MAX_RESEND_ATTEMPTS;
	}

    private void afterDisconnected() {
        Log.d(TAG, "after disconnected");
        mSharm.stop();
        mViewCtrl.stop();
    }

    private void requestUserConfig() {
		if (!mSharm.sendUserConfigRequest()) {
			mHandler.obtainMessage(MSG_TOAST,
				getString(R.string.user_req_not_sent)).sendToTarget();
			Log.e(TAG, "could not send user config request");
		}
		else {
			Log.i(TAG, "user config request sent");
            mViewCtrl.requestReadSent();
        }
    }

    private void requestSysConfig() {
		if (!mSharm.sendSysConfigRequest()) {
			mHandler.obtainMessage(MSG_TOAST,
				getString(R.string.sys_req_not_sent)).sendToTarget();
			Log.e(TAG, "could not send sys config request");
		}
		else {
			Log.i(TAG, "sys config request sent");
            mViewCtrl.requestReadSent();
        }
    }

    private void showIncorrectIncomingParamMsg(String paramName) {
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.invalid_param_received)).sendToTarget();		
    }

	private void requestPin() {
		if (mPinDlg == null) {
			final EditText pinEdit = new EditText(this);
			pinEdit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			mPinDlg = new AlertDialog.Builder(this)
				.setTitle(R.string.pin_dlg_title)
				.setMessage(R.string.pin_dlg_message)
				.setView(pinEdit)
				.setPositiveButton(R.string.pin_dlg_enter, new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							final String entered_pin = pinEdit.getText().toString();
							if (entered_pin.equals(SYS_PIN))
								requestSysConfig();
							else
								Toast.makeText(BtMonitorActivity.this, getString(R.string.pin_incorrect), Toast.LENGTH_SHORT).show();
						}
					})
				.setNegativeButton(R.string.pin_dlg_cancel, null)
				.create();
		}
		mPinDlg.show();
	}

	// IViewController implementations

	public void onWorkSignal(String text) {
		mWorkSignal.setText(text);
	}

    public void onBdBatteryValue(int level) {
        mBatteryBd.setLevel(level);
    }
    
	public void onRrBatteryValue(int level) {
        mBatteryRr.setLevel(level);
    }
    
	public void onKsBatteryValue(int level) {
        mBatteryKs.setLevel(level);
    }

	public void onBdRssiValue(int level) {
        mSignalBd.setLevel(level);
    }
    
	public void onRr1RssiValue(int level) {
        mSignalRr1.setLevel(level);
    }
    
	public void onRr2RssiValue(int level) {
        mSignalRr2.setLevel(level);
    }
    
	public void onKsRssiValue(int level) {
        mSignalKs.setLevel(level);
    }
    
	public void onGsmRssiValue(int level) {
        mSignalGsm.setLevel(level);
    }

	public void onRrLineVisibility(boolean showBat, boolean showRssi1, boolean showRssi2) {
		mBatteryRr.setVisibility(showBat ? View.VISIBLE : View.INVISIBLE);
		mSignalRr1.setVisibility(showRssi1 ? View.VISIBLE : View.INVISIBLE);
		mSignalRr2.setVisibility(showRssi2 ? View.VISIBLE : View.INVISIBLE);
	}

    public void onThreshold(String text) {
        mThreshold.setText(text);
    }

    public void onAlert(String text, int color) {
        mAlert.setTextColor(color);
        mAlert.setText(text);
    }

    public void onSetMode(String text) {
        mMode.setText(text);
    }

	public void onPeakText(String text) {
		mPeak.setText(text);
	}

	public void onStartShortBeep() {
		mLongBeep.stop();
		mShortBeep.start();
	}
	
	public void onStartLongBeep() {
		mShortBeep.stop();
		mLongBeep.start();
	}
    
	public void onEndBeep() {
		mShortBeep.stop();
		mLongBeep.stop();
    }

	public void onStartVibrate() {
		if (mAllowVibrate)
			mVibrator.vibrate(new long[]{500, 500}, 0);
    }
    
	public void onEndVibrate() {
		mVibrator.cancel();
    }

    public void onShowHeaderStatus() {
        Log.d(TAG, "showHeader");
        mHardwareLoss.setVisibility(View.VISIBLE);
    }
    
    public void onHideHeaderStatus() {
        Log.d(TAG, "hideHeader");
        mHardwareLoss.setVisibility(View.INVISIBLE);
    }
    
    public void onSetFooter(String text) {
        Log.d(TAG, "setFooter => " + text);
        mStatus.setText(text);
    }

	public void onTestName(String title) {
		if (title != null)
			mIncomingMsg.setText(title);
	}

	public void onSharmMessageOnMainThread(byte[] data) {
		mIncomingMsg.setText(HexUtils.bytesToHexString(data, 0));
	}

	public void onSendReset() {
		if (!CLICK_RUN_TESTS) {
			if (!mSharm.sendResetAlert())
				Toast.makeText(this, getString(R.string.reset_not_sent), Toast.LENGTH_LONG).show();
			else
				mViewCtrl.requestWriteSent(false);
		}
		else
			mViewCtrl.requestWriteSent(false);
	}
	
	public void onNothingToResetWarning() {
		Toast.makeText(this, getString(R.string.nothing_to_reset), Toast.LENGTH_LONG).show();
	}

    // ISharmDevice implementations

    public void onStateReceived(State s) {
		Log.d(TAG, "state");
		mViewCtrl.handleState(s);
    }
    
    public void onUserConfigReceived(UserConfig cfg) {
        try {
            mViewCtrl.requestAckdOrLost();
            mViewCtrl.handleUserConfig(cfg);
            mSharm.setRequestTimeout(MainViewController.requestTimeoutMsFromMode(cfg.mode, cfg.liveTime));
			Log.d(TAG, "user config received: " + cfg.toString());
            Intent ucfg_intent = mUserConfigAdapter.createUserConfigIntent(cfg, UserSetupActivity.class);
            startActivityForResult(ucfg_intent, ActivityCodes.USER_SETUP);
        } catch (Exception e) {
            Log.e(TAG, "incorrect user setup parameter: " + e.getMessage());
            showIncorrectIncomingParamMsg(e.getMessage());
        }
    }
    
    public void onSysConfigReceived(SysConfig cfg) {
        try {
            mViewCtrl.requestAckdOrLost();
			Log.d(TAG, "sys config received: " + cfg.toString());
            Intent scfg_intent = mSysConfigAdapter.createSysConfigIntent(cfg, SysSetupActivity.class);
            startActivityForResult(scfg_intent, ActivityCodes.SYS_SETUP);
        } catch (Exception e) {
            Log.e(TAG, "incorrect sys setup parameter: " + e.getMessage());
            showIncorrectIncomingParamMsg(e.getMessage());
        }
    }

    public void onUserConfigAccepted() {
		Log.d(TAG, "user config accepted");
        mViewCtrl.requestAckdOrLost();
		if (mLastUserConfigToAccept != null) {
			mViewCtrl.handleUserConfig(mLastUserConfigToAccept);
            mSharm.setRequestTimeout(
                MainViewController.requestTimeoutMsFromMode(
                    mLastUserConfigToAccept.mode, mLastUserConfigToAccept.liveTime));
			mLastUserConfigToAccept = null;
		}
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.user_cfg_accepted)).sendToTarget();
    }

    public void onSysConfigAccepted() {
		Log.d(TAG, "sys config accepted");
        mViewCtrl.requestAckdOrLost();
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.sys_cfg_accepted)).sendToTarget();
    }

	public void onResetAlertAccepted() {
		Log.d(TAG, "reset alert accepted");
		mViewCtrl.requestAckdOrLost();
		mViewCtrl.handleResetAlertAccepted();
	}
    
    public void onSocketError() { // sharm is already stopped here
		Log.e(TAG, "socket error");
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.socket_err)).sendToTarget();
        afterDisconnected();
		launchReconnectThread();
    }
    
    public void onParseError(String msg) { // sharm is already stopped here
		Log.e(TAG, "parse error: " + msg);
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.parse_err)).sendToTarget();
        afterDisconnected();
		launchReconnectThread();
    }

    public void onResponseTooLate() {
		Log.e(TAG, "response too late");
        mViewCtrl.requestAckdOrLost();
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.rsp_too_late)).sendToTarget();
    }

    public void onResponseTimeout() {
		Log.e(TAG, "response timed out");
        mViewCtrl.requestAckdOrLost();
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.rsp_timeout)).sendToTarget();
    }
    
    public void onResponseMismatch() {
		Log.e(TAG, "response mismatch");
        mViewCtrl.requestAckdOrLost();
		mHandler.obtainMessage(MSG_TOAST,
			getString(R.string.rsp_mismatch)).sendToTarget();
    }

	public void onSharmMessage(byte[] data) {
		if (SHOW_INCOMING_MSG)
			mViewCtrl.sharmMessage(data);
	}

    private void initTestStates() {
        mTestStates = new State[] {
			/*stateForSignal(127F, 1, false),
			stateForSignal(124F, 1, false),
			stateForSignal(126F, 1, false),
			stateForSignal(9F, 1, false),
			stateForSignal(0.5F, 0, false),
			
			stateForSignal(1119F, 2, true),
			stateForSignal(1118F, 2, true),
			stateForSignal(1117F, 2, true),
			// measure mode, signal is below
			stateForSignal(0.5F, 0, false),
			stateForSignal(0.5F, 0, true),
			stateForSignal(0.5F, 0, false),
			// measure mode, signal is above
			stateForSignal(100F, 0, false),
			stateForSignal(100F, 0, true),
			stateForSignal(100F, 0, false),
			// signaller mode, signal is below
			stateForSignal(0.6F, 1, false),
			stateForSignal(0.7F, 1, true),
			stateForSignal(0.8F, 1, false),
			// signaller mode, signal is above
			stateForSignal(129F, 1, false),
			stateForSignal(126F, 1, true),
			stateForSignal(127F, 1, false),
			stateForSignal(124F, 1, false),
			stateForSignal(126F, 1, false),
			stateForSignal(123F, 1, false),
			stateForSignal(128F, 1, false),
			stateForSignal(126F, 1, false),
			// watchdog mode, signal is below
			stateForSignal(6F, 2, false),
			stateForSignal(9F, 2, true),
			stateForSignal(7F, 2, false),
			stateForSignal(8F, 2, false),
			stateForSignal(7F, 2, false),
			stateForSignal(5F, 2, false),
			stateForSignal(6F, 2, false),
			stateForSignal(9F, 2, false),
			// intermix signaller & watchdog
			stateForSignal(7F, 2, false),
			stateForSignal(120F, 1, false),
			stateForSignal(8F, 2, false),
			stateForSignal(130F, 1, false),
			// intermix everything
			stateForSignal(11F, 0, false),
			stateForSignal(11F, 1, false),
			stateForSignal(9F, 1, false),
			stateForSignal(11F, 1, false),
			stateForSignal(11F, 2, false),
			stateForSignal(9F, 2, false),
			stateForSignal(11F, 2, false),
			stateForSignal(11F, 0, false),
			// all is ok
			stateForSignal(0.5F, 0, false),*/
            new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, false, "all ok 1"),
            new State(0.5F,
				15, 0, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, false, "battery RR alert"),
            new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, false, "no battery RR alert"),
			new State(500,
				13, 14, 15,
				2, 3, 2, 3, 14,
				8, 0, 0, false, "bad thrshld 1"),
			new State(50000,
				13, 14, 15,
				2, 3, 2, 3, 14,
				8, 0, 0, false, "bad thrshld 2"),
			new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, true, "gyro alert"),
			new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, false, "gyro no alert"),            
			new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 14,
				0, 0, 0, false, "0.5>0.25, mode0"),
			new State(100.0F,
				8, 9, 10,
				3, 3, 2, 2, 13,
				3, 0, 0, false, "100>3, mode0"),
			new State(100.0F,
				8, 9, 10,
				3, 3, 2, 2, 14,
				3, 0, 1, false, "100>3, mode1"),
			new State(2.0F,
				8, 9, 10,
				3, 3, 2, 2, 10,
				3, 0, 2, false, "2<3, mode2"),
			new State(0.5F,
				8, 9, 1,
				3, 3, 2, 2, 10,
				6, 0, 2, false, "KS batt low"),
			new State(500,
				13, 14, 15,
				2, 3, 2, 3, 13,
				7, 0, 0, false, "all ok"),
			new State(0.5F,
				1, 9, 10,
				2, 3, 3, 2, 14,
				6, 0, 2, false, "BD batt low"),
			new State(0.5F,
				6, 2, 10,
				2, 3, 3, 2, 13,
				6, 0, 2, false, "KS batt low"),			
			new State(500,
				13, 14, 15,
				2, 3, 2, 3, 14,
				7, 0, 0, false, "all ok"),
			new State(500,
				13, 14, 15,
				2, 3, 2, 3, 5,
				7, 0, 0, false, "GSM RSSI low"),
			new State(0.27F,
				13, 14, 15,
				2, 3, 2, 3, 14,
				4, 0, 0, false, "all ok"),
			new State(50,
				13, 14, 15,
				0, 3, 2, 3, 12,
				7, 0, 0, false, "BD RSSI low"),
			new State(0.27F,
				13, 14, 15,
				2, 3, 2, 3, 14,
				4, 0, 0, false, "all ok"),
			new State(500,
				13, 14, 15,
				2, 3, 2, 0, 15,
				7, 0, 0, false, "KS RSSI low"),
			new State(0.27F,
				13, 14, 15,
				2, 3, 2, 3, 14,
				5, 0, 0, false, "all ok"),
			new State(500,
				13, 14, 15,
				2, 3, 0, 3, 14,
				7, 0, 0, false, "RR2 RSSI low"),
			new State(0.27F,
				13, 14, 15,
				2, 3, 2, 3, 14,
				3, 0, 0, false, "all ok"),
			new State(500,
				13, 14, 15,
				2, 0, 2, 3, 15,
				7, 0, 0, false, "RR1 RSSI low"),
			new State(0.27F,
				13, 14, 15,
				2, 3, 2, 3, 13,
				4, 0, 0, false, "all ok"),
			new State(500,
				13, 0, 15,
				2, 0, 0, 3, 15,
				7, 0, 0, false, "RR is absent (no alert, hide line)"),
        };
    }

	private State stateForSignal(float signal, int mode, boolean gyro) {
		return new State(signal, 15, 14, 13, 3, 2, 3, 2, 15, 4, 0, mode, gyro,
			String.format("mode%d s=%.2f thres=[4]/10.0 gyro=%s",
				mode, signal, gyro ? "Y" : "N"));
	}

    private void loadAppSettingsFromPrefs() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        mAllowVibrate = sharedPref.getBoolean(PREF_ALLOW_VIBRATE, true);
		if (mMenu != null)
			mMenu.findItem(R.id.menu_toggle_vibrate).setChecked(mAllowVibrate);
    }

    private void saveAppSettingsToPrefs() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPref.edit();
		editor.putBoolean(PREF_ALLOW_VIBRATE, mAllowVibrate);
        editor.commit();
    }

	private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1;

	private void checkBluetoothPermissions() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // Android 12+
			if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
					ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {

				ActivityCompat.requestPermissions(this,
						new String[]{
								Manifest.permission.BLUETOOTH_CONNECT,
								Manifest.permission.BLUETOOTH_SCAN
						},
						REQUEST_BLUETOOTH_PERMISSIONS);
			} else {
				// Разрешения уже есть — можно работать с Bluetooth
				prepareForConnection(true);
			}
		} else {
			// Для Android < 12 — достаточно BLUETOOTH и BLUETOOTH_ADMIN
			prepareForConnection(true);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);

		if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
			if (grantResults.length > 0 &&
					grantResults[0] == PackageManager.PERMISSION_GRANTED &&
					grantResults[1] == PackageManager.PERMISSION_GRANTED) {
				prepareForConnection(true);
			} else {
				Toast.makeText(this, "Разрешения Bluetooth отклонены", Toast.LENGTH_SHORT).show();
			}
		}
	}
}

