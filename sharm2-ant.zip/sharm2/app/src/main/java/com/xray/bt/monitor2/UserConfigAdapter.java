package com.xray.bt.monitor2;

import android.content.res.Resources;
import android.content.Intent;
import android.content.Context;
import android.util.Log;

public class UserConfigAdapter {

    private String[] mThresholds, mGyroSens, mGsm, mModes;
    private String mLiveTimeName, mThresholdName, mGyroSensName, mGsmName, mModeName;
    private Context mContext;

    public UserConfigAdapter(Context context) {
        mContext = context;
        Resources rs = context.getResources();

		mLiveTimeName = rs.getString(R.string.live_time);
        mThresholdName = rs.getString(R.string.threshold);
        mGyroSensName = rs.getString(R.string.gyro_sens);
        mGsmName = rs.getString(R.string.gsm_mode);
        mModeName = rs.getString(R.string.mode);
                
        mThresholds = rs.getStringArray(R.array.thresholds);
        mGyroSens = rs.getStringArray(R.array.gyro_sensivities);
        mGsm = rs.getStringArray(R.array.gsm_modes);
        mModes = rs.getStringArray(R.array.modes);
    }

    public Intent createUserConfigIntent(UserConfig cfg, Class target_class) {
        Intent intent = new Intent();
        if (target_class != null)
            intent.setClass(mContext, target_class);
		
		intent.putExtra(UserConfig.LIVE_TIME, cfg.liveTime);
		if (cfg.liveTime < 10 || cfg.liveTime > 3600)
			intent.putExtra(UserConfig.LIVE_TIME_FB, 10);
		
		putParam(intent, cfg.threshold, mThresholds, UserConfig.THRESHOLD, UserConfig.THRESHOLD_FB);
		putParam(intent, cfg.gyroSens, mGyroSens, UserConfig.GYRO_SENS, UserConfig.GYRO_SENS_FB);
		putParam(intent, cfg.gsm, mGsm, UserConfig.GSM, UserConfig.GSM_FB);
		putParam(intent, cfg.mode, mModes, UserConfig.MODE, UserConfig.MODE_FB);
		
        return intent;
    }

    public UserConfig parseUserConfigIntent(Intent intent) throws Exception {
		UserConfig cfg = new UserConfig();

		cfg.liveTime = intent.getIntExtra(UserConfig.LIVE_TIME, -1);
		if (cfg.liveTime == -1)
			throw new Exception(mLiveTimeName);

		cfg.threshold = findIndex(intent.getStringExtra(UserConfig.THRESHOLD), mThresholds, mThresholdName);
		cfg.gyroSens = findIndex(intent.getStringExtra(UserConfig.GYRO_SENS), mGyroSens, mGyroSensName);
		cfg.gsm = findIndex(intent.getStringExtra(UserConfig.GSM), mGsm, mGsmName);
		cfg.mode = findIndex(intent.getStringExtra(UserConfig.MODE), mModes, mModeName);

		return cfg;
    }

    public static String validate(UserConfig cfg, Context ctx) {
        if (cfg.liveTime >= 0 && cfg.liveTime <= 3600)
            return null;
        else
            return ctx.getString(R.string.live_time);
    }

	private int findIndex(String s, String[] arr, String throwString) throws Exception {
		for (int i = 0; i < arr.length; i++) {
			if (s.equals(arr[i]))
				return i;
		}
		throw new Exception(throwString);
	}

	private void putParam(Intent intent, int index, String[] values, String key, String fallbackKey) {
        if (index < 0 || index >= values.length) {
			intent.putExtra(key, String.format("%d (!)", index));
			intent.putExtra(fallbackKey, values[0]);
		}
		else
			intent.putExtra(key, values[index]);
	}
    
}
