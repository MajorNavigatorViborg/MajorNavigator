package com.xray.bt.monitor2;

public class ActivityCodes {
	public static final int USER_SETUP = 1;
	public static final int SYS_SETUP = 2;
	public static final int ENABLE_BT = 3;
}
