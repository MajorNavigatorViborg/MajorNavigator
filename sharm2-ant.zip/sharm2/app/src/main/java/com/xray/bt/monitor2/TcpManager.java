package com.xray.bt.monitor2;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.os.StrictMode;

public class TcpManager implements IBtManager {
	private final static String TAG = "BtTcpManager";
    private static final int ENABLE_RESULT_AFTER_MS = 1000;
    private static final int SCAN_RESULT_AFTER_MS = 1200;

    BtObserver mObserver;
    private boolean mEnabled;
    private boolean mSupported;
    private boolean mCanEnable;
    private boolean mCanConnect;
    private FoundDevice[] mScannedDevs, mPairedDevs;

	private boolean mIsEnabling;

    public TcpManager(BtObserver obs,
        boolean supported, boolean alreadyEnabled, boolean canEnable, boolean canConnect,
        FoundDevice[] scannedDevices, FoundDevice[] pairedDevices)
    {
        mObserver = obs;
        mSupported = supported;
        mEnabled = alreadyEnabled;
        mCanEnable = canEnable;
        mCanConnect = canConnect;
        mScannedDevs = scannedDevices;
        mPairedDevs = pairedDevices;
		mIsEnabling = false;

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
    }

	public boolean enableWillResumeActivity() {
		return false;
	}

    public boolean isSupported() {
        Log.d(TAG, "isSupported => " + mSupported);
        return mSupported;
    }

    public boolean isEnabled() {
        boolean ret = mSupported && mEnabled;
        Log.d(TAG, "isEnabled => " + ret);
        return ret;
    }

    public void requestEnable(Activity activity) {
        Log.d(TAG, "requestEnable");
		mIsEnabling = true;
		final Thread thread = new Thread() {
				@Override
				public void run() {
					sleepMs(ENABLE_RESULT_AFTER_MS);
					mIsEnabling = false;
                    if (mSupported && mCanEnable) {
                        mEnabled = true;
                        Log.d(TAG, "simulating enabled");
                        mObserver.onEnabled();
                    }
                    else {
                        mEnabled = false;
                        Log.d(TAG, "simulating enable fail");
                        mObserver.onErrorEnabling();
                    }
				}
			};
		thread.start();        
    }

	public boolean checkActivityResult(int requestCode, int resultCode, Intent data) {
		return false; // we don't ask user anyhow
	}

    public void subscribe() {
        Log.d(TAG, "subscribe (no-op)");
        // nothing
    }

    public void unsubscribe() {
        Log.d(TAG, "ubsubscribe (no-op)");
        // nothing
    }

    public void startScanning() {
        Log.d(TAG, "startScanning");
        assert mSupported && mEnabled;
		final Thread thread = new Thread() {
				@Override
				public void run() {
					sleepMs(SCAN_RESULT_AFTER_MS);
                    Log.d(TAG, "simulating discovered devices");
                    mObserver.onDiscoveryFinished(mScannedDevs);
                }
            };
        thread.start();
    }

    public SocketInterface connectToDevice(String addr) {
        Log.d(TAG, "connectToDevice " + addr);
        assert mEnabled;
        int colon = addr.indexOf(':');
        if (colon == -1)
            return null;
        String host_addr = addr.substring(0, colon);
        String port_str = addr.substring(colon+1, addr.length());
        int port;
        try {
            port = Integer.parseInt(port_str);
        } catch (NumberFormatException e) {
            return null;
        }
		Log.d(TAG, "connecting " + host_addr + ":" + port);
        TcpSocket sock = new TcpSocket(host_addr, port);
        if (sock.connect())
            return sock;
        else
            return null;
    }

    public FoundDevice[] getPairedDevices() {
        Log.d(TAG, "simulating paired devices list");
        return mPairedDevs;
    }

	private void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}    

}
