package com.xray.bt.monitor2;

public enum Transaction {
    NONE,
    USER_CFG_READ,
    SYS_CFG_READ,
    USER_CFG_WRITE,
    SYS_CFG_WRITE,
	RESET_ALERT,
    UNKNOWN,
};
