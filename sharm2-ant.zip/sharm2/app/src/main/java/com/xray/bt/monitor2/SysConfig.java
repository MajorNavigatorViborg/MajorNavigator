package com.xray.bt.monitor2;

public class SysConfig {
	public static final String COMP_THRESHOLD = "sys_cfg_comp_threshold";
	public static final String HIGH_VOLTAGE = "sys_cfg_high_voltage";
	public static final String REF_VOLTAGE = "sys_cfg_ref_voltage";
	public static final String ADC_COEF = "sys_cfg_adc_coef";
	public static final String CNT_CHAN_COEF = "sys_cfg_cnt_chan_coef";
	public static final String INT_CHAN_COEF = "sys_cfg_int_chan_coef";
	public static final String CNT_INT_THRESHOLD = "sys_cfg_cnt_int_threshold";
	public static final String EXP_TIME = "sys_cfg_exp_time";

	public static final String COMP_THRESHOLD_FB = "sys_cfg_comp_threshold_fb";
	public static final String HIGH_VOLTAGE_FB = "sys_cfg_high_voltage_fb";
	public static final String REF_VOLTAGE_FB = "sys_cfg_ref_voltage_fb";
	public static final String ADC_COEF_FB = "sys_cfg_adc_coef_fb";
	public static final String CNT_CHAN_COEF_FB = "sys_cfg_cnt_chan_coef_fb";
	public static final String INT_CHAN_COEF_FB = "sys_cfg_int_chan_coef_fb";
	public static final String CNT_INT_THRESHOLD_FB = "sys_cfg_cnt_int_threshold_fb";
	public static final String EXP_TIME_FB = "sys_cfg_exp_time_fb";

	public SysConfig() {
		compThreshold = -1;
		highVoltage = -1;
		refVoltage = -1;
		adcCoef = -1;
		cntChannelCoef = -1;
		intChannelCoef = -1;
		cntIntThreshold = -1;
		expTime = -1;
	}

	public SysConfig(int cmp, int high, int ref, int adc, int cntc, int intc, int cntint, int exp) {
		compThreshold = cmp;
		highVoltage = high;
		refVoltage = ref;
		adcCoef = adc;
		cntChannelCoef = cntc;
		intChannelCoef = intc;
		cntIntThreshold = cntint;
		expTime = exp;
	}

	public String toString() {
		return String.format("compThreshold=%d, highVoltage=%d, refVoltage=%d, adcCoef=%d, cntChannelCoef=%d, intChannelCoef=%d, cntIntThreshold=%d, expTime=%d",
			compThreshold, highVoltage, refVoltage, adcCoef, cntChannelCoef, intChannelCoef, cntIntThreshold, expTime);
	}
	
	int compThreshold;
	int highVoltage;
	int refVoltage;
	int adcCoef;
	int cntChannelCoef;
	int intChannelCoef;
	int cntIntThreshold;
	int expTime;
}
