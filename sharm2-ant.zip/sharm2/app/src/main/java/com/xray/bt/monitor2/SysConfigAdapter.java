package com.xray.bt.monitor2;

import android.content.res.Resources;
import android.content.Intent;
import android.content.Context;
import android.util.Log;

public class SysConfigAdapter {
	private static final boolean SIMULATE_OVERFLOW = false;
    private Context mContext;

    public SysConfigAdapter(Context context) {
        mContext = context;
    }

    public Intent createSysConfigIntent(SysConfig cfg, Class target_class) throws Exception {
        Intent intent = new Intent();
        if (target_class != null)
            intent.setClass(mContext, target_class);

        putParam(intent, cfg.compThreshold, 0, 0xFF, SysConfig.COMP_THRESHOLD, SysConfig.COMP_THRESHOLD_FB);
		putParam(intent, cfg.highVoltage, 0, 0xFFFF, SysConfig.HIGH_VOLTAGE, SysConfig.HIGH_VOLTAGE_FB);
		putParam(intent, cfg.refVoltage, 0, 0xFFFF, SysConfig.REF_VOLTAGE, SysConfig.REF_VOLTAGE_FB);
		putParam(intent, cfg.adcCoef, 0, 0xFFFF, SysConfig.ADC_COEF, SysConfig.ADC_COEF_FB);
		putParam(intent, cfg.cntChannelCoef, 0, 0xFF, SysConfig.CNT_CHAN_COEF, SysConfig.CNT_CHAN_COEF_FB);
		putParam(intent, cfg.intChannelCoef, 0, 0xFF, SysConfig.INT_CHAN_COEF, SysConfig.INT_CHAN_COEF_FB);
		putParam(intent, cfg.cntIntThreshold, 0, 0xFF, SysConfig.CNT_INT_THRESHOLD, SysConfig.CNT_INT_THRESHOLD_FB);
		putParam(intent, cfg.expTime, 0, 0xFFFF, SysConfig.EXP_TIME, SysConfig.EXP_TIME_FB);

        return intent;
    }

    public SysConfig parseSysConfigIntent(Intent intent) throws Exception {
		SysConfig cfg = new SysConfig();

		cfg.compThreshold = findIntValue(intent, SysConfig.COMP_THRESHOLD);
		cfg.highVoltage = findIntValue(intent, SysConfig.HIGH_VOLTAGE);
		cfg.refVoltage = findIntValue(intent, SysConfig.REF_VOLTAGE);
		cfg.adcCoef = findIntValue(intent, SysConfig.ADC_COEF);        		
		cfg.cntChannelCoef = findIntValue(intent, SysConfig.CNT_CHAN_COEF);
		cfg.intChannelCoef = findIntValue(intent, SysConfig.INT_CHAN_COEF);
		cfg.cntIntThreshold = findIntValue(intent, SysConfig.CNT_INT_THRESHOLD);
		cfg.expTime = findIntValue(intent, SysConfig.EXP_TIME);

		return cfg;
    }

	public static String validate(SysConfig cfg, Context ctx) {
		if (cfg.compThreshold < 0 || cfg.compThreshold > 0xFF)
			return ctx.getString(R.string.comp_threshold);
		if (cfg.highVoltage < 0 || cfg.highVoltage > 0xFFFF)
			return ctx.getString(R.string.high_voltage);
		if (cfg.refVoltage < 0 || cfg.refVoltage > 0xFFFF)
			return ctx.getString(R.string.ref_voltage);
		if (cfg.adcCoef < 0 || cfg.adcCoef > 0xFFFF)
			return ctx.getString(R.string.adc_coef);
		if (cfg.cntChannelCoef < 0 || cfg.cntChannelCoef > 0xFF)
			return ctx.getString(R.string.cnt_chan_coef);
		if (cfg.intChannelCoef < 0 || cfg.intChannelCoef > 0xFF)
			return ctx.getString(R.string.int_chan_coef);
		if (cfg.cntIntThreshold < 0 || cfg.cntIntThreshold > 0xFF)
			return ctx.getString(R.string.cnt_int_threshold);
		if (cfg.expTime < 0 || cfg.expTime > 0xFFFF)
			return ctx.getString(R.string.exp_time);
		return null;
	}

	private int findIntValue(Intent intent, String key) throws Exception {
		int val = intent.getIntExtra(key, -1);
		if (val == -1)
			throw new Exception("sys config missing value");
		return val;
	}

	private void putParam(Intent intent, int value, int minVal, int maxVal, String key, String fallbackKey) {
		if (SIMULATE_OVERFLOW)
			value = value * 100;
		intent.putExtra(key, value);
		if (value < minVal || value > maxVal) {
			intent.putExtra(fallbackKey, minVal);
		}
	}
}
