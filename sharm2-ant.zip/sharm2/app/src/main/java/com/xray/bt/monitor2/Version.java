package com.xray.bt.monitor2;
public class Version {
public static final String VERSION_STRING = "3d6d611";
public static final String TIMESTAMP = "2018-07-19 00:44:08";
}
