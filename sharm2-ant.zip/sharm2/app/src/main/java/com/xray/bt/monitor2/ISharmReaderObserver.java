package com.xray.bt.monitor2;

public interface ISharmReaderObserver {

	public void onMessage(byte[] data);

	public void onParseError(String what);
	
}

