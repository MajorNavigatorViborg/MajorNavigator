package com.xray.bt.monitor2;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.util.Log;
import android.bluetooth.BluetoothSocket;

public class BtSocket implements SocketInterface {

	private BluetoothSocket mSocket;
	private InputStream mInStream;
	private OutputStream mOutStream;
    private static final String TAG = "BtSocket";

	public BtSocket(BluetoothSocket socket) {
		mSocket = socket;
		mInStream = null;
		mOutStream = null;
	}

	public boolean connect() {
		InputStream tmpIn = null;
		OutputStream tmpOut = null;

		try {
			mSocket.connect();
			tmpIn = mSocket.getInputStream();
			tmpOut = mSocket.getOutputStream();
		} catch (IOException e) {
			Log.e(TAG, "could not connect", e);
			return false;
		}

		mInStream = tmpIn;
		mOutStream = tmpOut;
		Log.d(TAG, "socket connected");
		return true;
	}
	
	public void write(byte[] buffer) throws IOException {
		mOutStream.write(buffer);
		mOutStream.flush();
		Log.d(TAG, "wrote " + HexUtils.bytesToHexString(buffer, 0));
	}

	public int read(byte[] buffer) throws IOException {
		return mInStream.read(buffer);
	}

	public void close() {
		try {
			mSocket.close();
		} catch (IOException e) {
			Log.w(TAG, "could not close socket", e);
		}
	}

	public int bytesAvailable() throws IOException {
		return mInStream.available();
	}

	public boolean isAlive() {
		return mSocket != null && mSocket.isConnected();
	}
}
