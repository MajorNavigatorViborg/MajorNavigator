package com.xray.bt.monitor2;

public interface BtObserver {

	public void onEnabled();

	public void onErrorEnabling();

	public void onDeniedEnabling();

	public void onDiscoveryFinished(FoundDevice[] devices);

}
