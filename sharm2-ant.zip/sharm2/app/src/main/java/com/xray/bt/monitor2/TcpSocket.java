package com.xray.bt.monitor2;

import java.net.Socket;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.util.Log;

public class TcpSocket implements SocketInterface {

	private Socket mSocket;
	private final String mServerAddr;
	private final int mPort;
	private InputStream mInStream;
	private OutputStream mOutStream;
    private static final String TAG = "TcpSocket";	
	
	public TcpSocket(String serverAddr, int port) {
		mSocket = null;
		mServerAddr = serverAddr;
		mPort = port;
		mInStream = null;
		mOutStream = null;
	}

	public boolean connect() {
		InputStream tmpIn = null;
		OutputStream tmpOut = null;

		try {
			mSocket = new Socket(mServerAddr, mPort);
			mSocket.setKeepAlive(true);
			tmpIn = mSocket.getInputStream();
			tmpOut = mSocket.getOutputStream();
		} catch (UnknownHostException e) {
			Log.e(TAG, "unknown host", e);
			return false;
		} catch (IOException e) {
			Log.e(TAG, "could not connect", e);
			return false;
		}

		mInStream = tmpIn;
		mOutStream = tmpOut;
		return true;
	}
	
	public void write(byte[] buffer) throws IOException {
		mOutStream.write(buffer);
		mOutStream.flush();
		// Log.d(TAG, "wrote " + HexUtils.bytesToHexString(buffer));
	}

	public int read(byte[] buffer) throws IOException {
		return mInStream.read(buffer);
	}

	public void close() {
		try {
			mInStream.close();
			mOutStream.close();
			mSocket.close();
		} catch (IOException e) {
			Log.w(TAG, "could not close socket", e);
		}
	}

	public int bytesAvailable() throws IOException {
		return mInStream.available();
	}

	public boolean isAlive() {
		return mSocket != null && mSocket.isConnected() && !mSocket.isClosed();
	}
}
