package com.xray.bt.monitor2;

import java.util.ArrayList;

public class SharmReader implements ISharmReader {

	private byte[] mBuffer;
	private int mOffset = 0; // can point to [0]..[mBuffer.size]
	private byte[] mPayload;
	private byte mCrc;
	private int mDataSize;

	private enum State { Syncing, Synced, GotSize, GotData };
	private State mState = State.Syncing;

	ISharmReaderObserver mObserver;
	private ArrayList<String> mRecvLog = new ArrayList<String>(256);

	public SharmReader(ISharmReaderObserver observer) {
		mObserver = observer;
		mOffset = 0;
	}

	public void addData(byte[] data, int len) {
        mRecvLog.add(HexUtils.bytesToHexString(data, len));
        
        if (len == 0) return;
		
		appendToBuffer(data, len);

		while (mOffset < mBuffer.length) {
            // System.out.println("-- state = " + stateToStr(mState) + ", offset = " + mOffset);
			
			switch (mState) {
				case Syncing: // searching for start sequence
					boolean found_stx = false;
					for (int i = mOffset; i < mBuffer.length; i++) {
						if (mBuffer[i] == (byte)0xFE) {
							mDataSize = 0;
							mState = State.Synced;
							mOffset = i + 1;					
							found_stx = true;
							break;
						}
					}
					if (!found_stx)
						mOffset = mBuffer.length;
					break;
				case Synced: // start sequence found, reading length
					if (remaining() > 2) {
						mDataSize = (mBuffer[mOffset] << 8) + mBuffer[mOffset+1];
						// System.out.println("-- data size => " + mDataSize);
						mOffset += 2;
						mState = State.GotSize;
					}
					else
						return;
					break;
				case GotSize: // total size of data is known, try reading
					if (remaining() >= mDataSize) {
						mCrc = Crc.calcCrc8((byte)0, mBuffer, mOffset, mDataSize);
						mPayload = new byte[mDataSize];
						System.arraycopy(mBuffer, mOffset, mPayload, 0, mDataSize);
						mOffset += mDataSize;
						mState = State.GotData;
					}
					else
						return;
					break;
				case GotData: // retrived payload, read and verify CRC
					if (remaining() >= 1) {
						byte crc_in_packet = mBuffer[mOffset];
						mOffset++;
						if (crc_in_packet == mCrc) {
							mObserver.onMessage(mPayload);
						} else {
							mObserver.onParseError(String.format("crc mismatch: expected %02x, got %02x", crc_in_packet, mCrc));
						}
						mPayload = null;
						trimBuffer();
						mState = State.Syncing;
					}
					break;
				default:
					assert false;
					break;
			} // switch
			// System.out.println("-- new offset = " + mOffset + ", buf len = " + mBuffer.length);
		} // while 
	}

	public String recvLogAsMultilineString() {
        StringBuffer s = new StringBuffer(mRecvLog.size() * 256);
        for (String line : mRecvLog) {
            s.append(line);
            s.append('\n');
        }
        return s.toString();
    }

    public void delimitRecvLog(String text) {
        mRecvLog.add("=== " + text + " ===");
    }	

	private int remaining() {
		return mBuffer.length - mOffset;
	}

    public byte[] getBuffer() {
        return mBuffer;
    }

    public int offset() {
        return mOffset;
    }	

    public void appendToBuffer(byte[] data, int len) {
        byte[] tmp;
        if (mBuffer != null) {
            tmp = new byte[mBuffer.length + len];
            System.arraycopy(mBuffer, 0, tmp, 0, mBuffer.length);
            System.arraycopy(data, 0, tmp, mBuffer.length, len);
        }
        else {
            tmp = new byte[len];
            System.arraycopy(data, 0, tmp, 0, len);
        }
        mBuffer = tmp;
    }

    public void trimBuffer() {
        byte[] tmp = new byte[mBuffer.length - mOffset];
        System.arraycopy(mBuffer, mOffset, tmp, 0, mBuffer.length - mOffset);
        mBuffer = tmp;
        mOffset = 0;
    }

    private String stateToStr(State s) {
        switch (s) {
            case Syncing: return "Syncing";
            case Synced: return "Synced";
            case GotSize: return "GotSize";
            case GotData: return "GotData";
            default: return "???";
        }
    }	
}
