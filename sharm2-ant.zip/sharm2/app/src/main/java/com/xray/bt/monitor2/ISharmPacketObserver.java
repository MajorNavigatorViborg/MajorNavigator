package com.xray.bt.monitor2;

public interface ISharmPacketObserver {
	// пакет 5
	public void onState(State state);
	// пакет 1
	public void onUserConfig(UserConfig cfg);
	// пакет 2
	public void onSysConfig(SysConfig cfg);
	// error parsing data structure
	public void onParsePacketError(String msg);
    // my config 1 has been saved
    public void onUserConfigAccepted();
    // my config 2 has been saved
    public void onSysConfigAccepted();
	// reset alert was accepted
	public void onResetAlertAccepted();
}
