package com.xray.bt.monitor2;

import java.io.UnsupportedEncodingException;

public class SharmFakePacket {

	public static class Incoming implements ISharmIncomingPacket {

		public boolean isAsync(byte[] data) {
			try {			
				String s = new String(data, "utf-8");			
				if ("state".equals(s))
					return true;
			}
			catch (UnsupportedEncodingException e) {}
			return false;
		}

		public Transaction getTransaction(byte[] data) {
			try {
				String s = new String(data, "utf-8");
				if ("state".equals(s))
					return Transaction.NONE;
				else if ("user".equals(s))
					return Transaction.USER_CFG_READ;
				else if ("sys".equals(s))
					return Transaction.SYS_CFG_READ;
				else if ("userok".equals(s))
					return Transaction.USER_CFG_WRITE;
				else if ("sysok".equals(s))
					return Transaction.SYS_CFG_WRITE;
				else {
					//System.out.println("getId: " + s + " is unknown packet");
					return Transaction.UNKNOWN;
				}
			}
			catch (UnsupportedEncodingException e) {}
			return Transaction.UNKNOWN;
		}

		public void parse(byte[] data, ISharmPacketObserver parsed) {
			try {			
				String s = new String(data, "utf-8");			
				if ("state".equals(s))
					parsed.onState(new State());
				else if ("user".equals(s))
					parsed.onUserConfig(new UserConfig());
				else if ("sys".equals(s))
					parsed.onSysConfig(new SysConfig());
				else
					parsed.onParsePacketError("wrong type");
			}
			catch (UnsupportedEncodingException e) {}
		}
	}

	public static class Outgoing implements ISharmOutgoingPacket {

		public byte[] serializeState(State s) { return null; }
		
		public SharmSendContext serializeResetAlert() {
			return new SharmSendContext(new byte[]{}, true, true, Transaction.RESET_ALERT);
		}

		public SharmSendContext serializeUserConfigRequest() {
			return new SharmSendContext(new byte[]{}, true, true, Transaction.USER_CFG_READ);
		}
		
		public SharmSendContext serializeSysConfigRequest() {
			return new SharmSendContext(new byte[]{}, true, true, Transaction.SYS_CFG_READ);
		}	
		
		public SharmSendContext serializeUserConfigSetup(UserConfig cfg) {
			return new SharmSendContext(new byte[]{}, true, true, Transaction.USER_CFG_WRITE);
		}

		public SharmSendContext serializeSysConfigSetup(SysConfig cfg) {
			return new SharmSendContext(new byte[]{}, true, true, Transaction.SYS_CFG_WRITE);
		}

	}
	
}
