package com.xray.bt.monitor2;

import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

public class SharmFakeReader implements ISharmReader {
	private ISharmReaderObserver mObserver;
    private ArrayList<String> mRecvLog = new ArrayList<String>(256);

	public SharmFakeReader(ISharmReaderObserver obs) {
		mObserver = obs;
	}

	public void addData(byte[] data, int len) {
        mRecvLog.add(HexUtils.bytesToHexString(data, len));
		try {
			String s = new String(data, "utf-8");
			if (s.length() < 2) {
				System.out.println("SharmFakeReader: too short message: " + s);
				mObserver.onParseError("too short message: " + s);
			}
			else if (s.charAt(0) != '[' || s.charAt(s.length()-1) != ']') {
				System.out.println("SharmFakeReader: invalid message format: " + s);
				mObserver.onParseError("invalid message format: " + s);
			}
			else {
				mObserver.onMessage(s.substring(1, s.length()-1).getBytes("utf-8"));
			}
		}
		catch (UnsupportedEncodingException e) {}
	}

    public String recvLogAsMultilineString() {
        StringBuffer s = new StringBuffer(mRecvLog.size() * 256);
        for (String line : mRecvLog) {
            s.append(line);
            s.append('\n');
        }
        return s.toString();
    }

    public void delimitRecvLog(String text) {
        mRecvLog.add("=== " + text + " ===");
    }


}
