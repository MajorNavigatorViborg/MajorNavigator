package com.xray.bt.monitor2;

public class UserConfig {
    public static final String LIVE_TIME = "user_cfg_live_time";
    public static final String THRESHOLD = "user_cfg_threshold";
    public static final String GYRO_SENS = "user_cfg_gyro_sens";
    public static final String GSM = "user_cfg_gsm";
    public static final String MODE = "user_cfg_mode";

    public static final String LIVE_TIME_FB = "user_cfg_live_time_fb";
    public static final String THRESHOLD_FB = "user_cfg_threshold_fb";
    public static final String GYRO_SENS_FB = "user_cfg_gyro_sens_fb";
    public static final String GSM_FB = "user_cfg_gsm_fb";
    public static final String MODE_FB = "user_cfg_mode_fb";
    
	public UserConfig() {
		liveTime = -1;
		threshold = -1;
		gyroSens = -1;
		gsm = -1;
		mode = -1;
	}

	public UserConfig(int lt, int th, int gs, int g, int m) {
		liveTime = lt;
		threshold = th;
		gyroSens = gs;
		gsm = g;
		mode = m;
	}

	public String toString() {
		return String.format("liveTime=%d, threshold=%d, gyroSens=%d, gsm=%d, mode=%d",
			liveTime, threshold, gyroSens, gsm, mode);
	}
	
	public int liveTime;
	public int threshold;
	public int gyroSens;
	public int gsm;
	public int mode;
}
