package com.xray.bt.monitor2;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class SharmPacket {

	public static class Incoming implements ISharmIncomingPacket {

		public boolean isAsync(byte[] data) {
            return getTransaction(data) == Transaction.NONE;
        }

		public Transaction getTransaction(byte[] data) {
            if (data.length > 0) {
                switch (data[0]) {
                    case 0x05:
                        return Transaction.NONE;
                    case 0x01: {
                        if (data.length > 1)
                            return Transaction.USER_CFG_READ;
                        else
                            return Transaction.USER_CFG_WRITE;
                    }
                    case 0x02: {
                        if (data.length > 1)
                            return Transaction.SYS_CFG_READ;
                        else
                            return Transaction.SYS_CFG_WRITE;
                    }
					case 0x06: {
                        if (data.length == 1)
                            return Transaction.RESET_ALERT;
                        else
                            return Transaction.NONE;
					}
                    default:
                        return Transaction.UNKNOWN;
                }
            }
            else
                return Transaction.UNKNOWN;
        }
			
		public void parse(byte[] data, ISharmPacketObserver parsed) {
			DataInputStream is = new DataInputStream(new ByteArrayInputStream(data));
			try {
				byte type = is.readByte();
				switch (type) {
					case 0x05: {
						State s = new State();
						s.workSignal = is.readFloat();
						
						byte b2 = is.readByte(); // batteryBd + rssiGsm
						byte b3 = is.readByte(); // batteryRr + batteryKs
						byte b4 = is.readByte(); // rssiBd + rssiKs + rssiRr1 + rssiRr2
						byte b5 = is.readByte(); // threshold[3] + thresholdGyro[2] + mode[2] + stateGyro[1]

						if (is.available() > 0) { // more bytes than necessary
							parsed.onParsePacketError("extra bytes in state");
							return;
						}

						s.batteryBd = (b2 >> 4) & 0x0f;
						s.batteryRr = (b3 >> 4) & 0x0f;
						s.batteryKs = b3 & 0x0f;
						s.rssiBd = (b4 >> 6) & 0x03;
						s.rssiRr1 = (b4 >> 2) & 0x03;
						s.rssiRr2 = b4 & 0x03;
						s.rssiKs = (b4 >> 4) & 0x03;
						s.rssiGsm = b2 & 0x0f;
						s.threshold = (b5 >> 5) & 0x07;
						s.thresholdGyro = (b5 >> 3) & 0x03;
						s.mode = (b5 >> 1) & 0x03;
						s.stateGyro = ((b5 & 0x01) == 0) ? false : true;

						parsed.onState(s);
						break;
					}
					case 0x01: {
                        if (is.available() == 0) {
                            parsed.onUserConfigAccepted();
                            return;
                        }
                            
						UserConfig c = new UserConfig();
						
						c.liveTime = is.readShort() & 0xffff;
						c.threshold = is.readByte() & 0xff;
						c.gyroSens = is.readByte() & 0xff;
						c.gsm = is.readByte() & 0xff;
						c.mode = is.readByte() & 0xff;

						if (is.available() > 0) { // more bytes than necessary
							parsed.onParsePacketError("extra bytes in user config");
							return;
						}

						parsed.onUserConfig(c);
						break;
					}

					case 0x02: {
                        if (is.available() == 0) {
                            parsed.onSysConfigAccepted();
                            return;
                        }
                        
						SysConfig c = new SysConfig();

						c.compThreshold = is.readByte() & 0xff;
						c.highVoltage = is.readShort() & 0xffff;
						c.refVoltage = is.readShort() & 0xffff;
						c.adcCoef = is.readShort() & 0xffff;
						c.cntChannelCoef = is.readByte() & 0xff;
						c.intChannelCoef = is.readByte() & 0xff;
						c.cntIntThreshold = is.readByte() & 0xff;
						c.expTime = is.readShort() & 0xffff;

						if (is.available() > 0) { // more bytes than necessary
							parsed.onParsePacketError("extra bytes in sys config");
							return;
						}

						parsed.onSysConfig(c);
						break;
					}
					case 0x06: {
                        if (is.available() == 0)
                            parsed.onResetAlertAccepted();
						else 
							parsed.onParsePacketError("extra bytes in reset accept packet");
						break;
					}
					default:
						parsed.onParsePacketError("unknown type");
				}
			}
			catch (IOException e) {
				parsed.onParsePacketError("read underflow");
			}
		}
	}

	public static class Outgoing implements ISharmOutgoingPacket {

		public byte[] serializeState(State s) {
			try {
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				DataOutputStream os = new DataOutputStream(bos);
				int stateGyro = s.stateGyro ? 1 : 0;
				os.writeByte((byte)0x05);
				os.writeFloat(s.workSignal);
				os.writeByte( ((s.batteryBd & 0x0f) << 4) | (s.rssiGsm & 0x0f) );
				os.writeByte( ((s.batteryRr & 0x0f) << 4) | (s.batteryKs & 0x0f) );
				os.writeByte( ((s.rssiBd & 0x03) << 6) | ((s.rssiKs & 0x03) << 4) | ((s.rssiRr1 & 0x03) << 2) | (s.rssiRr2 & 0x03) );
				os.writeByte( ((s.threshold & 0x07) << 5) | ((s.thresholdGyro & 0x03) << 3) | ((s.mode & 0x03) << 1) | (stateGyro & 0x01) );
				return bos.toByteArray();
			}
			catch (IOException e) {
				return null;
			}
		}
		
		public SharmSendContext serializeResetAlert() {
			return new SharmSendContext(new byte[]{ (byte)0x06, (byte)0x01 }, true, true, Transaction.RESET_ALERT);
		}
		
		public SharmSendContext serializeUserConfigRequest() {
			return new SharmSendContext(new byte[]{ (byte)0x01 }, true, true, Transaction.USER_CFG_READ);
		}
		
		public SharmSendContext serializeSysConfigRequest() {
			return new SharmSendContext(new byte[]{ (byte)0x02 }, true, true, Transaction.SYS_CFG_READ);
		}
		
		public SharmSendContext serializeUserConfigSetup(UserConfig cfg) {
			try {
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				DataOutputStream os = new DataOutputStream(bos);
				os.writeByte((byte)0x01);
				os.writeShort((short)(cfg.liveTime & 0xffff));
				os.writeByte((byte)(cfg.threshold & 0xff));
				os.writeByte((byte)(cfg.gyroSens & 0xff));
				os.writeByte((byte)(cfg.gsm & 0xff));
				os.writeByte((byte)(cfg.mode & 0xff));
				return new SharmSendContext(bos.toByteArray(), true, false, Transaction.USER_CFG_WRITE);
			}
			catch (IOException e) {
				return null;
			}
		}

		public SharmSendContext serializeSysConfigSetup(SysConfig cfg) {
			try {
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				DataOutputStream os = new DataOutputStream(bos);
				os.writeByte((byte)0x02);
				os.writeByte((byte)(cfg.compThreshold & 0xff));
				os.writeShort((short)(cfg.highVoltage & 0xffff));
				os.writeShort((short)(cfg.refVoltage & 0xffff));
				os.writeShort((short)(cfg.adcCoef & 0xffff));
				os.writeByte((byte)(cfg.cntChannelCoef & 0xff));
				os.writeByte((byte)(cfg.intChannelCoef & 0xff));
				os.writeByte((byte)(cfg.cntIntThreshold & 0xff));
				os.writeShort((short)(cfg.expTime & 0xffff));
				return new SharmSendContext(bos.toByteArray(), true, false, Transaction.SYS_CFG_WRITE);
			}
			catch (IOException e) {
				return null;
			}
		}

        public byte[] serializeUserConfigAccepted() {
            return new byte[]{ (byte)0x01 };
        }

        public byte[] serializeSysConfigAccepted() {
            return new byte[]{ (byte)0x02 };
        }

        public byte[] serializeResetAlertAccepted() {
            return new byte[]{ (byte)0x06 };
        }
		
	}
	
}
