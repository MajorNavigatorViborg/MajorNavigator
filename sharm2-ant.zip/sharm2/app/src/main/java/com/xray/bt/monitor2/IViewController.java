package com.xray.bt.monitor2;

public interface IViewController {

	public void onWorkSignal(String text);

	public void onThreshold(String text);

    public void onAlert(String text, int color);

	public void onStartShortBeep();
	public void onStartLongBeep();
	public void onEndBeep();

	public void onStartVibrate();
	public void onEndVibrate();

	public void onBdBatteryValue(int level);
	public void onRrBatteryValue(int level);
	public void onKsBatteryValue(int level);

	public void onBdRssiValue(int level);
	public void onRr1RssiValue(int level);
	public void onRr2RssiValue(int level);
	public void onKsRssiValue(int level);
	public void onGsmRssiValue(int level);

	public void onRrLineVisibility(boolean showBat, boolean showRssi1, boolean showRssi2);

	public void onSetMode(String text);
	public void onPeakText(String text);

    public void onShowHeaderStatus();
    public void onHideHeaderStatus();
    public void onSetFooter(String text);

	public void onTestName(String title);
	public void onSharmMessageOnMainThread(byte[] data);

	public void onSendReset();
	public void onNothingToResetWarning();
}
