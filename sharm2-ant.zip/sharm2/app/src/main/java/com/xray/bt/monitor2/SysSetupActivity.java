package com.xray.bt.monitor2;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.util.Log;

public class SysSetupActivity extends Activity {
	private static final String TAG = "SysSetupActivity";
	
    TextView mCompThresholdOld, mHighVoltageOld, mRefVoltageOld,
		mAdcCoefOld, mCntChanCoefOld, mIntChanCoefOld, mCntIntThresholdOld, mExpTimeOld;

    EditText mCompThresholdNew, mHighVoltageNew, mRefVoltageNew,
		mAdcCoefNew, mCntChanCoefNew, mIntChanCoefNew, mCntIntThresholdNew, mExpTimeNew;;

	public static final String COMP_THRESHOLD_OLD = "sys_cfg_comp_threshold_old";
	public static final String HIGH_VOLTAGE_OLD = "sys_cfg_high_voltage_old";
	public static final String REF_VOLTAGE_OLD = "sys_cfg_ref_voltage_old";
	public static final String ADC_COEF_OLD = "sys_cfg_adc_coef_old";
	public static final String CNT_CHAN_COEF_OLD = "sys_cfg_cnt_chan_coef_old";
	public static final String INT_CHAN_COEF_OLD = "sys_cfg_int_chan_coef_old";
	public static final String CNT_INT_THRESHOLD_OLD = "sys_cfg_cnt_int_threshold_old";
	public static final String EXP_TIME_OLD = "sys_cfg_exp_time_old";

	public static final String COMP_THRESHOLD_NEW = "sys_cfg_comp_threshold_new";
	public static final String HIGH_VOLTAGE_NEW = "sys_cfg_high_voltage_new";
	public static final String REF_VOLTAGE_NEW = "sys_cfg_ref_voltage_new";
	public static final String ADC_COEF_NEW = "sys_cfg_adc_coef_new";
	public static final String CNT_CHAN_COEF_NEW = "sys_cfg_cnt_chan_coef_new";
	public static final String INT_CHAN_COEF_NEW = "sys_cfg_int_chan_coef_new";
	public static final String CNT_INT_THRESHOLD_NEW = "sys_cfg_cnt_int_threshold_new";
	public static final String EXP_TIME_NEW = "sys_cfg_exp_time_new";

    private int mGoodColor, mBadColor;
	    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sys_setup);

        mGoodColor = getResources().getColor(android.R.color.white);
        mBadColor = getResources().getColor(android.R.color.holo_red_light);

        mCompThresholdOld = (TextView)findViewById(R.id.comp_threshold_old);
        mHighVoltageOld = (TextView)findViewById(R.id.high_voltage_old);
        mRefVoltageOld = (TextView)findViewById(R.id.ref_voltage_old);
        mAdcCoefOld = (TextView)findViewById(R.id.adc_coef_old);
        mCntChanCoefOld = (TextView)findViewById(R.id.cnt_chan_coef_old);
        mIntChanCoefOld = (TextView)findViewById(R.id.int_chan_coef_old);
        mCntIntThresholdOld = (TextView)findViewById(R.id.cnt_int_threshold_old);
        mExpTimeOld = (TextView)findViewById(R.id.exp_time_old);		

        mCompThresholdNew = (EditText)findViewById(R.id.comp_threshold_new);
        mHighVoltageNew = (EditText)findViewById(R.id.high_voltage_new);
        mRefVoltageNew = (EditText)findViewById(R.id.ref_voltage_new);
        mAdcCoefNew = (EditText)findViewById(R.id.adc_coef_new);
        mCntChanCoefNew = (EditText)findViewById(R.id.cnt_chan_coef_new);
        mIntChanCoefNew = (EditText)findViewById(R.id.int_chan_coef_new);
        mCntIntThresholdNew = (EditText)findViewById(R.id.cnt_int_threshold_new);
        mExpTimeNew = (EditText)findViewById(R.id.exp_time_new);
		
        loadValues(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
		storeValues(outState);
	}

    @Override
	public void onBackPressed() {
        // no-op
    }

    public void btnAcceptClicked(View v) {
		String wrong_param = validate();
		if (wrong_param == null) {
			if (!wasSomethingChanged())
				cancelAndFinish();
			else
				showConfirmDialog(R.string.confirm_accept, R.string.confirm_cancel, true);
		}
		else
			showInvalidValueDialog(wrong_param);
    }

    public void btnDiscardClicked(View v) {
        showConfirmDialog(R.string.confirm_discard, R.string.confirm_return, false);
    }

    private void showConfirmDialog(int rcText, int rcCancelBtn, final boolean positiveSaveOrCancel) {
		new AlertDialog.Builder(this)
			.setTitle(R.string.confirmation)
			.setMessage(rcText)
			.setPositiveButton(R.string.confirm_yes,
				new DialogInterface.OnClickListener() {
                    public void onClick(
						DialogInterface dialog, int whichButton)
					{
						if (positiveSaveOrCancel)
							saveAndFinish();
						else
							cancelAndFinish();
					}
				})
            .setNeutralButton(rcCancelBtn, null)
			.show();
    }

	private void showInvalidValueDialog(String wrongParam) {
		new AlertDialog.Builder(this)
			.setTitle(R.string.invalid_config_param)
			.setMessage(wrongParam)
			.show();
	}

    private boolean wasSomethingChanged() {
		if (!textEditEquals(mCompThresholdOld, mCompThresholdNew))
			return true;
		if (!textEditEquals(mHighVoltageOld, mHighVoltageNew))
			return true;
		if (!textEditEquals(mRefVoltageOld, mRefVoltageNew))
			return true;
		if (!textEditEquals(mAdcCoefOld, mAdcCoefNew))
			return true;
		if (!textEditEquals(mCntChanCoefOld, mCntChanCoefNew))
			return true;
		if (!textEditEquals(mIntChanCoefOld, mIntChanCoefNew))
			return true;
		if (!textEditEquals(mCntIntThresholdOld, mCntIntThresholdNew))
			return true;
		if (!textEditEquals(mExpTimeOld, mExpTimeNew))
			return true;		
		return false;
    }

	private String validate() {
		try {
			return SysConfigAdapter.validate(
				new SysConfig(
					readTextEdit(mCompThresholdNew, R.string.comp_threshold),
					readTextEdit(mHighVoltageNew, R.string.high_voltage),
					readTextEdit(mRefVoltageNew, R.string.ref_voltage),
					readTextEdit(mAdcCoefNew, R.string.adc_coef),
					readTextEdit(mCntChanCoefNew, R.string.cnt_chan_coef),
					readTextEdit(mIntChanCoefNew, R.string.int_chan_coef),
					readTextEdit(mCntIntThresholdNew, R.string.cnt_int_threshold),
					readTextEdit(mExpTimeNew, R.string.exp_time)
					), this);
		} catch (RuntimeException e) {
			return e.getMessage();
		}
	}

    private void loadValues(Bundle state) {
        if (state != null) {
            mCompThresholdOld.setText(String.format("%d", state.getInt(COMP_THRESHOLD_OLD)));
            mHighVoltageOld.setText(String.format("%d", state.getInt(HIGH_VOLTAGE_OLD)));
            mRefVoltageOld.setText(String.format("%d", state.getInt(REF_VOLTAGE_OLD)));
            mAdcCoefOld.setText(String.format("%d", state.getInt(ADC_COEF_OLD)));
            mCntChanCoefOld.setText(String.format("%d", state.getInt(CNT_CHAN_COEF_OLD)));
            mIntChanCoefOld.setText(String.format("%d", state.getInt(INT_CHAN_COEF_OLD)));
            mCntIntThresholdOld.setText(String.format("%d", state.getInt(CNT_INT_THRESHOLD_OLD)));
            mExpTimeOld.setText(String.format("%d", state.getInt(EXP_TIME_OLD)));

            mCompThresholdNew.setText(String.format("%d", state.getInt(COMP_THRESHOLD_NEW)));
            mHighVoltageNew.setText(String.format("%d", state.getInt(HIGH_VOLTAGE_NEW)));
            mRefVoltageNew.setText(String.format("%d", state.getInt(REF_VOLTAGE_NEW)));
            mAdcCoefNew.setText(String.format("%d", state.getInt(ADC_COEF_NEW)));
            mCntChanCoefNew.setText(String.format("%d", state.getInt(CNT_CHAN_COEF_NEW)));
            mIntChanCoefNew.setText(String.format("%d", state.getInt(INT_CHAN_COEF_NEW)));
            mCntIntThresholdNew.setText(String.format("%d", state.getInt(CNT_INT_THRESHOLD_NEW)));
            mExpTimeNew.setText(String.format("%d", state.getInt(EXP_TIME_NEW)));
        } else {
			Intent intent = getIntent();
            loadParam(intent, SysConfig.COMP_THRESHOLD, SysConfig.COMP_THRESHOLD_FB, mCompThresholdOld, mCompThresholdNew);
            loadParam(intent, SysConfig.HIGH_VOLTAGE, SysConfig.HIGH_VOLTAGE_FB, mHighVoltageOld, mHighVoltageNew);
            loadParam(intent, SysConfig.REF_VOLTAGE, SysConfig.REF_VOLTAGE_FB, mRefVoltageOld, mRefVoltageNew);
            loadParam(intent, SysConfig.ADC_COEF, SysConfig.ADC_COEF_FB, mAdcCoefOld, mAdcCoefNew);
            loadParam(intent, SysConfig.CNT_CHAN_COEF, SysConfig.CNT_CHAN_COEF_FB, mCntChanCoefOld, mCntChanCoefNew);
            loadParam(intent, SysConfig.INT_CHAN_COEF, SysConfig.INT_CHAN_COEF_FB, mIntChanCoefOld, mIntChanCoefNew);
            loadParam(intent, SysConfig.CNT_INT_THRESHOLD, SysConfig.CNT_INT_THRESHOLD_FB, mCntIntThresholdOld, mCntIntThresholdNew);
            loadParam(intent, SysConfig.EXP_TIME, SysConfig.EXP_TIME_FB, mExpTimeOld, mExpTimeNew);
        }
    }

    private void loadParam(Intent intent, String goodKey, String fallbackKey, TextView oldField, TextView newField) {
        int actual_val = intent.getIntExtra(goodKey, -1);
        int fallback_val = intent.getIntExtra(fallbackKey, -1);
        if (fallback_val == -1) { // correct value
            oldField.setText(String.format("%d", actual_val));
            oldField.setTextColor(mGoodColor);
            newField.setText(String.format("%d", actual_val));
        } else { // bad value
            oldField.setText(String.format("%d (!)", actual_val));
            oldField.setTextColor(mBadColor);
            newField.setText(String.format("%d", fallback_val));
        }
    }

    private void storeValues(Bundle state) {
		state.putInt(COMP_THRESHOLD_OLD, Integer.parseInt(mCompThresholdOld.getText().toString()));
		state.putInt(HIGH_VOLTAGE_OLD, Integer.parseInt(mHighVoltageOld.getText().toString()));
		state.putInt(REF_VOLTAGE_OLD, Integer.parseInt(mRefVoltageOld.getText().toString()));
		state.putInt(ADC_COEF_OLD, Integer.parseInt(mAdcCoefOld.getText().toString()));
		state.putInt(CNT_CHAN_COEF_OLD, Integer.parseInt(mCntChanCoefOld.getText().toString()));
		state.putInt(INT_CHAN_COEF_OLD, Integer.parseInt(mIntChanCoefOld.getText().toString()));
		state.putInt(CNT_INT_THRESHOLD_OLD, Integer.parseInt(mCntIntThresholdOld.getText().toString()));
		state.putInt(EXP_TIME_OLD, Integer.parseInt(mExpTimeOld.getText().toString()));

		state.putInt(COMP_THRESHOLD_NEW, Integer.parseInt(mCompThresholdNew.getText().toString()));
		state.putInt(HIGH_VOLTAGE_NEW, Integer.parseInt(mHighVoltageNew.getText().toString()));
		state.putInt(REF_VOLTAGE_NEW, Integer.parseInt(mRefVoltageNew.getText().toString()));
		state.putInt(ADC_COEF_NEW, Integer.parseInt(mAdcCoefNew.getText().toString()));
		state.putInt(CNT_CHAN_COEF_NEW, Integer.parseInt(mCntChanCoefNew.getText().toString()));
		state.putInt(INT_CHAN_COEF_NEW, Integer.parseInt(mIntChanCoefNew.getText().toString()));
		state.putInt(CNT_INT_THRESHOLD_NEW, Integer.parseInt(mCntIntThresholdNew.getText().toString()));
		state.putInt(EXP_TIME_NEW, Integer.parseInt(mExpTimeNew.getText().toString()));
    }

    private void saveAndFinish() {
		Intent intent = new Intent();

		intent.putExtra(SysConfig.COMP_THRESHOLD, Integer.parseInt(mCompThresholdNew.getText().toString()));
		intent.putExtra(SysConfig.HIGH_VOLTAGE, Integer.parseInt(mHighVoltageNew.getText().toString()));
		intent.putExtra(SysConfig.REF_VOLTAGE, Integer.parseInt(mRefVoltageNew.getText().toString()));
		intent.putExtra(SysConfig.ADC_COEF, Integer.parseInt(mAdcCoefNew.getText().toString()));
		intent.putExtra(SysConfig.CNT_CHAN_COEF, Integer.parseInt(mCntChanCoefNew.getText().toString()));
		intent.putExtra(SysConfig.INT_CHAN_COEF, Integer.parseInt(mIntChanCoefNew.getText().toString()));
		intent.putExtra(SysConfig.CNT_INT_THRESHOLD, Integer.parseInt(mCntIntThresholdNew.getText().toString()));
		intent.putExtra(SysConfig.EXP_TIME, Integer.parseInt(mExpTimeNew.getText().toString()));
		
		setResult(RESULT_OK, intent);
		finish();
    }

	private void cancelAndFinish() {
		setResult(RESULT_CANCELED);
		finish();
	}

	private boolean textEditEquals(TextView t1, EditText t2) {
		return t1.getText().toString().equals(t2.getText().toString());
	}

	private int readTextEdit(EditText t, int rcId) throws RuntimeException {
		try {
			return Integer.parseInt(t.getText().toString());
		} catch (NumberFormatException e) {
			throw new RuntimeException(getString(rcId));
		}
	}
}
