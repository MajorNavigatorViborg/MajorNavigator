package com.xray.bt.monitor2;

public interface ISharmIncomingPacket {

	public boolean isAsync(byte[] data);

	public Transaction getTransaction(byte[] data);

	public void parse(byte[] data, ISharmPacketObserver parsed);
	
}
