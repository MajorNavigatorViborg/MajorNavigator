package com.xray.bt.monitor2;

public interface ISharmDevice {

    // пакет 5
    public void onStateReceived(State s);

    // пакет 1
    public void onUserConfigReceived(UserConfig cfg);

    // пакет 2
    public void onSysConfigReceived(SysConfig cfg);

    // настройки 1 успешно сохранены
    public void onUserConfigAccepted();

    // настройки 2 успешно сохранены
    public void onSysConfigAccepted();

	// сбор тревоги успешно сохранён
	public void onResetAlertAccepted();

    // during sending or receiving an error occured; receiving thread is already stopped
    public void onSocketError();

    // could not parse incoming data; receiving thread is already stopped
    public void onParseError(String msg);

    // response received too late after request
    public void onResponseTooLate();

    // response hasn't been received during timeout
    public void onResponseTimeout();

	// response received in time but doesn't correspond to request
	public void onResponseMismatch();

	// raw sharm message
	public void onSharmMessage(byte[] data);
}
