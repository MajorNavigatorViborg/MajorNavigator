package com.xray.bt.monitor2;

public interface ISharmOutgoingPacket {

	public byte[] serializeState(State s);

	public SharmSendContext serializeResetAlert();

	public SharmSendContext serializeUserConfigRequest();
	
	public SharmSendContext serializeSysConfigRequest();

	public SharmSendContext serializeUserConfigSetup(UserConfig cfg);
	
	public SharmSendContext serializeSysConfigSetup(SysConfig cfg);
	
}
