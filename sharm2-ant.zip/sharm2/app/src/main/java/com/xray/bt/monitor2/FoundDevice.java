package com.xray.bt.monitor2;

public class FoundDevice {
	public FoundDevice(String n, String a) {
		addr = a;
		name = n;
	}
	public String addr;
	public String name;
}
