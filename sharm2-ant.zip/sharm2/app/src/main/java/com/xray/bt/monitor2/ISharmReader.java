package com.xray.bt.monitor2;

public interface ISharmReader {

	public void addData(byte[] data, int len);

    public String recvLogAsMultilineString();

    public void delimitRecvLog(String text);
	
}
