package com.xray.bt.monitor2;

import java.util.UUID;
import java.util.HashMap;
import java.util.Map.Entry;

public class BtServiceUuids {

	private HashMap<UUID, String> mServiceNames =
		new HashMap<UUID, String>(64);

	public static final UUID SPP_UUID =
		UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

	BtServiceUuids() {
		HashMap<Integer, String> shortNames = new HashMap<Integer, String>(64);
		shortNames.put(0x1000, "ServiceDiscoveryServerServiceClassID");
		shortNames.put(0x1001, "BrowseGroupDescriptorServiceClassID");
		shortNames.put(0x1002, "PublicBrowseGroup");
		shortNames.put(0x1101, "SerialPort");
		shortNames.put(0x1102, "LANAccessUsingPPP");
		shortNames.put(0x1103, "DialupNetworking");
		shortNames.put(0x1104, "IrMCSync");
		shortNames.put(0x1105, "OBEXObjectPush");
		shortNames.put(0x1106, "OBEXFileTransfer");
		shortNames.put(0x1107, "IrMCSyncCommand");
		shortNames.put(0x1108, "Headset");
		shortNames.put(0x1109, "CordlessTelephony");
		shortNames.put(0x110A, "AudioSource");
		shortNames.put(0x110B, "AudioSink");
		shortNames.put(0x110C, "A/V_RemoteControlTarget");
		shortNames.put(0x110D, "AdvancedAudioDistribution");
		shortNames.put(0x110E, "A/V_RemoteControl");
		shortNames.put(0x110F, "VideoConferencing");
		shortNames.put(0x1110, "Intercom");
		shortNames.put(0x1111, "Fax");
		shortNames.put(0x1112, "HeadsetAudioGateway");
		shortNames.put(0x1113, "WAP");
		shortNames.put(0x1114, "WAP_CLIENT");
		shortNames.put(0x1115, "PANU");
		shortNames.put(0x1116, "NAP");
		shortNames.put(0x1117, "GN");
		shortNames.put(0x1118, "DirectPrinting");
		shortNames.put(0x1119, "ReferencePrinting");
		shortNames.put(0x111A, "Imaging");
		shortNames.put(0x111B, "ImagingResponder");
		shortNames.put(0x111C, "ImagingAutomaticArchive");
		shortNames.put(0x111D, "ImagingReferencedObjects");
		shortNames.put(0x111E, "Handsfree");
		shortNames.put(0x111F, "HandsfreeAudioGateway");
		shortNames.put(0x1120, "DirectPrintingReferenceObjectsService");
		shortNames.put(0x1121, "ReflectedUI");
		shortNames.put(0x1122, "BasicPrinting");
		shortNames.put(0x1123, "PrintingStatus");
		shortNames.put(0x1124, "HumanInterfaceDeviceService");
		shortNames.put(0x1125, "HardcopyCableReplacement");
		shortNames.put(0x1126, "HCR_Print");
		shortNames.put(0x1127, "HCR_Scan");
		shortNames.put(0x1128, "Common_ISDN_Access");
		shortNames.put(0x1129, "VideoConferencingGW");
		shortNames.put(0x112A, "UDI_MT");
		shortNames.put(0x112B, "UDI_TA");
		shortNames.put(0x112C, "Audio/Video");
		shortNames.put(0x112D, "SIM_Access");
		shortNames.put(0x112E, "Phonebook Access - PCE");
		shortNames.put(0x112F, "Phonebook Access - PSE");
		shortNames.put(0x1130, "Phonebook Access");
		shortNames.put(0x1200, "PnPInformation");
		shortNames.put(0x1201, "GenericNetworking");
		shortNames.put(0x1202, "GenericFileTransfer");
		shortNames.put(0x1203, "GenericAudio");
		shortNames.put(0x1204, "GenericTelephony");
		shortNames.put(0x1205, "UPNP_Service");
		shortNames.put(0x1206, "UPNP_IP_Service");
		shortNames.put(0x1300, "ESDP_UPNP_IP_PAN");
		shortNames.put(0x1301, "ESDP_UPNP_IP_LAP");
		shortNames.put(0x1302, "ESDP_UPNP_L2CAP");
		shortNames.put(0x1303, "VideoSource");
		shortNames.put(0x1304, "VideoSink");
		shortNames.put(0x1305, "VideoDistribution");

		for (Entry<Integer, String> e : shortNames.entrySet()) {
			mServiceNames.put(UUID.fromString("0000" + Integer.toHexString(e.getKey()) +
					"-0000-1000-8000-00805F9B34FB"), e.getValue());
		}
	}

	public String asServiceName(UUID uuid) {
		String s = mServiceNames.get(uuid);
		if (s == null) return uuid.toString();
		else return s;
	}

}

