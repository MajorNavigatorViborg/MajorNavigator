package com.xray.bt.monitor2;

public class State {
	public State() {}

    public State(
        float sig, int bat_bd, int bat_rr, int bat_ks,
        int rssi_bd, int rssi_rr1, int rssi_rr2, int rssi_ks, int rssi_gsm,
        int thresh, int thresh_gyro, int mod, boolean state_gyro,
		String test_name)
	{
		this(sig, bat_bd, bat_rr, bat_ks, rssi_bd, rssi_rr1, rssi_rr2, rssi_ks,
			rssi_gsm, thresh, thresh_gyro, mod, state_gyro);
		testName = test_name;
	}

    public State(
        float sig, int bat_bd, int bat_rr, int bat_ks,
        int rssi_bd, int rssi_rr1, int rssi_rr2, int rssi_ks, int rssi_gsm,
        int thresh, int thresh_gyro, int mod, boolean state_gyro)
    {
        workSignal = sig;
        batteryBd = bat_bd;
        batteryRr = bat_rr;
        batteryKs = bat_ks;
        rssiBd = rssi_bd;
        rssiRr1 = rssi_rr1;
        rssiRr2 = rssi_rr2;
        rssiKs = rssi_ks;
        rssiGsm = rssi_gsm;
        threshold = thresh;
        thresholdGyro = thresh_gyro;
        mode = mod;
        stateGyro = state_gyro;
		testName = null;
    }
	
	public float workSignal;
	public int batteryBd;
	public int batteryRr;
	public int batteryKs;
	public int rssiBd;
	public int rssiRr1;
	public int rssiRr2;
	public int rssiKs;
	public int rssiGsm;
	public int threshold;
	public int thresholdGyro;
	public int mode;
	public boolean stateGyro;

	public String testName;

    public String toString() {
        return String.format("workSignal=%.3f, batBd=%d, batRr=%d, batKs=%d, rssiBd=%d, rssiRr1=%d, rssiRr2=%d, rssiKs=%d, rssiGsm=%d, threshold=%d, thresholdGyro=%d, mode=%d, gyro=%d",
            workSignal, batteryBd, batteryRr, batteryKs, rssiBd, rssiRr1, rssiRr2, rssiKs, rssiGsm,
            threshold, thresholdGyro, mode, stateGyro ? 1 : 0);
    }
}
