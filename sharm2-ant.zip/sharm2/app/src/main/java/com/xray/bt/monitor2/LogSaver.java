package com.xray.bt.monitor2;

import java.lang.Process;
import java.lang.ProcessBuilder;
import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.InputStreamReader;
import java.io.BufferedOutputStream;
import java.util.zip.GZIPOutputStream;
import java.io.FileOutputStream;
import android.util.Log;

public class LogSaver {
    private static final String TAG = "BtLogSaver";
	private static SimpleDateFormat FMT = new SimpleDateFormat("yyyy-MM-dd_HH:mm");
    private static final String LOG_SUBDIR = "SharmAA";

	public static int getAndSave() {
		Process p = null;
		try {
            Log.d(TAG, "LogSaver: starting logcat");
			p = new ProcessBuilder()
				.command("/system/bin/logcat", "-d")
				.redirectErrorStream(true)
			.start();
			InputStream in = p.getInputStream();
            Log.d(TAG, "LogSaver: started logcat");
			return processLogcatOutput(in);
		}
		catch (IOException e) {
            Log.e(TAG, "error saving logs: " + e.getMessage());
			return R.string.log_error_io;
		}
		finally {
			if (p != null)
				p.destroy();
		}
	}

	private static int processLogcatOutput(InputStream in) {
		InputStreamReader reader = new InputStreamReader(in);
		File f = null;
		GZIPOutputStream gz = null;
		byte[] buf = new byte[8192];
		try {
			f = new File(generateFileName(createSubDir()));
			gz = new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
			while (true) {
				int br = in.read(buf);
				if (br == -1)
					return 0; // successfully reached the end-of-file
				gz.write(buf, 0, br);
			}
		}
		catch (SecurityException e) {
            Log.e(TAG, "error processing logcat (security): " + e.getMessage());
			return R.string.log_error_rw;
		}
		catch (IOException e) {
            Log.e(TAG, "error processing logcat (io): " + e.getMessage());
			return R.string.log_error_rw;
		}
		finally {
			try {
				if (gz != null)
					gz.close();
			} catch (IOException e) {
				// ignore
			}
		}
	}

	private static String generateFileName(String base_dir) {
        return base_dir +
            File.separatorChar +
            "sharm_" +
            FMT.format(new Date()) +
            ".log.gz";
	}

    private static String createSubDir() throws IOException {
		String base_dir = android.os.Environment.
			getExternalStorageDirectory().getAbsolutePath() +
            File.separatorChar +
            LOG_SUBDIR;
        boolean dir_created = new File(base_dir).mkdir();
        if (!dir_created)
            Log.d(TAG, "sub dir not created, already exists");
        return base_dir;
    }

}
