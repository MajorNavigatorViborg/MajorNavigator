package com.xray.bt.monitor2;

import java.util.Timer;
import java.util.TimerTask;
import android.os.Handler;
import android.os.Message;
import android.content.Context;
import android.util.Log;

public class MainViewController implements Handler.Callback {
	private static final String TAG = "BtViewController";
	
    private IViewController mSink;
    private Context mCtx;
	private Handler mHandler;
    private String[] mThresholds, mModes;
	private float[] mThresholdVals;
    private String mStrWaitRead, mStrWaitWrite, mStrWaitOther;
    private int mStateTimeoutMs, mDefaultStateTimeoutMs;
	private Timer mTimer;
    
    private final static int MSG_UPDATE_STATE = 1;
    private final static int MSG_UPDATE_HEADER = 2;
    private final static int MSG_UPDATE_FOOTER = 3;
	private final static int MSG_UPDATE_MESSAGE = 4;
	private final static int MSG_TRY_RESET_THEFT = 5;
	private final static int MSG_RESET_ALERTS_LOCALLY = 6;
	private final static int MSG_NOTHING_TO_RESET = 7;

	private enum BeepType { NO, SHORT, LONG };
	private enum AlertType { NO, THEFT, OVERFLOW, UNDERFLOW };
	private enum PresenseType { UNKNOWN, PRESENT, ABSENT };

	private int mMode = -1;
	private PresenseType mGsm = PresenseType.UNKNOWN;
	private State mLastState = null;
	private int mLastLiveTimeoutSec;
	private AlertType mCurrentAlert = AlertType.NO, mPrevAlert = null;
	private float mMaxValueForOverflow = -1, mMinValueForUnderflow = -1;

    private class ViewState {
        public ViewState() {
			beep = BeepType.NO; vibrate = false; testName = null;
			showBatteryRr = true; showRssiRr1 = true; showRssiRr2 = true; peakText = null;
		}
        public String signal;
        public String threshold;
        public int batteryBd, batteryRr, batteryKs;
        public int rssiBd, rssiRr1, rssiRr2, rssiKs, rssiGsm;
        public String alertText;
        public int alertColor;
        public String mode;
        public BeepType beep;
        public boolean vibrate;
		public boolean showBatteryRr;
		public boolean showRssiRr1;
		public boolean showRssiRr2;
		public String peakText;
		public String testName;

        public String toString() {
            return String.format(
                "signal='%s', threshold='%s', batBd=%d, batRr=%d, batKs=%d, " +
                "rssiBd=%d, rssiRr1=%d, rssiRr2=%d, rssiKs=%d rssiGsm=%d, " +
                "alert='%s'/%08x, mode='%s', beep=%s, vibr=%s, showBatRr=%s, " +
				"showRssiRr1=%s, showRssiRr2=%s, peakText='%s', testName='%s'",
                signal, threshold, batteryBd, batteryRr, batteryKs,
                rssiBd, rssiRr1, rssiRr2, rssiKs, rssiGsm,
                alertText, alertColor, mode, beepToStr(beep), vibrate ? "YES" : "NO",
				showBatteryRr ? "YES" : "NO", showRssiRr1 ? "YES" : "NO", showRssiRr2 ? "YES" : "NO",
				peakText != null ? peakText : "",
                testName);
        }

        public String beepToStr(BeepType b) {
            switch (b) {
                case NO: return "NO";
                case SHORT: return "SHORT";
                case LONG: return "LONG";
                default: return "?";
            }
        }
    }

    public MainViewController(IViewController sink, Context context, int defaultStateTimeoutMs) {
		mSink = sink;
        mCtx = context;
        mHandler = new Handler(this);
        mLastLiveTimeoutSec = defaultStateTimeoutMs / 1000;
		
        mThresholds = context.getResources().getStringArray(R.array.thresholds);
		try {
			mThresholdVals = new float[mThresholds.length];
			for (int i = 0 ; i < mThresholds.length; i++) {
				final String str_val = mThresholds[i].replace(',', '.');
				mThresholdVals[i] = Float.parseFloat(str_val);
			}
		} catch (NumberFormatException e) {
			// this will lead to 'threshold_valid' be always false:
			mThresholds = new String[0];
			mThresholdVals = new float[0];
		}
		
        mModes = context.getResources().getStringArray(R.array.modes);
        mStrWaitRead = context.getResources().getString(R.string.waiting_read_request);
		mStrWaitWrite = context.getResources().getString(R.string.waiting_write_request);
        mStrWaitOther = context.getResources().getString(R.string.waiting_other_request);
        mStateTimeoutMs = defaultStateTimeoutMs;
		mDefaultStateTimeoutMs = defaultStateTimeoutMs;
    }

    public void init() {
        ViewState vs = new ViewState();
        // assume that newly constructed ViewState looks resonable
        updateViewState(vs);
        updateHeader(false);
    }

    public void startFirstStateTimer() {
        startStateTimer();
    }

    public void stop() {
        stopStateTimer();
    }

    public void requestReadSent() {
		mHandler.obtainMessage(MSG_UPDATE_FOOTER, mStrWaitRead).sendToTarget();
    }

	public void requestWriteSent(boolean params_or_reset) {
		mHandler.obtainMessage(MSG_UPDATE_FOOTER, 
            params_or_reset ? mStrWaitWrite : mStrWaitOther).sendToTarget();
	}

    public void requestAckdOrLost() {
		mHandler.obtainMessage(MSG_UPDATE_FOOTER, "").sendToTarget();
    }

	public void sharmMessage(byte[] data) {
		mHandler.obtainMessage(MSG_UPDATE_MESSAGE, data).sendToTarget();
	}

	public void handleUserConfig(UserConfig cfg) {
		Log.d(TAG, "handle user config: " + cfg.toString());
		
		if (cfg.gsm == 1)
			mGsm = PresenseType.PRESENT;
		else if (cfg.gsm == 0)
			mGsm = PresenseType.ABSENT;
		else
			mGsm = PresenseType.UNKNOWN;
		
		if (mLastState != null) {
			mLastLiveTimeoutSec = cfg.liveTime;
			mLastState.threshold = cfg.threshold;
			mLastState.mode = cfg.mode;
			Log.d(TAG, "simulating handleState with saved state");
			handleState(mLastState); // state timeout will be handled from inside here
		}
		else
			handleLiveTimeoutAndMode(cfg.liveTime, cfg.mode);
	}

	public void handleResetPressed() {
		switch (mCurrentAlert) {
			case THEFT:
				mHandler.obtainMessage(MSG_TRY_RESET_THEFT).sendToTarget();
				break;
			case OVERFLOW:
			case UNDERFLOW:
				mHandler.obtainMessage(MSG_RESET_ALERTS_LOCALLY).sendToTarget();
				break;
			default:
				mHandler.obtainMessage(MSG_NOTHING_TO_RESET).sendToTarget();
				break;
		}
	}

	public void handleResetAlertAccepted() {
		mHandler.obtainMessage(MSG_RESET_ALERTS_LOCALLY).sendToTarget();
	}

    // can be invoked from any thread
    public void handleState(State s) {
		Log.d(TAG, "handle state: " + s.toString());
		mLastState = s;

		handleModeFromState(s.mode);
        clearHeaderAndRestartStateTimer();
		
        ViewState vs = new ViewState();
		vs.signal = workSignalToStr(s.workSignal, null);

		boolean threshold_valid = true;
        if (s.threshold >= mThresholds.length) {
            vs.threshold = mCtx.getString(R.string.invalid_threshold);
			threshold_valid = false;
		}
        else
            vs.threshold = mThresholds[s.threshold];

        vs.batteryBd = convertBattery(s.batteryBd);
        vs.batteryRr = convertBattery(s.batteryRr);
        vs.batteryKs = convertBattery(s.batteryKs);

        vs.rssiBd = convertOneToOneRssi(s.rssiBd);
        vs.rssiRr1 = convertOneToOneRssi(s.rssiRr1);
        vs.rssiRr2 = convertOneToOneRssi(s.rssiRr2);
        vs.rssiKs = convertOneToOneRssi(s.rssiKs);
        vs.rssiGsm = convertGsmRssi(s.rssiGsm);

		if (s.stateGyro) {
			vs.alertText = mCtx.getString(R.string.alert_theft);
			vs.alertColor = 0xFFFF0000; // red
			vs.beep = BeepType.SHORT;
			vs.vibrate = true;
			mPrevAlert = mCurrentAlert;
			mCurrentAlert = AlertType.THEFT;
		}
		else {
			if (threshold_valid) {
				Log.d(TAG, String.format("signal = %.3f, threshold = %.3f", s.workSignal, mThresholdVals[s.threshold]));

				switch (s.mode) {
					case 0: // "измеритель"
						vs.alertText = mCtx.getString(R.string.alert_measure);
						vs.alertColor = 0xFF00FF00; // green
						mPrevAlert = mCurrentAlert;
						mCurrentAlert = AlertType.NO;
						Log.d(TAG, "mode 0, no alert");
						break;
					case 1: // "сигнализатор"
						mPrevAlert = mCurrentAlert;
						if (s.workSignal >= mThresholdVals[s.threshold]) {
							mCurrentAlert = AlertType.OVERFLOW;
							Log.d(TAG, "mode 1, signal is adove, will alert");
						}
						else {
							Log.d(TAG, "mode 1, signal is below, alert remains");
						}
						break;
					case 2: // "сторож"
						mPrevAlert = mCurrentAlert;
						if (s.workSignal < mThresholdVals[s.threshold]) {
							mCurrentAlert = AlertType.UNDERFLOW;
							Log.d(TAG, "mode 2, signal is below, will alert");
						}
						else {
							Log.d(TAG, "mode 2, signal is above, alert remains");
						}
						break;
					default:
						break; // invalid mode will be handled right after
				}
			} // threshold is comparable

			if (mCurrentAlert == mPrevAlert) {
				Log.d(TAG, "same alert");
				if (mCurrentAlert == AlertType.OVERFLOW) {
					if (s.workSignal > mMaxValueForOverflow)
						mMaxValueForOverflow = s.workSignal;
				}
				else if (mCurrentAlert == AlertType.UNDERFLOW) {
					if (s.workSignal < mMinValueForUnderflow)
						mMinValueForUnderflow = s.workSignal;
				}
			}
			else {
				Log.d(TAG, "initialize peak values");
				mMaxValueForOverflow = s.workSignal;
				mMinValueForUnderflow = s.workSignal;
			}

		    if (mCurrentAlert == AlertType.OVERFLOW) {
				vs.alertText = mCtx.getString(R.string.alert_excess);
				vs.alertColor = 0xFFFF0000; // red
				vs.beep = BeepType.SHORT;
				vs.vibrate = true;
				vs.peakText = workSignalToStr(mMaxValueForOverflow, "max");
			}
			else if (mCurrentAlert == AlertType.UNDERFLOW) {
				vs.alertText = mCtx.getString(R.string.alert_decrease);
				vs.alertColor = 0xFFFF0000; // red
				vs.beep = BeepType.SHORT;
				vs.vibrate = true;
				vs.peakText = workSignalToStr(mMinValueForUnderflow, "min");
			}
			else { // measure mode OR the signal is ok
				vs.peakText = null; // means hide completely min/max value
			}
		} // no theft (gyro) alert

		if (s.mode >= mModes.length)
			vs.mode = mCtx.getString(R.string.invalid_mode);
		else
			vs.mode = mModes[s.mode];

		if (mCurrentAlert == AlertType.NO) { // no alerts at this point
			vs.vibrate = false;
			vs.beep = BeepType.NO;

			if (isAlertOnMandatoryModule(vs.batteryBd, vs.rssiBd, true, "BD") ||
				isAlertOnOptionalModule(vs.batteryRr, vs.rssiRr1, vs.rssiRr2, "RR") ||
				isAlertOnMandatoryModule(vs.batteryKs, vs.rssiKs, true, "KS") ||
				isAlertOnMandatoryModule(0xffff, vs.rssiGsm, mGsm != PresenseType.ABSENT, "GSM"))
			{
				vs.beep = BeepType.LONG;
				vs.vibrate = true;
			}
		}

		if (s.batteryRr == 0 && s.rssiRr1 == 0 && s.rssiRr2 == 0) { // RR is absent just hide the whole line
			vs.showBatteryRr = false;
			vs.showRssiRr1 = false;
			vs.showRssiRr2 = false;
		} else {
			vs.showBatteryRr = true;
			vs.showRssiRr1 = true;
			vs.showRssiRr2 = true;
		}

		vs.testName = s.testName;

		mHandler.obtainMessage(MSG_UPDATE_STATE, vs).sendToTarget();
    }

	public boolean handleMessage(Message msg) {
		switch (msg.what) {
			case MSG_UPDATE_STATE: {
				updateViewState((ViewState)msg.obj);
                break;
            }
            case MSG_UPDATE_HEADER: {
                updateHeader((boolean)msg.obj);
                break;
            }
            case MSG_UPDATE_FOOTER: {
                updateFooter((String)msg.obj);
                break;
            }
			case MSG_UPDATE_MESSAGE: {
				mSink.onSharmMessageOnMainThread((byte[])msg.obj);
				break;
			}
			case MSG_TRY_RESET_THEFT: {
				mSink.onSendReset();
				break;
			}
			case MSG_RESET_ALERTS_LOCALLY: {
				resetAlertsLocally();
				break;
			}
			case MSG_NOTHING_TO_RESET: {
				mSink.onNothingToResetWarning();
				break;
			}
			default:
		}
		return true;
    }

    public static int requestTimeoutMsFromMode(int mode, int live_time_s) {
        if (mode == 0) return 25000;
        else return (live_time_s + 10) * 1000;
    }

    private void handleModeFromState(int mode) {
		Log.d(TAG, "new mode from state = " + mode);
		handleLiveTimeoutAndMode(mLastLiveTimeoutSec, mode);
    }

    private void handleLiveTimeoutAndMode(int seconds, int mode) {
		mMode = mode;
		Log.d(TAG, "new mode " + mode);
		if (seconds != -1) {
			mLastLiveTimeoutSec = seconds;
			// NOTE will affect only after ongoing timeout expiration or State arrival
			if (mMode == 1 || mMode == 2)
				mStateTimeoutMs = (seconds + 10) * 1000;
			else if (mMode == 0)
				mStateTimeoutMs = mDefaultStateTimeoutMs;
			// NOTE without known mode the default timeout will remain
			// NOTE in mode 0 the default timeout will be used
			Log.d(TAG, "new timeout " + mStateTimeoutMs + " ms");
		}
    }

    private int convertBattery(int received_level) {
        if (received_level < 0 || received_level > 15)
            return -1;
        else
            return received_level * 100 / 15;
    }

    private int convertOneToOneRssi(int received_level) {
        if (received_level < 0 || received_level > 3)
            return -1;
        else
            return received_level;
    }

    private int convertGsmRssi(int received_level) {
        if (received_level < 0 || received_level > 15)
            return -1;
        else
            return received_level / 4;
    }

    private void updateViewState(ViewState vs) {
        Log.d(TAG, "updateView: " + vs.toString());
        
        mSink.onWorkSignal(vs.signal);
        mSink.onThreshold(vs.threshold);
        mSink.onAlert(vs.alertText, vs.alertColor);

		switch (vs.beep) {
			case NO: mSink.onEndBeep(); break;
			case SHORT: mSink.onStartShortBeep(); break;
			case LONG: mSink.onStartLongBeep(); break;
			default: break;
		}

        if (vs.vibrate)
            mSink.onStartVibrate();
        else
            mSink.onEndVibrate();

        mSink.onBdBatteryValue(vs.batteryBd);
        mSink.onRrBatteryValue(vs.batteryRr);
        mSink.onKsBatteryValue(vs.batteryKs);

        mSink.onBdRssiValue(vs.rssiBd);
        mSink.onRr1RssiValue(vs.rssiRr1);
        mSink.onRr2RssiValue(vs.rssiRr2);
        mSink.onKsRssiValue(vs.rssiKs);
        mSink.onGsmRssiValue(vs.rssiGsm);

		mSink.onRrLineVisibility(vs.showBatteryRr, vs.showRssiRr1, vs.showRssiRr2);

        mSink.onSetMode(vs.mode);
		mSink.onPeakText(vs.peakText);

		mSink.onTestName(vs.testName);
	}

    private void stateTimerElapsed() {
        Log.d(TAG, "state timeout elapsed");
		mHandler.obtainMessage(MSG_UPDATE_HEADER, true).sendToTarget(); // show label
    }

    private void updateHeader(boolean showOrHide) {
        if (showOrHide)
            mSink.onShowHeaderStatus();
        else
            mSink.onHideHeaderStatus();
    }

    private void updateFooter(String text) {
        mSink.onSetFooter(text);
    }

	private void resetAlertsLocally() {
		mSink.onEndVibrate();
		mSink.onEndBeep();
		mSink.onAlert("", 0);
		mSink.onPeakText(null);
		mPrevAlert = mCurrentAlert;
		mCurrentAlert = AlertType.NO;
	}

    private void startStateTimer() {
        try {
            Log.d(TAG, "starting state timer with " + mStateTimeoutMs + " peroid");
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        stateTimerElapsed();
                    }
                }, mStateTimeoutMs);
        } catch (Exception e) {
			// Log.e(TAG, "TIMER ERROR: " + e.getMessage());
		}
    }

    private void stopStateTimer() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    private void clearHeaderAndRestartStateTimer() {
		mHandler.obtainMessage(MSG_UPDATE_HEADER, false).sendToTarget(); // hide label
        stopStateTimer();
        startStateTimer();
    }

	private String workSignalToStr(float signal, String prefix) {
		if (signal < 10) {
			if (prefix == null)
				return String.format("%.2f", signal);
			else
				return String.format("%s %.2f", prefix, signal);
		}
		else {
			if (prefix == null)
				return String.format("%.0f", signal);
			else
				return String.format("%s %.0f", prefix, signal);
		}
	}

	private boolean isAlertOnMandatoryModule(int batt_level, int rssi_level, boolean externally_on, String title) {
		String prefix = "module \"" + title + "\": ";
		if (!externally_on) {
			Log.d(TAG, prefix + "externally off");
			return false;
		}
		if (batt_level < 15) {
			Log.d(TAG, prefix + "battery alert!");
			return true;
		}
		if (rssi_level == 0) {
			Log.d(TAG, prefix + "rssi alert!");
			return true;
		}
		Log.d(TAG, prefix + "(no alert)");
		return false;
	}

	private boolean isAlertOnOptionalModule(int batt_level, int rssi_level_1, int rssi_level_2, String title) {
		String prefix = "module \"" + title + "\": ";
		if (batt_level == 0 && rssi_level_1 == 0 && rssi_level_2 == 0) {
			Log.d(TAG, prefix + "externally off");
			return false;
		}
		if (batt_level < 15) {
			Log.d(TAG, prefix + "battery alert!");
			return true;
		}
		if (rssi_level_1 == 0 || rssi_level_2 == 0) {
			Log.d(TAG, prefix + "rssi alert!");
			return true;
		}
		Log.d(TAG, prefix + "(no alert)");
		return false;
    }
}
