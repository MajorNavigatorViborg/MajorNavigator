package com.xray.bt.monitor2;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import android.os.ParcelUuid;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Timer;
import java.util.TimerTask;

public class BtManager implements IBtManager {
	private static final String TAG = "BtManager";
	private static int SHARM_CHANNEL = 6;

	BluetoothAdapter mBtAdapter = null;

    private BroadcastReceiver mReceiver = null;
	private final IntentFilter mIntentFilter = new IntentFilter();

	private enum BtState {
		not_supp, on, turning_on, off,
	};
	private BtState mState;

	private ArrayList<BluetoothDevice> mNewDevices;
	private BtObserver mObserver;
	private Context mContext;
	private BtServiceUuids mUuidNames = new BtServiceUuids();
	private String[] mFilters;

	private Timer mDiscoveryTimer;
	private static final int MAX_DISCOVERY_TIME = 15;

	public BtManager(BtObserver obs, Context ctx, String[] filters) {
		mObserver = obs;
		mContext = ctx;
		mFilters = filters;
		synchronized (this) {
			mBtAdapter = BluetoothAdapter.getDefaultAdapter();
			if (mBtAdapter == null) {
				mState = BtState.not_supp;
				return;
			}
			if (mBtAdapter.isEnabled())
				mState = BtState.on;
			else
				mState = BtState.off;
		}

		mIntentFilter.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
		//mIntentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
		mIntentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		mIntentFilter.addAction(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		mIntentFilter.addAction(BluetoothDevice.ACTION_FOUND);
	}

	public boolean enableWillResumeActivity() {
		return true;
	}

	public void subscribe() {
		Log.d(TAG, "subscribing...");
		if (mState == BtState.not_supp)
			return;
        mReceiver = new BtReceiver(this);
//ANT		mContext.registerReceiver(mReceiver, mIntentFilter);
        ContextCompat.registerReceiver(mContext, mReceiver, mIntentFilter, ContextCompat.RECEIVER_NOT_EXPORTED);
		Log.d(TAG, "subscribed");
	}		

	public void unsubscribe() {
		Log.d(TAG, "unsubscribing...");
		if (mState == BtState.not_supp || mReceiver == null)
			return;
        mContext.unregisterReceiver(mReceiver);
		mReceiver = null;
		Log.d(TAG, "unsubscribed");
	}

	public boolean isEnabled() {
		synchronized (this) {
			return mState == BtState.on;
		}
	}

	public boolean isSupported() {
		synchronized (this) {
			return mState != BtState.not_supp;
		}
	}

	public void requestEnable(Activity activity) {
		Intent enableIntent = new Intent(
			BluetoothAdapter.ACTION_REQUEST_ENABLE);
		synchronized(this) {
			mState = BtState.turning_on;
			activity.startActivityForResult(enableIntent, ActivityCodes.ENABLE_BT);
		}
		Log.d(TAG, "enable request pending...");
	}

	public void disable() {
		synchronized(this) {
			if (mState == BtState.off) {
				Log.d(TAG, "disable: already off!");
			} else {
				if (mBtAdapter.disable()) {
					mState = BtState.off;
					Log.d(TAG, "disabled");
				}
				else
					Log.d(TAG, "disable: could not disable!");
			}
		}
	}
	
	public boolean checkActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == ActivityCodes.ENABLE_BT) {
			Log.d(TAG, "enable request result");
			synchronized(this) {
				if (resultCode == Activity.RESULT_OK) {
					Log.d(TAG, "enable request satisfied");
					if (mBtAdapter.enable()) {
						// NOTE shouldn't it be turning on???
						mState = BtState.on;
						Log.d(TAG, "enabled");
						mObserver.onEnabled();
					}
					else {
						Log.d(TAG, "could not enabled");
						mState = BtState.off;
						mObserver.onErrorEnabling();
					}
				}
				else {
					Log.d(TAG, "enable request denied");
					mState = BtState.off;
					mObserver.onDeniedEnabling();
				}
			}
			return true;
		}
		else
			return false;
	}

	public void startScanning() {
		if (mState == BtState.on) {
			Log.d(TAG, "discovery started");
			mNewDevices = new ArrayList<BluetoothDevice>(4);
			mBtAdapter.startDiscovery();
			synchronized(this) {
				mDiscoveryTimer = new Timer();
			}
			mDiscoveryTimer.schedule(new TimerTask() {
					@Override
					public void run() {
						mDiscoveryTimer = null;
						Log.d(TAG, "discovery timeout, force finish");
                        mBtAdapter.cancelDiscovery();
						onDiscoveryFinished();
					}
				},
				MAX_DISCOVERY_TIME * 1000);
		}
		else
			Log.d(TAG, "wrong state for discovery!");
	}

	public void onNewDeviceFound(
		BluetoothDevice device, BluetoothClass clas, String name)
	{
        if (mNewDevices == null) {
            Log.e(TAG, "device " + name + " is found after discovery complete, ignore it");
            return;
        }

        final String addr = device.getAddress();
        if (isDuplicateAddr(addr)) {
            Log.e(TAG, "duplicate addr " + addr + ", ignore it");
            return;
        }

		boolean addDevice = false;
		if (mFilters != null) {
			for (String f : mFilters) {
				if (name != null &&
					name.toUpperCase().contains(f.toUpperCase()))
				{
					addDevice = true;
					break;
				}
			}
		}
		else
			addDevice = true;

		if (addDevice) {
			Log.d(TAG, "Found device " + name + " / " + addr +
                " majorClass " + clas.getMajorDeviceClass() + " class " + clas.getDeviceClass());
			mNewDevices.add(device);
		}
	}

	public void onDiscoveryFinished() {
		Log.d(TAG, "discovery completed");
		synchronized(this) {
			if (mDiscoveryTimer != null) {
				Log.d(TAG, "killing discovery active timer");
				mDiscoveryTimer.cancel();
				mDiscoveryTimer = null;
			}
		}
		if (mNewDevices == null) return;
		FoundDevice[] newDevices = new FoundDevice[mNewDevices.size()];
		int i = 0;
		for (BluetoothDevice dev : mNewDevices) {
			newDevices[i] = new FoundDevice(dev.getName(), dev.getAddress());
			Log.d(TAG, "found device: " + newDevices[i]);
			++i;
		}
		mObserver.onDiscoveryFinished(newDevices);
		mNewDevices = null;
	}

	public FoundDevice[] getPairedDevices() {
		synchronized(this) {
			if (mState != BtState.on) {
				Log.d(TAG, "could not get paired devices: not enabled");
				return null;
			}
		}
		Set<BluetoothDevice> pairedDevs = mBtAdapter.getBondedDevices();
		ArrayList<FoundDevice> bondedDevices = new ArrayList<FoundDevice>();
		for (BluetoothDevice dev : pairedDevs) {
			boolean addDevice;
			final String name = dev.getName();
			if (mFilters == null)
				addDevice = true;
			else {
				addDevice = false;
				for (String f : mFilters) {
					if (name != null &&
						name.toUpperCase().contains(f.toUpperCase()))
						{
							addDevice = true;
							break;
						}
				}
			}
			if (addDevice) {
				bondedDevices.add(new FoundDevice(name, dev.getAddress()));
				Log.d(TAG, "bonded device: " + dev.getAddress());
			}
		}
		return bondedDevices.toArray(new FoundDevice[bondedDevices.size()]);
	}
	
	public SocketInterface connectToDevice(String addr) {
		synchronized(this) {
			if (mState != BtState.on) {
				Log.d(TAG, "could not connect: not enabled");
				return null;
			}
		}
		mBtAdapter.cancelDiscovery();

		Log.i(TAG, "BtSocket: connecting to device " + addr);
		BluetoothDevice dev = mBtAdapter.getRemoteDevice(addr);
		BluetoothSocket sock = null;

		int tries = 0;
		while (tries < 3) {
			try {
				switch (tries) {
					case 0:
						Log.d(TAG, "method SENA");
						sock = dev.createRfcommSocketToServiceRecord(BtServiceUuids.SPP_UUID);
						break;
					case 1:
						Log.d(TAG, "method OSA");
						sock = dev.createInsecureRfcommSocketToServiceRecord(BtServiceUuids.SPP_UUID);
						break;
					case 2:
						Log.d(TAG, "method OSA (reflection)");
						Method m = dev.getClass().getMethod("createInsecureRfcommSocket", new Class[] { int.class });
						sock = (BluetoothSocket)m.invoke(dev, Integer.valueOf(SHARM_CHANNEL));
						break;
					default:
						break;
				}
				BtSocket btSock = new BtSocket(sock);
				if (btSock.connect()) {
					Log.d(TAG, "connected");
					return btSock;
				}
				else {
					Log.e(TAG, "could not connect");
				}
			} catch (IOException e) {
				Log.e(TAG, "could not connect rfcomm to spp");
			} catch (NoSuchMethodException e) {
				Log.e(TAG, "no such method");
			} catch (IllegalAccessException e) {
				Log.e(TAG, "illegal access");
			} catch (InvocationTargetException e) {
				Log.e(TAG, "invocation target exception");
			}
			tries++;
		}
            
		return null;
	}

    private boolean isDuplicateAddr(String addr) {
        for (BluetoothDevice dev : mNewDevices) {
            if (dev.getAddress().equals(addr))
                return true;
        }
        return false;
    }

}
