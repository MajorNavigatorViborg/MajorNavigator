package com.xray.bt.monitor2;

import android.app.Activity;
import android.content.Intent;

public interface IBtManager {

    public boolean isSupported();

    public boolean isEnabled();

    public void requestEnable(Activity activity);

	public boolean checkActivityResult(int requestCode, int resultCode, Intent data);

    public void subscribe();

    public void unsubscribe();

    public void startScanning();

    public SocketInterface connectToDevice(String addr);

    public FoundDevice[] getPairedDevices();

	public boolean enableWillResumeActivity();
}
