package com.xray.bt.monitor2;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.locks.ReentrantLock;
import java.io.IOException;
import java.lang.reflect.Method;

import android.util.Log;

public class SharmDevice implements ISharmReaderObserver, ISharmPacketObserver
{
	private static final int READ_BUF_SZ = 256;
	private static final String TAG = "SharmDevice";

	private ISharmDevice mSink;
    private SocketInterface mSock = null;
    private int mReqTimeoutMs;
    private boolean mExit = false;
    private Thread mRecvThread;
	private boolean mRequestPending = false;
	private Transaction mTransaction = Transaction.NONE;
	private ReentrantLock mLock = new ReentrantLock();
	private Timer mReqTimer;
	private final String[] mFakeIncomingData;
	private final boolean mSocketWriteFakeThrow;
	private ISharmIncomingPacket mIncomingPacket;
	private ISharmOutgoingPacket mOutgoingPacket;
    private ISharmReader mReader;

    // start thread(s) and listen to socket
    public SharmDevice(
		ISharmDevice sink, int requestTimeoutMs,
		String[] fakeIncomingData, boolean socketWriteFakeThrow)
	{
		mSink = sink;
		mFakeIncomingData = fakeIncomingData;
		mSocketWriteFakeThrow = socketWriteFakeThrow;
        mReqTimeoutMs = requestTimeoutMs;
		if (fakeIncomingData == null) {
			mIncomingPacket = new SharmPacket.Incoming();
			mOutgoingPacket = new SharmPacket.Outgoing();
            mReader = new SharmReader(this);
		} else {
			mIncomingPacket = new SharmFakePacket.Incoming();
			mOutgoingPacket = new SharmFakePacket.Outgoing();
            mReader = new SharmFakeReader(this);
		}
    }

    public void setRequestTimeout(int timeout_ms) {
        mReqTimeoutMs = timeout_ms;
    }

    public void start(SocketInterface sock) {
        System.out.println("start enter");
		mSock = sock;
		mExit = false;
        mReader.delimitRecvLog("start");
        mRecvThread = new Thread() {
				@Override
				public void run() {
					receiveThread();
				}
			};
		mRecvThread.start();
        System.out.println("start leave");
    }

    // stop even if the socket alive; upon exit the receiving thread is guaranteed not be active
    public void stop() {
		if (mSock == null)
			return;
		System.out.println("stop enter");
        mExit = true;
		stopTimer();
        mRecvThread.interrupt();
		try {
			mRecvThread.join();
		} catch (InterruptedException e) {
		}
        mReader.delimitRecvLog("stop");
		System.out.println("stop leave");
    }
	
    private boolean sendAnyRequest(SharmSendContext ctx) {
		mLock.lock();
		if (!mRequestPending || !ctx.blocking()) {
			try {
				if (mFakeIncomingData == null) {
					SharmMessage msg = new SharmMessage(ctx.data());
					mSock.write(msg.serialize());
				}
				else if (mSocketWriteFakeThrow)
					throw new IOException();
				if (ctx.needRsp()) {
					mRequestPending = true;
					mTransaction = ctx.transaction();
					startTimer();
				}
				mLock.unlock();
				return true;
			} catch (Exception e) {
				// e.printStackTrace();
				stop();
				mLock.unlock();
				mSink.onSocketError();
				Log.d(TAG, "sendResetAlert: not sent, socket or method error");
				return false;
			}
		}
		else {
			mLock.unlock();
			Log.d(TAG, "sendResetAlert: not sent, previous request is pending");
		}
		return false;
    }

    public boolean sendResetAlert() {
        Log.d(TAG, "reset alert");
		SharmSendContext ctx = mOutgoingPacket.serializeResetAlert();
		return sendAnyRequest(ctx);
	}	

	public boolean sendUserConfigRequest() {
        Log.d(TAG, "user config request");
		SharmSendContext ctx = mOutgoingPacket.serializeUserConfigRequest();
		return sendAnyRequest(ctx);
	}

    public boolean sendSysConfigRequest() {
        Log.d(TAG, "sys config request");
		SharmSendContext ctx = mOutgoingPacket.serializeSysConfigRequest();
		return sendAnyRequest(ctx);
    }

	public boolean sendUserConfigSetup(UserConfig cfg) {
		Log.d(TAG, "user config setup");
		SharmSendContext ctx = mOutgoingPacket.serializeUserConfigSetup(cfg);
		return sendAnyRequest(ctx);
	}

	public boolean sendSysConfigSetup(SysConfig cfg) {
		Log.d(TAG, "sys config setup");
		SharmSendContext ctx = mOutgoingPacket.serializeSysConfigSetup(cfg);
		return sendAnyRequest(ctx);
	}	

	public boolean isRequestPending() {
		boolean ret;
		mLock.lock();
		ret = mRequestPending;
		mLock.unlock();
		return ret;
	}

    public String recvLogAsMultilineString() {
        return mReader.recvLogAsMultilineString();
    }

	public void timerRun() { // timer elapsed
		stopTimer();
		mLock.lock();
		mRequestPending = false;
		mLock.unlock();
		mSink.onResponseTimeout();
	}

    private void receiveThread() {
		System.out.println("receiveThread: started");
		byte[] buf = new byte[READ_BUF_SZ];
		int fakeCnt = 0;
		
		while (!mExit) {
			try {
				if (mFakeIncomingData == null) {
					int avail = mSock.bytesAvailable();
					if (avail > 0) {
						// Log.d(TAG, "socket has " + avail + " bytes to read");
						int rb = mSock.read(buf);
						Log.d(TAG, "read " + rb + " bytes from socket: " + HexUtils.bytesToHexString(buf, rb));
						mReader.addData(buf, rb); // here onMessage() or onParseError() may be called multiple times
					}
					else {
						sleepMs(100);
					}
				} else {
					// System.out.println("receiveThread: simulation, cnt = " + fakeCnt);
					if (fakeCnt < mFakeIncomingData.length) {
						final String fakeMsg = mFakeIncomingData[fakeCnt];
						if (fakeMsg == null) {
							throw new IOException();
						} else if (fakeMsg.isEmpty()) {
							System.out.println("receiveThread: nothing, sleep 100 ms");
							sleepMs(100);
						} else {
							try { // simulate delay indicated by the number
								int delay_sec = Integer.parseInt(fakeMsg);
								System.out.println("receiveThread: delay of " + delay_sec);
								sleepMs(delay_sec);
							}
							catch (NumberFormatException e) { // pass to parser
								System.out.println("receiveThread: string " + fakeMsg);
								final byte[] data = fakeMsg.getBytes("utf-8");
								mReader.addData(data, data.length); // here onMessage() or onParseError() may be called
							}
						}
						fakeCnt++;
					}
					else {
						sleepMs(100);
					}
				}
			}
			catch (IOException e) {
				e.printStackTrace();
				mLock.lock();
				stopTimer();
				mLock.unlock();
				mSink.onSocketError();
				break;
			}
		}
		System.out.println("receiveThread: leave");
    }

	// ISharmReaderObserver
	
	@Override
	public void onMessage(byte[] data) {
		System.out.println("onMessage");
		mSink.onSharmMessage(data);
		if (mIncomingPacket.isAsync(data)) {
			System.out.println("onMessage: async");
			mIncomingPacket.parse(data, this);
			return;
		}
		System.out.println("onMessage: response");
		mLock.lock();
		if (mRequestPending) {
			System.out.println("pending, ok");
			final Transaction trans = mIncomingPacket.getTransaction(data);
			stopTimer();
			mRequestPending = false;
			mLock.unlock();
            if (trans != Transaction.UNKNOWN) {
                if (trans == mTransaction) {
                    mIncomingPacket.parse(data, this);
                } else {
                    System.out.printf("mismatch, expected %d got %d\n", mTransaction.ordinal(), trans.ordinal());
                    mSink.onResponseMismatch();
                }
            }
            else {
                onParseError("missing msg id (empty packet?)");
            }
		} else {
			System.out.println("not pending!");			
			mLock.unlock();
			mSink.onResponseTooLate();
		}
	}

	@Override
	public void onParseError(String what) {
		System.out.println("onParseError: " + what);
		stop();
		mSink.onParseError(what);
	}

	// ISharmPacketObserver

	@Override
	public void onState(State state) {
        System.out.println("onState: " + state.toString());
		mSink.onStateReceived(state);
	}

	@Override
	public void onUserConfig(UserConfig cfg) {
		mSink.onUserConfigReceived(cfg);
	}

	@Override
	public void onSysConfig(SysConfig cfg) {
		mSink.onSysConfigReceived(cfg);
	}

	@Override
	public void onParsePacketError(String msg) {
		System.out.println("onParsePacketError: " + msg);
		stop();
		mSink.onParseError(msg);
	}

    @Override
    public void onUserConfigAccepted() {
        mSink.onUserConfigAccepted();
    }

    @Override
    public void onSysConfigAccepted() {
        mSink.onSysConfigAccepted();
    }

	@Override
	public void onResetAlertAccepted() {
		mSink.onResetAlertAccepted();
	}

	// utility methods

	private void startTimer() {
		try {
			mReqTimer = new Timer();
			// Log.d(TAG, "SCHEDULE TIMER " + mReqTimer.toString());
			mReqTimer.schedule(new TimerTask() {
					@Override
					public void run() {
						timerRun();
					}
				}, mReqTimeoutMs);
		} catch (Exception e) {
			// Log.e(TAG, "TIMER ERROR: " + e.getMessage());
		}
	}

	private void stopTimer() {
		if (mReqTimer != null) {
			// Log.d(TAG, "CANCEL TIMER " + mReqTimer.toString());
			mReqTimer.cancel();
			mReqTimer = null;
		}
	}

	private void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}    
}
