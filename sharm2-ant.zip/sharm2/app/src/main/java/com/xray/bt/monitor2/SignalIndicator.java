package com.xray.bt.monitor2;

import android.view.View;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;

public class SignalIndicator extends View {
	private static final String TAG = "SignalIndicator";
    private static final boolean DBG_SPACE = false;

	int mNumBars;
    
	int mLowestBarHeightPercent;
	int mBarWidthPercent;
    
	Paint mSolidBarPaint, mEmptyBarPaint;
    Paint mSolidBarPaintMiddle, mEmptyBarPaintMiddle;
    Paint mSolidBarPaintLow, mEmptyBarPaintLow;
    
	int mLevel = 0;
    int mLowLimit, mMiddleLimit;

	public SignalIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.SignalIndicator);
		
		mNumBars = typedArray.getInt(R.styleable.SignalIndicator_numBars, 3);

		int color_good = typedArray.getColor(R.styleable.SignalIndicator_goodBarColor, Color.WHITE);
        int color_middle = typedArray.getColor(R.styleable.SignalIndicator_middleBarColor, Color.YELLOW);
        int color_low = typedArray.getColor(R.styleable.SignalIndicator_lowBarColor, Color.RED);
        
        mLowLimit = typedArray.getInt(R.styleable.SignalIndicator_lowBarLimit, 0);
        mMiddleLimit = typedArray.getInt(R.styleable.SignalIndicator_middleBarLimit, 1);
        
		mLowestBarHeightPercent = typedArray.getInt(R.styleable.SignalIndicator_lowestBarHeightPercent, 25);
		mBarWidthPercent = typedArray.getInt(R.styleable.SignalIndicator_barWidthPercent, 40);

		mSolidBarPaint = new Paint();
		mSolidBarPaint.setColor(color_good);
		mSolidBarPaint.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyBarPaint = new Paint();
		mEmptyBarPaint.setColor(color_good);
		mEmptyBarPaint.setStyle(Paint.Style.STROKE);
		mEmptyBarPaint.setStrokeWidth(2);

        mSolidBarPaintMiddle = new Paint();
		mSolidBarPaintMiddle.setColor(color_middle);
		mSolidBarPaintMiddle.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyBarPaintMiddle = new Paint();
		mEmptyBarPaintMiddle.setColor(color_middle);
		mEmptyBarPaintMiddle.setStyle(Paint.Style.STROKE);
		mEmptyBarPaintMiddle.setStrokeWidth(2);

        mSolidBarPaintLow = new Paint();
		mSolidBarPaintLow.setColor(color_low);
		mSolidBarPaintLow.setStyle(Paint.Style.FILL_AND_STROKE);
		
		mEmptyBarPaintLow = new Paint();
		mEmptyBarPaintLow.setColor(color_low);
		mEmptyBarPaintLow.setStyle(Paint.Style.STROKE);
		mEmptyBarPaintLow.setStrokeWidth(2);
		
		typedArray.recycle();
	}

	@Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (mLevel == -1)
            return;

        // Log.d(TAG, String.format("Level = %d, low = %d, middle = %d", mLevel, mLowLimit, mMiddleLimit));

        Paint emptyBarPaint, solidBarPaint;
        if (mLevel <= mLowLimit) {
            emptyBarPaint = mEmptyBarPaintLow;
            solidBarPaint = mSolidBarPaintLow;
        } else if (mLevel <= mMiddleLimit) {
            emptyBarPaint = mEmptyBarPaintMiddle;
            solidBarPaint = mSolidBarPaintMiddle;
        } else {
            emptyBarPaint = mEmptyBarPaint;
            solidBarPaint = mSolidBarPaint;
        }

		final int w = getWidth();
		final int h = getHeight();
		//Log.d(TAG, "w = " + w + ", h = " + h);
		final int section_width = w / mNumBars;
		final int y_first = h * (100 - mLowestBarHeightPercent) / 100;
		final int y_step = y_first / (mNumBars - 1);
		//Log.d(TAG, "y_first = " + y_first + ", y_step = " + y_step);

		int bar_y1 = y_first;

		for (int i = 0; i < mNumBars; i++, bar_y1 -= y_step) {
			Paint p;
			if (i >= mLevel)
				p = emptyBarPaint;
			else
				p = solidBarPaint;

			int bar_base_x1 = i * section_width;
			int spacing = (section_width * (100 - mBarWidthPercent) / 100 / 2);
			int bar_x1 = bar_base_x1 + spacing;
			int bar_x2 = bar_base_x1 + section_width - spacing;

			canvas.drawRect(bar_x1, bar_y1, bar_x2, h, p);

            if (DBG_SPACE)
                canvas.drawRect(1, 1, w-1, h-1, emptyBarPaint);
		}
	}

	// set level in range [0 ; numBars]
	public void setLevel(int level) {
		if (level <= mNumBars && level >= 0) {
			mLevel = level;
            invalidate();
        }
	}

    // set level in percent [0 ; 100]
    public void setPercent(int per) {
        setLevel(mNumBars * per / 100);
    }
	
}
