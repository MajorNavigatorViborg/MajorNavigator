package com.xray.bt.monitor2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothClass;

public class BtReceiver extends BroadcastReceiver {
	private BtManager mMgr;

	public BtReceiver(BtManager mgr) {
		super();
		mMgr = mgr;
	}

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
	    if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {
			mMgr.onDiscoveryFinished();
		}
		else if (action.equals(BluetoothDevice.ACTION_FOUND)) {
			mMgr.onNewDeviceFound(
				(BluetoothDevice)intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE),
				(BluetoothClass)intent.getParcelableExtra(BluetoothDevice.EXTRA_CLASS),
				intent.getStringExtra(BluetoothDevice.EXTRA_NAME));
		}
	}
}
