package com.xray.bt.monitor2;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.util.Log;

public class UserSetupActivity extends Activity {
	private static final String TAG = "UserSetupActivity";
	
    TextView mLiveTimeOld, mThresholdOld, mGyroSensOld, mGsmOld, mModeOld;

    EditText mLiveTimeNew;
    Spinner mThresholdNew, mGyroSensNew, mGsmNew, mModeNew;

    public static final String LIVE_TIME_OLD = "user_cfg_live_time_old";
    public static final String THRESHOLD_OLD = "user_cfg_threshold_old";
    public static final String GYRO_SENS_OLD = "user_cfg_gyro_sens_old";
    public static final String GSM_OLD = "user_cfg_gsm_old";
    public static final String MODE_OLD = "user_cfg_mode_old";

    public static final String LIVE_TIME_NEW = "user_cfg_live_time_new";
    public static final String THRESHOLD_NEW = "user_cfg_threshold_new";
    public static final String GYRO_SENS_NEW = "user_cfg_gyro_sens_new";
    public static final String GSM_NEW = "user_cfg_gsm_new";
    public static final String MODE_NEW = "user_cfg_mode_new";

    private int mGoodColor, mBadColor;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_setup);

        mGoodColor = getResources().getColor(android.R.color.white);
        mBadColor = getResources().getColor(android.R.color.holo_red_light);

        mLiveTimeOld = (TextView)findViewById(R.id.live_time_old);
        mThresholdOld = (TextView)findViewById(R.id.threshold_old);
        mGyroSensOld = (TextView)findViewById(R.id.gyro_sens_old);
        mGsmOld = (TextView)findViewById(R.id.gsm_old);
        mModeOld = (TextView)findViewById(R.id.mode_old);

        mLiveTimeNew = (EditText)findViewById(R.id.live_time_new);
        mThresholdNew = (Spinner)findViewById(R.id.threshold_new);
        mGyroSensNew = (Spinner)findViewById(R.id.gyro_sens_new);
        mGsmNew = (Spinner)findViewById(R.id.gsm_new);
        mModeNew = (Spinner)findViewById(R.id.mode_new);

        loadValues(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
		storeValues(outState);
	}

    @Override
	public void onBackPressed() {
        // no-op
    }

    public void btnAcceptClicked(View v) {
		String wrong_param = validate();
		if (wrong_param == null) {
			if (!wasSomethingChanged())
				cancelAndFinish();
			else
				showConfirmDialog(R.string.confirm_accept, R.string.confirm_cancel, true);
		}
		else
			showInvalidValueDialog(wrong_param);
    }

    public void btnDiscardClicked(View v) {
        showConfirmDialog(R.string.confirm_discard, R.string.confirm_return, false);
    }

    private void showConfirmDialog(int rcText, int rcCancelBtn, final boolean positiveSaveOrCancel) {
		new AlertDialog.Builder(this)
			.setTitle(R.string.confirmation)
			.setMessage(rcText)
			.setPositiveButton(R.string.confirm_yes,
				new DialogInterface.OnClickListener() {
                    public void onClick(
						DialogInterface dialog, int whichButton)
					{
						if (positiveSaveOrCancel)
							saveAndFinish();
						else
							cancelAndFinish();
					}
				})
            .setNeutralButton(rcCancelBtn, null)
			.show();
    }

	private void showInvalidValueDialog(String wrongParam) {
		new AlertDialog.Builder(this)
			.setTitle(R.string.invalid_config_param)
			.setMessage(wrongParam)
			.show();
	}

    private boolean wasSomethingChanged() {
        if (!mLiveTimeOld.getText().toString().equals(mLiveTimeNew.getText().toString()))
			return true;
		if (!mThresholdOld.getText().toString().equals(getSelectedSpinnerValue(mThresholdNew)))
			return true;		
		if (!mGyroSensOld.getText().toString().equals(getSelectedSpinnerValue(mGyroSensNew)))
			return true;
		if (!mGsmOld.getText().toString().equals(getSelectedSpinnerValue(mGsmNew)))
			return true;
		if (!mModeOld.getText().toString().equals(getSelectedSpinnerValue(mModeNew)))
			return true;		
		return false;
    }

	private String validate() {
		try {
            UserConfig cfg  = new UserConfig();
            cfg.liveTime = Integer.parseInt(mLiveTimeNew.getText().toString());
            return UserConfigAdapter.validate(cfg, this);
		} catch (NumberFormatException e) {}
		return getString(R.string.live_time);
	}

    private void loadValues(Bundle state) {
        if (state != null) {
            // restoring from freeze or background
            mLiveTimeOld.setText(String.format("%d", state.getInt(LIVE_TIME_OLD)));
            mGyroSensOld.setText(state.getString(GYRO_SENS_OLD));
            mThresholdOld.setText(state.getString(THRESHOLD_OLD));
            mGsmOld.setText(state.getString(GSM_OLD));
            mModeOld.setText(state.getString(MODE_OLD));

            mLiveTimeNew.setText(String.format("%d", state.getInt(LIVE_TIME_NEW)));
            selectSpinnerValue(mThresholdNew, state.getString(THRESHOLD_NEW));
			selectSpinnerValue(mGyroSensNew, state.getString(GYRO_SENS_NEW));
			selectSpinnerValue(mGsmNew, state.getString(GSM_NEW));
			selectSpinnerValue(mModeNew, state.getString(MODE_NEW));
        } else {
            // creating after activity launch
            Intent intent = getIntent();

			{
				int live_time = intent.getIntExtra(UserConfig.LIVE_TIME, 0);
				int live_time_fallback = intent.getIntExtra(UserConfig.LIVE_TIME_FB, -1);
				if (live_time_fallback == -1) {
					mLiveTimeOld.setText(String.format("%d", live_time));
					mLiveTimeNew.setText(String.format("%d", live_time));
					mLiveTimeOld.setTextColor(mGoodColor);
				} else {
					mLiveTimeOld.setText(String.format("%d", live_time));
					mLiveTimeNew.setText(String.format("%d", live_time_fallback));
					mLiveTimeOld.setTextColor(mBadColor);
				}
			}

			loadSpinnerParam(intent, UserConfig.THRESHOLD, UserConfig.THRESHOLD_FB, mThresholdOld, mThresholdNew);
			loadSpinnerParam(intent, UserConfig.GYRO_SENS, UserConfig.GYRO_SENS_FB, mGyroSensOld, mGyroSensNew);
			loadSpinnerParam(intent, UserConfig.GSM, UserConfig.GSM_FB, mGsmOld, mGsmNew);
			loadSpinnerParam(intent, UserConfig.MODE, UserConfig.MODE_FB, mModeOld, mModeNew);
         }
    }

	private void loadSpinnerParam(Intent intent, String goodKey, String fallbackKey, TextView oldField, Spinner newField) {
		String val = intent.getStringExtra(goodKey);
		String val_fallback = intent.getStringExtra(fallbackKey);
		if (val_fallback == null) {
			oldField.setText(val);
			oldField.setTextColor(mGoodColor);
			selectSpinnerValue(newField, val);
		} else {
			oldField.setText(val);
			oldField.setTextColor(mBadColor);
			selectSpinnerValue(newField, val_fallback);
		}
	}

    private void selectSpinnerValue(Spinner spinner, String text) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).equals(text)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

	private String getSelectedSpinnerValue(Spinner spinner) {
		int pos = spinner.getSelectedItemPosition();
		return (String)spinner.getItemAtPosition(pos);
	}

    private void storeValues(Bundle state) {
		state.putInt(LIVE_TIME_OLD, Integer.parseInt(mLiveTimeOld.getText().toString()));
		state.putString(THRESHOLD_OLD, mThresholdOld.getText().toString());
		state.putString(GYRO_SENS_OLD, mGyroSensOld.getText().toString());
		state.putString(GSM_OLD, mGsmOld.getText().toString());
		state.putString(MODE_OLD, mModeOld.getText().toString());

		state.putInt(LIVE_TIME_NEW, Integer.parseInt(mLiveTimeNew.getText().toString()));
		state.putString(THRESHOLD_NEW, (String)mThresholdNew.getSelectedItem());
		state.putString(GYRO_SENS_NEW, (String)mGyroSensNew.getSelectedItem());
		state.putString(GSM_NEW, (String)mGsmNew.getSelectedItem());
		state.putString(MODE_NEW, (String)mModeNew.getSelectedItem());		
    }

    private void saveAndFinish() {
		Intent intent = new Intent();

		intent.putExtra(UserConfig.LIVE_TIME, Integer.parseInt(mLiveTimeNew.getText().toString()));
		intent.putExtra(UserConfig.THRESHOLD, (String)mThresholdNew.getSelectedItem());
		intent.putExtra(UserConfig.GYRO_SENS, (String)mGyroSensNew.getSelectedItem());
		intent.putExtra(UserConfig.GSM, (String)mGsmNew.getSelectedItem());
		intent.putExtra(UserConfig.MODE, (String)mModeNew.getSelectedItem());
		
		setResult(RESULT_OK, intent);
		finish();
    }

	private void cancelAndFinish() {
		setResult(RESULT_CANCELED);
		finish();
	}
}


