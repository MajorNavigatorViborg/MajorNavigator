package com.xray.bt.monitor2;

import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.util.Log;

public class Beeper {
	private AudioTrack mAudio;
	private short[] mSamples;

	private static int RATE = 44100;

	public Beeper(int freq, int toneMs, int silenceMs) {
		int sample_tone_count = (int)((double)RATE * (double)toneMs / 1000.0);
		int sample_count = (int)((double)RATE * (double)(toneMs + silenceMs) / 1000.0);
		
		mSamples = new short[sample_count];
		
		for (int i = 0; i < sample_tone_count; i++)
			mSamples[i] = (short)(Math.sin(2 * Math.PI * i * (double)freq / (double)RATE) * Short.MAX_VALUE);
		for (int i = sample_tone_count; i < sample_count; i++)
			mSamples[i] = 0;

		int minBufSize = AudioTrack.getMinBufferSize(
			RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);

		mAudio = new AudioTrack(AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
			AudioFormat.ENCODING_PCM_16BIT, mSamples.length * 2, AudioTrack.MODE_STATIC);

		mAudio.setVolume(mAudio.getMaxVolume());
		mAudio.write(mSamples, 0, mSamples.length);
		mAudio.setLoopPoints(0, mSamples.length, -1);
	}

	public void start() {
		mAudio.play();
	}

	public void stop() {
		mAudio.stop();
	}

	public void destroy() {
		stop();
		mAudio.release();
	}
}
