package com.xray.bt.monitor2;

import java.io.IOException;

public interface SocketInterface {

	public boolean connect();
	
	public void write(byte[] buffer) throws IOException;

	public int read(byte[] buffer) throws IOException;

	public void close();

	public int bytesAvailable() throws IOException;

	public boolean isAlive();

}
