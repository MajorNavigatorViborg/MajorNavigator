package com.xray.bt.monitor2;

public class Crc {

	public static byte calcCrc8(byte current, byte[] buf, int offset, int len) {
		byte crc = current;
		for (int i = offset; i < len + offset; i++) {
			crc ^= buf[i];
			// System.out.println(String.format("--- CRC <= %02x ", buf[i]));
		}
		return crc;
	}

}
