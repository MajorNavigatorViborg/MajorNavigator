package com.xray.bt.monitor2;

import java.io.ByteArrayOutputStream;

public class HexUtils {

	public static String bytesToHexString(byte[] data, int limit) {
        if (limit == 0)
            limit = data.length;
		String s = new String();
		for (int i = 0; i < limit; i++) {
			int v = data[i] & 0xff;
			s += String.format("%02x ", v);
		}
		return s;
	}

	public static byte[] hexStringToBytes(String s) {
		if (s.length() % 2 != 0)
			return null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream(s.length() * 3);
		byte b = 0;
		boolean high = true;
		for (int i = 0; i < s.length(); i++) {
			final char c = s.charAt(i);
			if (c == ' ' || c == '-' || c == ':')
				continue;
			int val = Character.digit(c, 16);
			if (val == -1)
				return null;
			if (high) {
				b = (byte)(val << 4);
				high = false;
			} else {
				b += (byte)val;
				high = true;
				bos.write(b);
			}
		}
		return bos.toByteArray();
	}
	
}
