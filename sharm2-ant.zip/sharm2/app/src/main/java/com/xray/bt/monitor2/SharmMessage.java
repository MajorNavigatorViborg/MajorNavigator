package com.xray.bt.monitor2;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class SharmMessage {

	public class LogicException extends Exception {
		public LogicException(String s, int val) {
			super(String.format("Sharm logic error: %s: %d", s, val));
		}
	}

	private byte[] mData;

	public SharmMessage(byte[] data) throws LogicException {
		if (data == null)
			throw new LogicException("data is null", 0);
		if (data.length > 0xffff)
			throw new LogicException("data is too big", data.length);			
		mData = data;
	}

	public byte[] serialize() {
		try {
			ByteArrayOutputStream ostr =
				new ByteArrayOutputStream(4 + mData.length);
			DataOutputStream dostr = new DataOutputStream(ostr);
		
			dostr.writeByte(0xfe);
			dostr.writeShort(mData.length & 0xffff);
			dostr.write(mData, 0, mData.length);

			// calculate crc over payload only
			byte[] data = ostr.toByteArray();
			byte crc = Crc.calcCrc8((byte)0, data, 3, mData.length);

			dostr.writeByte(crc);
			ostr.flush();

			return ostr.toByteArray();
		} catch (IOException e) {
			return null;
		}
	}
    
}
