package com.xray.bt.monitor2;

public class SharmSendContext {

	private byte[] mData;
	private boolean mNeedRsp;
	private boolean mBlocking;
	private Transaction mTrans;

	public SharmSendContext(byte[] d, boolean nr, boolean bl, Transaction t) {
		mData = d;
		mNeedRsp = nr;
		mBlocking = bl;
		mTrans = t;
	}

	public byte[] data() {
		return mData;
	}

	public boolean needRsp() {
		return mNeedRsp;
	}

	public boolean blocking() {
		return mBlocking;
	}

	public Transaction transaction() {
		return mTrans;
	}

	public void setData(byte[] data) {
		mData = data;
	}

	public void setNeedRsp(boolean val) {
		mNeedRsp = val;
	}

	public void setBlocking(boolean val) {
		mBlocking = val;
	}

	public void setTransaction(Transaction t) {
		mTrans = t;
	}
	
}
