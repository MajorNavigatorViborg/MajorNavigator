package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import com.xray.bt.monitor2.SharmPacket;
import com.xray.bt.monitor2.ISharmPacketObserver;
import com.xray.bt.monitor2.State;
import com.xray.bt.monitor2.UserConfig;
import com.xray.bt.monitor2.SysConfig;
import com.xray.bt.monitor2.HexUtils;

public class SharmPacketTest implements ISharmPacketObserver {
	State parsedState;
    UserConfig userCfg;
    SysConfig sysCfg;
    String err;
    boolean userSaved;
    boolean sysSaved;

    private void init() {
        parsedState = null;
        userCfg = null;
        sysCfg = null;
        err = null;
        userSaved = false;
        sysSaved = false;
    }
    
	// пакет 5
	public void onState(State s) {
		parsedState = s;
		System.out.println(String.format("State:\n" +
				"рабочий сигнал = %f\n" +
				"батарея БД = %d\n" +
				"батарея РР = %d\n" +
				"батарея КС = %d\n" +
				"RSSI БД = %d\n" +
				"RSSI РР1 = %d\n" +
				"RSSI РР2 = %d\n" +
				"RSSI КС = %d\n" +
				"RSSI GSM = %d\n" +
				"порог БД = %d\n" +
				"порог гироскопа = %d\n" +
				"режим = %d\n" +
				"срабатвания гироскопа = %d\n",
				s.workSignal,
				s.batteryBd, s.batteryRr, s.batteryKs,
				s.rssiBd, s.rssiRr1, s.rssiRr2, s.rssiKs, s.rssiGsm,
				s.threshold, s.thresholdGyro, s.mode, s.stateGyro ? 1 : 0));
	}
	
	// пакет 1
	public void onUserConfig(UserConfig cfg) {
        userCfg = cfg;
	}
	
	// пакет 2
	public void onSysConfig(SysConfig cfg) {
        sysCfg = cfg;
	}
	
	// error parsing data structure
	public void onParsePacketError(String msg) {
        err = "parse error: " + msg;
	}

    // my config 1 has been saved
    public void onUserConfigAccepted() {
        userSaved = true;
    }
    
    // my config 2 has been saved
    public void onSysConfigAccepted() {
        sysSaved = true;
    }

	public void onResetAlertAccepted() {
	}

	@Test
	public void stateRealState() {
        init();
		SharmPacket.Incoming p = new SharmPacket.Incoming();
		SharmPacket.Outgoing o = new SharmPacket.Outgoing();
		byte[] buf = new byte[] {
				(byte)0x05,
				(byte)0x40, (byte)0x03, (byte)0x33, (byte)0x33,
				(byte)0x72, (byte)0x49, (byte)0xFC,	(byte)0x25 };
		p.parse(buf, this);
		assertNotNull(parsedState);

		byte[] buf2 = o.serializeState(parsedState);
		assertArrayEquals(buf, buf2);

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream d = new DataOutputStream(bos);
            d.writeFloat(0.01f);   // 3c 23 d7 0a = 0 01111000 01000111101011100001010 = 1.01000111b * 2^-7 = 101000111b * 2^-15 = 0.0099792
            d.writeInt(0);
            d.writeFloat(0.66f);   // 3f 28 f5 c3 = 0 01111110 01010001111010111000011 = 1.0101b * 2^-1 = 10101 * 2^-5 = 0.65625
            d.writeInt(0);
            d.writeFloat(2.05f);   // 40 03 33 33 = 0 10000000 00000110011001100110011 = 1.0000011 * 2^1 = 10000011 * 2^-6 = 2.0469
            d.writeInt(0);
            d.writeFloat(7.05f);   // 40 e1 99 9a = 0 10000001 11000011001100110011010 = 1.11000011 * 2^2 = 111000011 * 2^-6 = 7.0469
            d.writeInt(0);
            d.writeFloat(51.45f);  // 42 4d cc cd = 0 10000100 10011011100110011001100 = 1.0011b * 2^5 = 100110111 * 2^-3 = 38.875
            d.writeInt(0);
            d.writeFloat(1000.0f); // 44 7a 00 00
            d.writeInt(0);
            d.writeFloat(2000.0f); // 44 fa 00 00
            d.flush();
            System.out.println(HexUtils.bytesToHexString(bos.toByteArray(), 0));
        } catch (IOException e) {}
	}

    //@Test
    public void parseSysConfig() {
        init();
		SharmPacket.Incoming p = new SharmPacket.Incoming();
        p.parse(new byte[]
            {
                (byte)0x02, (byte)0x01, (byte)0x03, (byte)0x04, (byte)0x04, (byte)0x05, (byte)0x06, (byte)0x07, (byte)0x08
            },
            this);
        assertNull(err);
        assertNotNull(sysCfg);
    }
    
    //@Test
    public void parseUserConfig() {
        init();
		SharmPacket.Incoming p = new SharmPacket.Incoming();
        p.parse(new byte[]
            {
                (byte)0x01, (byte)0x01, (byte)0x06, (byte)0x07, (byte)0x04, (byte)0x05, (byte)0x06, (byte)0x07, (byte)0x08
            },
            this);
        assertNull(err);
        assertNotNull(userCfg);
    }
	
}
