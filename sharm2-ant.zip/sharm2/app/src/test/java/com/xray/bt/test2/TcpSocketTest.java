package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import java.io.IOException;

import com.xray.bt.monitor2.TcpSocket;

public class TcpSocketTest {

	// @Test
	public void connectToTcpServerAndExchangeData() throws IOException, InterruptedException {
		TcpSocket sock = new TcpSocket("localhost", 12345);
		System.out.println("connecting TCP");
		int connectTries = 0;
		while (!sock.connect()) {
			connectTries++;
			assertTrue(connectTries < 5);
			System.out.println("failed, will try over...");
			Thread.sleep(1000);
		}
		int bytesReceived = 0;
		int spentMs = 0;
		byte[] buf = new byte[256];
	
		while (bytesReceived < 5 && spentMs < 10000) {
			//try {
			int avail = sock.bytesAvailable();
			if (avail > 0) {
				System.out.println("socket has " + avail + " bytes to read");
				int rb = sock.read(buf);
				System.out.println("read " + rb + " bytes from socket");
				bytesReceived += rb;
				sock.write(buf);
			}
			else {
				Thread.sleep(100);
				spentMs += 100;
			}
			//catch (IOException e) {}
		}

		assertTrue(bytesReceived >= 5);

		sock.close();
	}

}
