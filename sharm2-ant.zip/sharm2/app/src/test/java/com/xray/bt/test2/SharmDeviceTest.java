package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import java.util.ArrayList;

import com.xray.bt.monitor2.*;

public class SharmDeviceTest {

	public enum Callback { STATE, USER_R, SYS_R, USER_W, SYS_W, SOCK, PARSE, LATE, TIMEOUT, MISMATCH };

	public static class SharmTester implements ISharmDevice {

		public SharmDevice dev = null;
		public ArrayList<Callback> callbacks = new ArrayList<Callback>();

		public SharmTester(String[] fakeIncomingData, boolean socketWriteFakeThrow) {
			dev = new SharmDevice(this, 500, fakeIncomingData, socketWriteFakeThrow);
            dev.start(new BtSocket(null));
		}

		public void onStateReceived(State s) {
			callbacks.add(Callback.STATE);
		}

		public void onUserConfigReceived(UserConfig cfg) {
			callbacks.add(Callback.USER_R);
		}

		public void onSysConfigReceived(SysConfig cfg) {
			callbacks.add(Callback.SYS_R);
		}

        public void onUserConfigAccepted() {
            callbacks.add(Callback.USER_W);
        }
        
        public void onSysConfigAccepted() {
            callbacks.add(Callback.SYS_W);
        }

		public void onResetAlertAccepted() {
		}

		public void onSocketError() {
			callbacks.add(Callback.SOCK);
		}

		public void onParseError(String msg) {
			callbacks.add(Callback.PARSE);
		}

		public void onResponseTooLate() {
			callbacks.add(Callback.LATE);
		}

		public void onResponseTimeout() {
			callbacks.add(Callback.TIMEOUT);
		}

		public void onResponseMismatch() {
			callbacks.add(Callback.MISMATCH);
		}

		public void onSharmMessage(byte[] data) {}
	}

	@Test
	public void createAndNothing() {
		SharmTester t = new SharmTester(new String[]{}, false);
		assertTrue(!t.dev.isRequestPending());
		sleepMs(250);
		t.dev.stop();
		assertTrue(t.callbacks.isEmpty());
	}

	@Test
	public void sendTrivalReqAndExit() {
		SharmTester t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendResetAlert());
		assertTrue(t.dev.isRequestPending());
		sleepMs(250);
		assertTrue(t.dev.isRequestPending());
		t.dev.stop();
		assertTrue(t.callbacks.isEmpty());
	}

	@Test
	public void sendComplexReqAndExit() {
		SharmTester t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendUserConfigRequest());
		assertTrue(t.dev.isRequestPending());
		sleepMs(250);
		assertTrue(t.dev.isRequestPending());
		t.dev.stop();
		assertTrue(t.callbacks.isEmpty());
	}

	@Test
	public void failRequestWhilePreviousPending() {
		SharmTester t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendUserConfigRequest());
		assertFalse(t.dev.sendUserConfigRequest());
		t.dev.stop();
		assertTrue(t.callbacks.isEmpty());
	}


	public void requestConfigAndResponse() {
		SharmTester t = new SharmTester(new String[]{ "300", "[sys]" }, false);
		assertTrue(t.dev.sendSysConfigRequest());
		sleepMs(250);
		assertTrue(t.dev.isRequestPending());
		sleepMs(100);
		assertFalse(t.dev.isRequestPending());
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.SYS_R, t.callbacks.get(0));
		t.dev.stop();
        System.out.println(t.dev.recvLogAsMultilineString());
	}

	public void requestConfigSaveAndResponse() {
		SharmTester t = new SharmTester(new String[]{ "300", "[sysok]" }, false);
		assertTrue(t.dev.sendSysConfigSetup(new SysConfig()));
		sleepMs(250);
		assertTrue(t.dev.isRequestPending());
		sleepMs(100);
		assertFalse(t.dev.isRequestPending());
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.SYS_W, t.callbacks.get(0));
		t.dev.stop();
        System.out.println(t.dev.recvLogAsMultilineString());
	}

	@Test
	public void requestConfigAndNoResponse() {
		SharmTester t = new SharmTester(new String[]{ "5000" }, false);
		assertTrue(t.dev.sendSysConfigRequest());
		sleepMs(400);
		assertTrue(t.dev.isRequestPending());
		assertTrue(t.callbacks.isEmpty());
		sleepMs(150);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.TIMEOUT, t.callbacks.get(0));
		t.dev.stop();
	}

	@Test
	public void requestConfigSaveAndNoResponse() {
		SharmTester t = new SharmTester(new String[]{ "5000" }, false);
		assertTrue(t.dev.sendSysConfigSetup(new SysConfig()));
		sleepMs(400);
		assertTrue(t.dev.isRequestPending());
		assertTrue(t.callbacks.isEmpty());
		sleepMs(150);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.TIMEOUT, t.callbacks.get(0));
		t.dev.stop();
	}

	@Test
	public void requestAndResponseTooLate() {
		SharmTester t = new SharmTester(new String[]{ "600", "[sys]" }, false);
		assertTrue(t.dev.sendSysConfigRequest());
		sleepMs(400);
		assertTrue(t.dev.isRequestPending());
		assertTrue(t.callbacks.isEmpty());
		sleepMs(150);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.TIMEOUT, t.callbacks.get(0));
		sleepMs(100);
		assertEquals(2, t.callbacks.size());
		assertEquals(Callback.LATE, t.callbacks.get(1));
		t.dev.stop();
	}

	@Test
	public void responseWithBadFormat() {
		SharmTester t = new SharmTester(new String[]{ "50", "niggers" }, false);
		assertTrue(t.dev.sendSysConfigRequest());
		assertTrue(t.callbacks.isEmpty());
		sleepMs(100);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.PARSE, t.callbacks.get(0));
		sleepMs(400);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.PARSE, t.callbacks.get(0));		
		t.dev.stop();		
	}

	@Test
	public void responseWithBadPayload() {
		SharmTester t = new SharmTester(new String[]{ "50", "[niggers]" }, false);
		assertTrue(t.dev.sendSysConfigRequest());
		assertTrue(t.callbacks.isEmpty());
		sleepMs(100);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.PARSE, t.callbacks.get(0));
		sleepMs(400);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.PARSE, t.callbacks.get(0));
		t.dev.stop();
	}

	@Test
	public void commErrorOnWrite() {
		SharmTester t = new SharmTester(new String[]{ "50", "[sys]" }, true);
		assertFalse(t.dev.sendSysConfigRequest());
		sleepMs(100);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.SOCK, t.callbacks.get(0));		
		t.dev.stop();
	}

	@Test
	public void gotThreeAsyncPackets() {
		SharmTester t = new SharmTester(new String[]{
				"25", "[state]",  "25", "[state]", "25", "[state]"
			}, false);
		sleepMs(150);
		assertEquals(3, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(0));
		assertEquals(Callback.STATE, t.callbacks.get(1));
		assertEquals(Callback.STATE, t.callbacks.get(2));
		t.dev.stop();
	}

	@Test
	public void gotSyncAndOrphanPackets() {
		SharmTester t = new SharmTester(new String[]{
				"25", "[state]",  "25", "[sys]", "25", "[state]"
			}, false);
		sleepMs(150);
		assertEquals(3, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(0));
		assertEquals(Callback.LATE, t.callbacks.get(1));
		assertEquals(Callback.STATE, t.callbacks.get(2));
		t.dev.stop();
	}

	@Test
	public void asyncAndRequestResponse() {
		SharmTester t = new SharmTester(new String[]{
				"25", "[state]",  "50", "[sys]", "25", "[state]"
			}, false);
		sleepMs(40);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(0));
  		assertTrue(t.dev.sendSysConfigRequest());
		sleepMs(50);
		assertEquals(2, t.callbacks.size());
		assertEquals(Callback.SYS_R, t.callbacks.get(1));
		sleepMs(100);
		assertEquals(3, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(2));
		t.dev.stop();
	}

	@Test
	public void typicalSequence() {
		SharmTester t = new SharmTester(new String[]{
				"50", "[user]",  "50", "[state]", "100", "[state]", "50", "[user]",
			}, false);
		assertTrue(t.dev.sendUserConfigRequest());
		sleepMs(75);
		assertEquals(1, t.callbacks.size());
		assertEquals(Callback.USER_R, t.callbacks.get(0));
		sleepMs(50);
		assertEquals(2, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(1));
		sleepMs(25);
		assertTrue(t.dev.sendUserConfigRequest());
		sleepMs(75);
		assertEquals(3, t.callbacks.size());
		assertEquals(Callback.STATE, t.callbacks.get(2));
		sleepMs(50);
		assertEquals(4, t.callbacks.size());
		assertEquals(Callback.USER_R, t.callbacks.get(3));
		t.dev.stop();
        System.out.println(t.dev.recvLogAsMultilineString());
	}

	@Test
	public void createAndDestroyMuptipleTimes() {
		SharmTester t;
		t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendUserConfigRequest());		
		t.dev.stop();

		t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendSysConfigRequest());		
		t.dev.stop();

		t = new SharmTester(new String[]{}, false);
		assertTrue(t.dev.sendUserConfigRequest());		
		t.dev.stop();
	}
		
	private void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}    	

}
