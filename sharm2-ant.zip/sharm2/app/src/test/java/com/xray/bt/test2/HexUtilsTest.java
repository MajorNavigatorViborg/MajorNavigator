package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import com.xray.bt.monitor2.HexUtils;
import com.xray.bt.monitor2.Crc;

public class HexUtilsTest {

	@Test
	public void parseEmptyHexString() {
		byte[] ret = HexUtils.hexStringToBytes("");
		assertEquals(0, ret.length);
	}

	@Test
	public void parseHexStringWithoutSpaces() {
		byte[] ret = HexUtils.hexStringToBytes("01abcd");
		System.out.println(HexUtils.bytesToHexString(ret, 0));
		assertEquals(3, ret.length);
		assertEquals((byte)0x01, ret[0]);
		assertEquals((byte)0xab, ret[1]);
		assertEquals((byte)0xcd, ret[2]);
	}

	@Test
	public void parseHexStringWithSpaces() {
		byte[] ret = HexUtils.hexStringToBytes("01 ab   cd");
		System.out.println(HexUtils.bytesToHexString(ret, 0));
		assertEquals(3, ret.length);
		assertEquals((byte)0x01, ret[0]);
		assertEquals((byte)0xab, ret[1]);
		assertEquals((byte)0xcd, ret[2]);
	}

	@Test
	public void parseInvalidHexString() {
		byte[] ret = HexUtils.hexStringToBytes("01nigger");
		assertNull(ret);
	}

    @Test
    public void crcTest() {
		byte[] ret = HexUtils.hexStringToBytes("05 28 29 20 2b 22 28 38 4e");
        assertNotNull(ret);
        System.out.println(String.format("CRC = %08x", Crc.calcCrc8((byte)0, ret, 0, ret.length)));
    }
}
