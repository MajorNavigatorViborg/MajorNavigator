package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import java.util.ArrayList;
import java.util.Random;
import java.io.ByteArrayOutputStream;
import com.xray.bt.monitor2.ISharmReaderObserver;
import com.xray.bt.monitor2.SharmReader;
import com.xray.bt.monitor2.SharmMessage;
import com.xray.bt.monitor2.HexUtils;

public class SharmReaderRandomTest implements ISharmReaderObserver {
    private Random mRnd = new Random (12345);
    private ArrayList<byte[]> mData = new ArrayList<byte[]>();

    public void onMessage(byte[] data) {
		// System.out.println("=== message of " + data.length + " bytes");
        mData.add(data);
	}

    public void onParseError(String what) {
        fail("parse error occured: " + what);
    }

    @Test
    public void randomBulk() throws SharmMessage.LogicException {
        final int NR_MSGS = 1024;
        final int MAX_PAYLOAD = 16;
        // prepare source stream
        ArrayList<byte[]> input_payloads = new ArrayList<byte[]>(NR_MSGS);
        SharmMessage[] msgs = new SharmMessage[NR_MSGS];
        ByteArrayOutputStream stream = new ByteArrayOutputStream(NR_MSGS * MAX_PAYLOAD * 2);
        for (SharmMessage m : msgs) {
            byte[] payload = randomByteArray(MAX_PAYLOAD);
            m = new SharmMessage(payload);
            input_payloads.add(payload);
            final byte[] serialized = m.serialize();
            stream.write(serialized, 0, serialized.length);
        }
        // feed stream to reader in random fashion
        final int MAX_CHUNK = 24;
		SharmReader r = new SharmReader(this);
        final byte[] stream_arr = stream.toByteArray();
        // System.out.println("Stream of size " + stream_arr.length + ", " + HexUtils.bytesToHexString(stream_arr, 0));
        int pos = 0, max_chunk;
        do {
            max_chunk = Math.min(MAX_CHUNK, stream_arr.length - pos);
            byte[] chunk;
			if (max_chunk > 1)
				chunk = new byte[mRnd.nextInt(max_chunk - 1) + 1];
			else
				chunk = new byte[1];
            System.arraycopy(stream_arr, pos, chunk, 0, chunk.length);
            // System.out.println("add chunk of size " + chunk.length + ": " + HexUtils.bytesToHexString(chunk, 0));
            r.addData(chunk, chunk.length);
            pos += chunk.length;
			// System.out.println("new pos => " + pos);
        } while(pos < stream_arr.length);
        // verify parsed and initial messages
        assertEquals(input_payloads.size(), mData.size());
        
    }

    private byte[] randomByteArray(int maxSize) {
        byte[] ret = new byte[mRnd.nextInt(maxSize)];
        for (int i = 0; i < ret.length; i++)
            ret[i] = (byte)(mRnd.nextInt(256) & 0xff);
        return ret;             
    }
}
