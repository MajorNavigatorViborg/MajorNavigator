package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import java.util.ArrayList;
import com.xray.bt.monitor2.ISharmReaderObserver;
import com.xray.bt.monitor2.SharmReader;
import com.xray.bt.monitor2.SharmMessage;

public class SharmReaderTest implements ISharmReaderObserver {
	private int mNrCallbacks;
	private byte[] mData;
    private boolean mErr;

	public void onMessage(byte[] data) {
		mNrCallbacks++;
		mData = data;
	}

    public void onParseError(String what) {
        mErr = true;
    }

    @Test
	public void testParseMonoliticIdeal() {
		init();
		SharmReader r = new SharmReader(this);
		r.addData(new byte[] {
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)0xAA^0xBB^0xCC // CRC
			}, 7);
        assertFalse(mErr);
        assertEquals(1, mNrCallbacks);
        assertEquals(3, mData.length);
        assertArrayEquals(
            new byte[]{ (byte)0xAA,(byte)0xBB,(byte)0xCC }, mData);
        //assertNull(r.getBuffer());
        assertEquals(0, r.offset());
    }

    @Test
	public void testParseMonoliticShifted() {
		init();
		SharmReader r = new SharmReader(this);
		r.addData(new byte[] {
				(byte)0xAB, (byte)0x00, (byte)0xCD, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)0xAA^0xBB^0xCC // CRC
			}, 10);
        assertFalse(mErr);
		assertEquals(1, mNrCallbacks);
		assertEquals(3, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB,(byte)0xCC }, mData);
		//assertNull(r.getBuffer());
		assertEquals(0, r.offset());
	}

    @Test
	public void testParseMonoliticDoubleShifted() {
		init();
		SharmReader r = new SharmReader(this);
		r.addData(new byte[] {
				(byte)0xAB, (byte)0x00, (byte)0xCD, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)(0xAA^0xBB^0xCC), // CRC
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x02, // data size
				(byte)0xAA, (byte)0xBB, // data
				(byte)(0xAA^0xBB), // CRC
			}, 16);
        assertFalse(mErr);
		assertEquals(2, mNrCallbacks);
		assertEquals(2, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB }, mData);
		//assertNull(r.getBuffer());
		assertEquals(0, r.offset());
	}

    @Test
	public void testParseSparseDoubleShifted() {
		SharmReader r = new SharmReader(this);

		init();
		r.addData(new byte[] {
				(byte)0xAB, (byte)0x00, (byte)0xCD, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)(0xAA^0xBB^0xCC), // CRC
			}, 10);
        assertFalse(mErr);
		assertEquals(1, mNrCallbacks);
		assertEquals(3, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB,(byte)0xCC }, mData);
		//assertNull(r.getBuffer());
		assertEquals(0, r.offset());

		init();
		r.addData(new byte[] {
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x02, // data size
				(byte)0xAA, (byte)0xBB, // data
				(byte)(0xAA^0xBB), // CRC
			}, 6);
        assertFalse(mErr);
		assertEquals(1, mNrCallbacks);
		assertEquals(2, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB }, mData);
		//assertNull(r.getBuffer());
		assertEquals(0, r.offset());
	}

    @Test
    public void testParseMonoliticDoubleUnsynced() {
		init();
		SharmReader r = new SharmReader(this);
		r.addData(new byte[] {
				(byte)0xAB,	(byte)0x00, (byte)0xCD, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)(0xAA^0xBB^0xCC), // CRC
				(byte)0xAA, (byte)0x81, (byte)0xCC, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x02, // data size
				(byte)0xAA, (byte)0xBB, // data
				(byte)(0xAA^0xBB), // CRC
				(byte)0xAB // garbage
			}, 20);
        assertFalse(mErr);
		assertEquals(2, mNrCallbacks);
		assertEquals(2, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB }, mData);
		assertNotNull(r.getBuffer());
		assertArrayEquals(r.getBuffer(), new byte[]{(byte)0xAB});
		assertEquals(1, r.offset());
	}

    @Test
	public void testParseSparseDoubleUnsynced() {
		SharmReader r = new SharmReader(this);
		init();
		r.addData(new byte[] {
				(byte)0xAB,	(byte)0x00, (byte)0xCD, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x03, // data size
				(byte)0xAA, (byte)0xBB, (byte)0xCC, // data
				(byte)(0xAA^0xBB^0xCC), // CRC
				(byte)0xAA, (byte)0xFF // garbage
			}, 12);
        assertFalse(mErr);
		assertEquals(1, mNrCallbacks);
		assertEquals(3, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB,(byte)0xCC }, mData);
		assertNotNull(r.getBuffer());
		assertEquals(2, r.offset());

		init();
		r.addData(new byte[] {
				(byte)0xCC, // garbage
				(byte)0xFE, // STX
				(byte)0x00, (byte)0x02, // data size
				(byte)0xAA, (byte)0xBB, // data
				(byte)(0xAA^0xBB), // CRC
				(byte)0xAB // garbage
			}, 8);
        assertFalse(mErr);
		assertEquals(1, mNrCallbacks);
		assertEquals(2, mData.length);
		assertArrayEquals(
			new byte[]{ (byte)0xAA,(byte)0xBB }, mData);
		assertNotNull(r.getBuffer());
		assertArrayEquals(r.getBuffer(), new byte[]{(byte)0xAB});
		assertEquals(1, r.offset());
	}

	private void init() {
		mData = null;
        mErr = false;
        mNrCallbacks = 0;
    }
    
}

