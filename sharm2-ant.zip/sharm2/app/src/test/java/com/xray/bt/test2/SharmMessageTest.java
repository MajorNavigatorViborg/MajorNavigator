package com.xray.bt.test2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import com.xray.bt.monitor2.SharmMessage;

public class SharmMessageTest {

	@Test
	public void genEmptyMessage() throws SharmMessage.LogicException {
		SharmMessage m = new SharmMessage(new byte[]{});
		byte[] buf = m.serialize();
		assertArrayEquals(
			new byte[] {
				(byte)0xFE, (byte)0x00, (byte)0x00, (byte)0x00 },
			buf);
	}

	@Test
	public void genNonEmptyMessage() throws SharmMessage.LogicException {
		SharmMessage m = new SharmMessage(new byte[]{(byte)0x23, (byte)0xab, (byte)0xcd});
		byte[] buf = m.serialize();
		assertArrayEquals(
			new byte[] {
				(byte)0xFE,
				(byte)0x00, (byte)0x03, // length including type
				(byte)0x23, // type
				(byte)0xab, (byte)0xcd, // data
				(byte)(0x23^0xab^0xcd) }, // crc
			buf);
	}
	

}
