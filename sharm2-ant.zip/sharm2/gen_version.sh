#!/bin/bash

VERSION=$(git log --oneline |head -1|cut -f1 -d' ')
if [ -f last_version ]; then
	. ./last_version
fi

if [ x${VERSION} == x${LAST_VERSION} ]; then
	echo Version not changed
	exit 0
fi

DATETIME=$(date +"%F %T")

cat <<- EOF > app/src/main/java/com/xray/bt/monitor2/Version.java
package com.xray.bt.monitor2;
public class Version {
public static final String VERSION_STRING = "${VERSION}";
public static final String TIMESTAMP = "${DATETIME}";
}
EOF

echo "LAST_VERSION=${VERSION}" > last_version
