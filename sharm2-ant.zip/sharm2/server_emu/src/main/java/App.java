import java.io.*;
import java.net.*;

import com.xray.bt.monitor2.HexUtils;

public class App {
	private static final int PORT = 1234;
	private static final int BUF_SZ = 512;
	private static volatile boolean mExit = false;

	private static void sleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {}
	}    	

	private static void receiveThread(InputStream in) {
		byte[] buf = new byte[BUF_SZ];
		while (!mExit) {
			try {
				// System.out.println("reading from socket...");
				int avail = in.available();
				if (avail > 0) {
					int rb = in.read(buf);
					System.out.println("read " + rb + " bytes from socket: " + HexUtils.bytesToHexString(buf, rb));
				}
				else {
					sleepMs(100);
				}
			}
			catch (IOException e) {
				System.err.println("receive thread exception");
				System.exit(1);
			}
		}
	}
		
    public static void main(String[] args) {
		BufferedReader br = null;
		ServerSocket server = null;
		Socket client = null;
		DataOutputStream out = null;
		SharmServer sharm = new SharmServer();
		
		try {
			server = new ServerSocket(PORT);
			System.out.print("waiting for a client...");
		
			client = server.accept();
			System.out.println("client connected");

			final InputStream in = client.getInputStream();
			out = new DataOutputStream(client.getOutputStream());
			sharm.setOutputStream(out);

			Thread recv_thread = new Thread() {
					@Override
					public void run() {
						receiveThread(in);
					}
				};
			recv_thread.start();

			br = new BufferedReader(new InputStreamReader(System.in));
			
			while (true) {
				System.out.print("> ");
				String p = br.readLine();
				if (p == null) {
					System.out.println("stdin eof, exiting");
					break;
				}
				if (p.equals("q"))
					break;
				
				if (p.length() < 2) {
					System.out.println("wrong command " + p);
					continue;
				}
				char last_char = p.charAt(p.length() - 1);
				if (!Character.isDigit(last_char)) {
					System.out.println("wrong command format " + p);
					continue;
				}
				int variant = -1;
				try {
					variant = Integer.parseInt(new String(new char[]{last_char}), 10);
				} catch (NumberFormatException e) {}
				String cmd = p.substring(0, p.length() - 1);

				byte[] out_bytes = sharm.action(cmd, variant);
				if (out_bytes != null) {
					out.write(out_bytes);
					System.out.println("wrote bytes " + HexUtils.bytesToHexString(out_bytes, 0));
				}
			}

			mExit = true;
			recv_thread.join();
		}
		catch (IOException e) {
			System.err.println("i/o error: ");
			e.printStackTrace();
		}
		catch (InterruptedException e) {
			System.out.println("interrupted");
		}
		finally {
			try {
				System.out.println("closing everything");
				if (br != null) br.close();
				if (out != null) out.close();
				if (server != null) server.close();
				if (client != null) client.close();
			} catch (IOException e) {}
		}
	}
}
