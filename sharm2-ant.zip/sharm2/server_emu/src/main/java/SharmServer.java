import com.xray.bt.monitor2.SharmPacket;
import com.xray.bt.monitor2.SharmSendContext;
import com.xray.bt.monitor2.SharmMessage;
import com.xray.bt.monitor2.State;
import com.xray.bt.monitor2.UserConfig;
import com.xray.bt.monitor2.SysConfig;

import java.io.*;

public class SharmServer {
	private SharmPacket.Outgoing mOut = new SharmPacket.Outgoing();
	private DataOutputStream mOutStream = null;
	
	private State[] STATES = new State[] {
            new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, false, "mode 0"),
            new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
                7, 0, 1, false, "mode 1"),
			new State(500,
				13, 14, 15,
				2, 3, 2, 3, 14,
				8, 0, 0, false, "bad threshold 1"),
            new State(0.5F,
				15, 14, 13,
				3, 2, 3, 2, 15,
				7, 0, 0, true, "theft"),
	};

	private UserConfig[] USER_CFGS = new UserConfig[] {
		new UserConfig(40, 3, 1, 1, 1),
		new UserConfig(9, 66, 77, 88, 99),
	};

	private SysConfig[] SYS_CFGS = new SysConfig[] {
		new SysConfig(10, 20, 30, 40, 50, 60, 70, 80),
		new SysConfig(0xff, 0xffff, 0xffff, 0xffff, 0xff, 0xff, 0xff, 0xffff)
	};

	public void setOutputStream(DataOutputStream s) {
		mOutStream = s;
	}

	public byte[] action(String cmd, int variant) {
		try {
			SharmMessage msg = null;
			if (cmd.equals("s"))
				msg = sendState(variant);
			else if (cmd.equals("ss"))
				schedulePeriodicState(variant);
			else if (cmd.equals("user"))
				msg = sendUser(variant);
			else if (cmd.equals("sys"))
				msg = sendSys(variant);			
			else if (cmd.equals("userok"))
				msg = sendUserOk();
			else if (cmd.equals("sysok"))
				msg = sendSysOk();
			else if (cmd.equals("resetok"))
				msg = sendResetOk();
			else
				return null;

			if (msg != null)
				return msg.serialize();
			else
				return null;
		} catch (SharmMessage.LogicException e) {
			return null;
		}
	}

	private SharmMessage sendState(int n) throws SharmMessage.LogicException {
		if (n < STATES.length) {
            System.out.println("sending State about '" + STATES[n].testName + "'");
			return new SharmMessage(mOut.serializeState(STATES[n]));
        }
		else
			return null;
	}

	private void schedulePeriodicState(int nr) {
		System.out.println("will send periodic stated");
		Thread thread = new Thread() {
				@Override
				public void run() {
					System.out.println("send thread started");
					try {
						while (true) {
							for (int state_index = 0; state_index < STATES.length; state_index++ ) {
								Thread.sleep(nr * 100);
								SharmMessage msg = sendState(state_index);
								mOutStream.write(msg.serialize());
							}
						}
					}
					catch (SharmMessage.LogicException e) {
						System.err.println("sharm logic exception " + e.getMessage());
					}
					catch (InterruptedException e) {
						System.out.println("interrupted");
					}
					catch (IOException e) {
						System.out.println("io exception " + e.getMessage());
					}
				}
			};
		thread.start();
	}

	private SharmMessage sendUser(int n) throws SharmMessage.LogicException {
		if (n < USER_CFGS.length) {
			SharmSendContext ctx = mOut.serializeUserConfigSetup(USER_CFGS[n]);
			return new SharmMessage(ctx.data());
		}
		else
			return null;
	}

	private SharmMessage sendSys(int n) throws SharmMessage.LogicException {
		if (n < SYS_CFGS.length) {
			SharmSendContext ctx = mOut.serializeSysConfigSetup(SYS_CFGS[n]);
			return new SharmMessage(ctx.data());
		}
		else
			return null;
	}

    private SharmMessage sendUserOk() throws SharmMessage.LogicException {
        return new SharmMessage(mOut.serializeUserConfigAccepted());
    }

    private SharmMessage sendSysOk() throws SharmMessage.LogicException {
        return new SharmMessage(mOut.serializeSysConfigAccepted());
    }

    private SharmMessage sendResetOk() throws SharmMessage.LogicException {
        return new SharmMessage(mOut.serializeResetAlertAccepted());
    }
}
